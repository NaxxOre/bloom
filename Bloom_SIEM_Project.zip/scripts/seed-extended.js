/* eslint-disable @typescript-eslint/no-require-imports */
const { PrismaClient } = require('@prisma/client')

const db = new PrismaClient()

const ATTACK_SURFACE_ASSETS = [
  { hostname: 'admin.bloomsec.net', ipAddress: '52.84.62.123', type: 'web_app', exposure: 'internet_facing', riskScore: 78, ports: [{port:443,service:'https',banner:'nginx/1.25.3'},{port:80,service:'http',banner:'nginx/1.25.3'}] },
  { hostname: 'api.bloomsec.net', ipAddress: '52.84.62.124', type: 'api', exposure: 'internet_facing', riskScore: 65, ports: [{port:443,service:'https',banner:'envoy'},{port:8080,service:'http',banner:'istio-proxy'}] },
  { hostname: 'portal.bloomsec.net', ipAddress: '52.84.62.125', type: 'web_app', exposure: 'internet_facing', riskScore: 54, ports: [{port:443,service:'https',banner:'cloudfront'}] },
  { hostname: 'shop.bloomsec.net', ipAddress: '52.84.62.126', type: 'web_app', exposure: 'internet_facing', riskScore: 71, ports: [{port:443,service:'https',banner:'nginx'},{port:22,service:'ssh',banner:'OpenSSH 8.9'}] },
  { hostname: 'db-prod-01.internal', ipAddress: '10.0.12.45', type: 'server', exposure: 'internal', riskScore: 42, ports: [{port:5432,service:'postgresql',banner:'PostgreSQL 14.10'}] },
  { hostname: 'redis-cache.internal', ipAddress: '10.0.12.50', type: 'server', exposure: 'internal', riskScore: 38, ports: [{port:6379,service:'redis',banner:'Redis 7.2'}] },
  { hostname: 'bastion.bloomsec.net', ipAddress: '52.84.62.130', type: 'server', exposure: 'dmz', riskScore: 89, ports: [{port:22,service:'ssh',banner:'OpenSSH 9.0'},{port:3389,service:'rdp',banner:'Microsoft Terminal Service'}] },
  { hostname: 'vpn.bloomsec.net', ipAddress: '52.84.62.140', type: 'server', exposure: 'internet_facing', riskScore: 67, ports: [{port:443,service:'https',banner:'OpenVPN Access Server'},{port:1194,service:'openvpn',banner:'OpenVPN 2.6'}] },
  { hostname: 'k8s-api.bloomsec.net', ipAddress: '52.84.62.150', type: 'api', exposure: 'internet_facing', riskScore: 92, ports: [{port:6443,service:'kubernetes-api',banner:'Kubernetes v1.28.4'}] },
  { hostname: 'mail.bloomsec.net', ipAddress: '52.84.62.160', type: 'server', exposure: 'internet_facing', riskScore: 58, ports: [{port:25,service:'smtp',banner:'Postfix 3.7'},{port:443,service:'https',banner:'nginx'},{port:993,service:'imaps',banner:'Dovecot 2.3'}] },
  { hostname: 'iot-sensor-01', ipAddress: '10.0.30.12', type: 'iot', exposure: 'internal', riskScore: 84, ports: [{port:80,service:'http',banner:'Boa HTTPd 0.94'},{port:23,service:'telnet',banner:'BusyBox telnetd'}] },
  { hostname: 'ci-runner-01', ipAddress: '10.0.20.30', type: 'container', exposure: 'vpn', riskScore: 47, ports: [{port:8080,service:'http',banner:'GitLab Runner 16.5'}] },
]

const EXPOSURES = [
  { title: 'CVE-2024-3094 - XZ Utils backdoor', description: 'XZ Utils versions 5.6.0 and 5.6.1 contain malicious code via liblzma that allows SSH authentication bypass.', severity: 'critical', category: 'cve', cveId: 'CVE-2024-3094', cvssScore: 10.0, assetName: 'bastion.bloomsec.net' },
  { title: 'CVE-2024-6387 - regreSSHion OpenSSH RCE', description: 'A signal handler race condition in OpenSSH server allows unauthenticated remote code execution as root.', severity: 'critical', category: 'cve', cveId: 'CVE-2024-6387', cvssScore: 8.1, assetName: 'bastion.bloomsec.net' },
  { title: 'Kubernetes API exposed to internet', description: 'k8s-api.bloomsec.net:6443 is reachable from the internet without IP allowlist. Should be behind bastion or VPN only.', severity: 'critical', category: 'open_port', cvssScore: 9.1, assetName: 'k8s-api.bloomsec.net' },
  { title: 'Weak TLS configuration on admin panel', description: 'admin.bloomsec.net supports TLS 1.0 and TLS 1.1, both deprecated. Cipher suite includes RC4-MD5.', severity: 'high', category: 'misconfiguration', cvssScore: 7.5, assetName: 'admin.bloomsec.net' },
  { title: 'Default credentials on Redis container', description: 'redis-cache.internal has no AUTH configured. Any internal network user can read/write all keys.', severity: 'critical', category: 'weak_credential', cvssScore: 9.8, assetName: 'redis-cache.internal' },
  { title: 'IoT device running vulnerable Boa HTTPd', description: 'iot-sensor-01 runs Boa HTTPd 0.94, last patched in 2005. Multiple known RCE vulnerabilities.', severity: 'high', category: 'cve', cveId: 'CVE-2017-9833', cvssScore: 9.8, assetName: 'iot-sensor-01' },
  { title: 'Telnet enabled on IoT sensor', description: 'iot-sensor-01 has telnet (port 23) open with default credentials. Should be disabled in favor of SSH.', severity: 'high', category: 'open_port', cvssScore: 8.2, assetName: 'iot-sensor-01' },
  { title: 'Missing security patches - PostgreSQL 14.10', description: 'db-prod-01.internal is missing 4 critical security patches from Q1 2026 quarterly release.', severity: 'medium', category: 'missing_patch', cvssScore: 5.5, assetName: 'db-prod-01.internal' },
  { title: 'Open RDP port on bastion host', description: 'bastion.bloomsec.net exposes RDP (3389) directly to internet without MFA or IP allowlist.', severity: 'high', category: 'open_port', cvssScore: 8.5, assetName: 'bastion.bloomsec.net' },
  { title: 'Outdated OpenVPN Access Server', description: 'vpn.bloomsec.net runs OpenVPN AS 2.7.3, vulnerable to CVE-2024-28995 path traversal.', severity: 'medium', category: 'cve', cveId: 'CVE-2024-28995', cvssScore: 6.5, assetName: 'vpn.bloomsec.net' },
  { title: 'Postfix SMTP relay allows open auth', description: 'mail.bloomsec.net permits relay with weak PLAIN auth, allowing email spoofing.', severity: 'medium', category: 'misconfiguration', cvssScore: 5.9, assetName: 'mail.bloomsec.net' },
  { title: 'Shop subdomain - missing CSP header', description: 'shop.bloomsec.net lacks Content-Security-Policy header, vulnerable to XSS attacks.', severity: 'low', category: 'misconfiguration', cvssScore: 3.2, assetName: 'shop.bloomsec.net' },
]

const BLOCKED_DOMAINS = [
  { hostname: 'malicious-c2.evil.tk', type: 'domain', status: 'blocked', source: 'auto_action', reason: 'C2 beacon detected from alert ALT-2026-0142', hits: 47 },
  { hostname: '185.220.101.45', type: 'ip', status: 'blocked', source: 'threat_feed', reason: 'Listed on AbuseIPDB confidence 92%', hits: 1283 },
  { hostname: 'tor-exit-01.datapoint.network', type: 'domain', status: 'blocked', source: 'manual', reason: 'Tor exit node - manual block by SOC', hits: 89 },
  { hostname: 'phishing-login-clone.xyz', type: 'domain', status: 'blocked', source: 'threat_feed', reason: 'PhishTank verified URL', hits: 234 },
  { hostname: '193.27.228.142', type: 'ip', status: 'blocked', source: 'auto_action', reason: 'Brute force SSH - 50+ failed attempts', hits: 612 },
  { hostname: 'torrent-tracker.lol', type: 'domain', status: 'blocked', source: 'manual', reason: 'Policy violation - P2P traffic', hits: 17 },
  { hostname: 'suspicious-dns-tunnel.ml', type: 'domain', status: 'monitored', source: 'auto_action', reason: 'DNS tunneling suspected, monitoring', hits: 4 },
  { hostname: 'new-vendor-api.example.com', type: 'domain', status: 'allowed', source: 'manual', reason: 'Approved vendor API', hits: 0 },
  { hostname: '45.155.205.83', type: 'ip', status: 'blocked', source: 'threat_feed', reason: 'Known scanner network', hits: 894 },
  { hostname: 'cryptominer-pool.hashparty.io', type: 'domain', status: 'blocked', source: 'auto_action', reason: 'Cryptominer C2 detected', hits: 56 },
]

const LOG_SOURCES = [
  { name: 'web-logs-syslog', sourceType: 'syslog', endpoint: 'syslog://bloomsec.net:514', sharedSecret: '', enabled: true, eventsIngested: 1847291 },
  { name: 'firewall-webhook', sourceType: 'webhook', endpoint: 'https://bloomsec.net/api/ingest/firewall', sharedSecret: 'whsec_***REDACTED***', enabled: true, eventsIngested: 524882 },
  { name: 'edr-endpoints', sourceType: 'api', endpoint: 'https://edr.bloomsec.net/api/v2/events', sharedSecret: 'api_***REDACTED***', enabled: true, eventsIngested: 412934 },
  { name: 'cloudtrail-aws', sourceType: 'webhook', endpoint: 'sqs://cloudtrail-events-queue', sharedSecret: '', enabled: true, eventsIngested: 87234 },
  { name: 'okta-identity', sourceType: 'api', endpoint: 'https://bloomsec.okta.com/api/v1/logs', sharedSecret: 'ssws_***REDACTED***', enabled: true, eventsIngested: 18923 },
  { name: 'k8s-audit', sourceType: 'webhook', endpoint: 'https://bloomsec.net/api/ingest/k8s', sharedSecret: 'whsec_***REDACTED***', enabled: false, eventsIngested: 0 },
]

function random(arr) { return arr[Math.floor(Math.random() * arr.length)] }
function randomInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min }
function randomDate(daysBack, hoursBack = 0) {
  const d = new Date()
  d.setDate(d.getDate() - daysBack)
  d.setHours(d.getHours() - hoursBack)
  d.setMinutes(d.getMinutes() - randomInt(0, 60))
  return d
}

async function main() {
  console.log('Clearing new model data...')
  await db.analystVerdict.deleteMany()
  await db.aIProvider.deleteMany()
  await db.domain.deleteMany()
  await db.logSource.deleteMany()
  await db.attackSurfaceAsset.deleteMany()
  await db.exposure.deleteMany()

  // Default AI Provider - ZAI (built-in to this sandbox via z-ai-web-dev-sdk)
  console.log('Creating AI providers...')
  await db.aIProvider.create({
    data: {
      provider: 'zai',
      label: 'Bloom AI (default)',
      apiKey: 'auto-configured',
      baseUrl: 'https://chat.z.ai/api',
      model: 'glm-4.6',
      enabled: true,
      isDefault: true,
      lastUsedAt: randomDate(0, randomInt(0, 1)),
    }
  })
  await db.aIProvider.create({
    data: {
      provider: 'openai',
      label: 'OpenAI GPT-4o',
      apiKey: '',
      baseUrl: 'https://api.openai.com/v1',
      model: 'gpt-4o',
      enabled: false,
      isDefault: false,
    }
  })
  await db.aIProvider.create({
    data: {
      provider: 'anthropic',
      label: 'Anthropic Claude 3.5 Sonnet',
      apiKey: '',
      baseUrl: 'https://api.anthropic.com',
      model: 'claude-3-5-sonnet-20241022',
      enabled: false,
      isDefault: false,
    }
  })
  await db.aIProvider.create({
    data: {
      provider: 'groq',
      label: 'Groq Llama 3.1 70B',
      apiKey: '',
      baseUrl: 'https://api.groq.com/openai/v1',
      model: 'llama-3.1-70b-versatile',
      enabled: false,
      isDefault: false,
    }
  })
  await db.aIProvider.create({
    data: {
      provider: 'mistral',
      label: 'Mistral Large',
      apiKey: '',
      baseUrl: 'https://api.mistral.ai/v1',
      model: 'mistral-large-latest',
      enabled: false,
      isDefault: false,
    }
  })

  console.log('Creating attack surface assets...')
  for (const a of ATTACK_SURFACE_ASSETS) {
    await db.attackSurfaceAsset.create({
      data: {
        hostname: a.hostname,
        ipAddress: a.ipAddress,
        type: a.type,
        exposure: a.exposure,
        riskScore: a.riskScore,
        openPorts: JSON.stringify(a.ports),
        services: JSON.stringify(a.ports.map(p => p.service)),
        lastScanned: randomDate(0, randomInt(0, 12)),
      }
    })
  }

  console.log('Creating exposures...')
  for (const e of EXPOSURES) {
    await db.exposure.create({
      data: {
        title: e.title,
        description: e.description,
        severity: e.severity,
        category: e.category,
        cveId: e.cveId || null,
        cvssScore: e.cvssScore || null,
        assetName: e.assetName,
        status: Math.random() > 0.6 ? random(['mitigated', 'accepted']) : 'open',
        discoveredAt: randomDate(randomInt(0, 30), randomInt(0, 12)),
      }
    })
  }

  console.log('Creating blocked domains/IPs...')
  for (const d of BLOCKED_DOMAINS) {
    await db.domain.create({
      data: {
        hostname: d.hostname,
        type: d.type,
        status: d.status,
        source: d.source,
        reason: d.reason,
        hits: d.hits,
        blockedAt: d.status === 'blocked' ? randomDate(randomInt(0, 14), randomInt(0, 12)) : null,
      }
    })
  }

  console.log('Creating log sources...')
  for (const s of LOG_SOURCES) {
    await db.logSource.create({
      data: {
        ...s,
        lastEvent: s.enabled ? randomDate(0, 0) : null,
      }
    })
  }

  console.log('\n=== EXTENDED SEED COMPLETE ===')
  const counts = {
    aIProviders: await db.aIProvider.count(),
    attackSurfaceAssets: await db.attackSurfaceAsset.count(),
    exposures: await db.exposure.count(),
    domains: await db.domain.count(),
    logSources: await db.logSource.count(),
  }
  console.log(counts)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
