const {
  Document, Packer, Paragraph, TextRun, AlignmentType,
  LevelFormat,
} = require("docx");
const fs = require("fs");

const FONT = { ascii: "Times New Roman", eastAsia: "Times New Roman" };
const SZ = 24;

function p(text, opts = {}) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, size: SZ, font: FONT, ...opts })],
  });
}
function h1(text) {
  return new Paragraph({
    alignment: AlignmentType.LEFT,
    spacing: { before: 360, after: 200 },
    children: [new TextRun({ text, bold: true, size: 28, font: FONT })],
  });
}
function h2(text) {
  return new Paragraph({
    alignment: AlignmentType.LEFT,
    spacing: { before: 280, after: 160 },
    children: [new TextRun({ text, bold: true, size: 26, font: FONT })],
  });
}
function center(text, sz = SZ) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, size: sz, font: FONT, bold: true })],
  });
}
function bul(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    numbering: { reference: "bl", level: 0 },
    spacing: { after: 60, line: 312 },
    children: [new TextRun({ text, size: SZ, font: FONT })],
  });
}

const doc = new Document({
  creator: "Bloom",
  title: "Bloom SIEM Requirement Analysis",
  styles: { default: { document: { run: { font: FONT, size: SZ }, paragraph: { spacing: { line: 312 } } } } },
  numbering: {
    config: [
      { reference: "bl", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ],
  },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: [
      center("University of Information Technology", 28),
      center("Faculty of Computer Systems and Technologies", 26),
      center("Network & Internet Security (CST-8415)", 26),
      p(""),
      center("Requirement Analysis", 28),
      center("Bloom SIEM: Real-Time Security Monitoring with AI-Driven Threat Detection and Automated Response", 24),
      p(""),
      p(""),

      h1("1. Functional Requirements"),
      p(""),
      p("The following functional requirements define the core capabilities that Bloom SIEM must deliver. Each requirement is mapped to a real, working feature in the system.", { bold: true }),
      p(""),

      h2("1.1 Log Ingestion and Traffic Monitoring"),
      bul("Ingest real-time web traffic events via HTTP middleware (Next.js, HTML script tag, PHP, or Express)."),
      bul("Capture request metadata including method, path, IP address, user agent, status code, and response time."),
      bul("Capture form input field names and values (sanitized) for SQLi and XSS detection."),
      bul("Track button clicks and page navigation on connected sites via client-side script."),
      bul("Support batch event ingestion (up to 100 events per request) with shared-secret authentication."),
      bul("Store all events in a persistent database with timestamp indexing for fast retrieval."),

      p(""),
      h2("1.2 Threat Detection Engine"),
      bul("Detect brute-force login attempts (5+ failed logins from same IP within 10 minutes)."),
      bul("Detect SQL injection patterns in input fields (UNION SELECT, OR 1=1, DROP TABLE, xp_cmdshell)."),
      bul("Detect Cross-Site Scripting (XSS) payloads in input fields (<script>, javascript:, onerror=)."),
      bul("Detect route scanning behavior (5+ 404/403 responses from same IP across different paths)."),
      bul("Detect session replication (same session token used from multiple IP addresses)."),
      bul("Detect malware file uploads via hash signature matching and double-extension detection (e.g., image.php.exe)."),
      bul("Map all detected threats to MITRE ATT&CK tactics and techniques (T1110, T1204, T1190, T1059, T1595, T1078)."),

      p(""),
      h2("1.3 AI Analyst Verdict System"),
      bul("Generate confidence-scored verdicts (0-100%) for each alert using LLM APIs (Z.ai GLM-4.6)."),
      bul("Produce structured output: verdict (safe, auto-contain, high-risk, critical), summary, rationale, key findings, recommended actions."),
      bul("Support multiple AI providers (OpenAI, Anthropic, Groq, Mistral) with opencode-style provider switching."),
      bul("Provide a Test API button that sends a real test prompt to the configured provider and displays the actual response and latency."),
      bul("Fall back to rule-based verdict generation if the LLM API is unreachable."),

      p(""),
      h2("1.4 Automated Response Playbook"),
      bul("Automatically block source IPs by adding them to the blocklist when high-severity rules fire."),
      bul("Revoke user sessions instantly when malware uploads or session replication is detected."),
      bul("Quarantine uploaded files flagged as malicious before they reach the application."),
      bul("Send real-time Telegram alerts with Approve/Deny inline buttons for admin approval."),
      bul("Process Telegram webhook callbacks to execute approve (keep block) or deny (unblock IP) actions."),
      bul("Enforce country-based blocking using IP geolocation lookup (ip-api.com) with 24-hour cache."),
      bul("Enforce a cooldown period between rule firings to prevent alert fatigue."),

      p(""),
      h2("1.5 Site Discovery and Domain Analysis"),
      bul("Perform deep crawl of connected sites using headless Chromium (Playwright) to render JavaScript."),
      bul("Click buttons on SPA sites to discover hidden forms and input fields that appear after interaction."),
      bul("Extract all routes, forms, input fields, buttons, and links from the rendered DOM."),
      bul("Identify inaccessible routes (HTTP 404, 403) and flag them as potential attack targets."),
      bul("Perform real DNS resolution (A, CNAME, MX, NS, TXT records) on monitored domains."),
      bul("Perform real SSL certificate inspection (issuer, validity window, days until expiry)."),
      bul("Perform real HTTP reachability checks (status code, response time, server header, content type)."),
      bul("Perform real TCP port scanning on common service ports (22, 80, 443, 3000, 3306, 5432, 6379, 8080, 9200)."),
      bul("Generate AI risk assessments for monitored targets with risk level, score, findings, and recommendations."),

      p(""),
      h2("1.6 Dashboard and Reporting"),
      bul("Display real-time traffic overview (Vercel-style) with allowed, denied, challenged, logged, and rate-limited counters."),
      bul("Show top IPs, JA4 fingerprints, AS names, user agents, request paths, and hosts from real traffic data."),
      bul("Display brute-force detection results with IP, targeted field, attempt count, and severity."),
      bul("Display session replication alerts with session ID and associated IPs."),
      bul("Show IP activity spike graph (requests per hour) with multi-IP line chart."),
      bul("Display site discovery panel with all routes, input fields, buttons, and inaccessible paths."),
      bul("Provide live activity feed via Server-Sent Events streaming heartbeats, logs, alerts, and AI actions."),
      bul("Display MITRE ATT&CK playbook with AI-driven technique evaluation (Run AI Check button per technique)."),

      p(""),
      h2("1.7 Heartbeat and Agent Monitoring"),
      bul("Enforce configurable heartbeat interval (1-60 minutes) for connected site middleware."),
      bul("Generate alerts when no traffic arrives within the offline threshold period."),
      bul("Display heartbeat timeline with real timestamps and live status indicators (green, red, gray)."),

      p(""),
      h2("1.8 Blocklist Management"),
      bul("Add, remove, block, allow, and monitor IP addresses and domains via the blocklist UI."),
      bul("Automatically increment hit counters when blocked IPs attempt to access connected sites."),
      bul("Display geo-block entries (country:MM) created by country automation rules."),
      bul("Enforce blocklist via the middleware evaluate endpoint (returns 403 for blocked IPs)."),

      p(""),
      h2("1.9 Compliance and Controls"),
      bul("Track compliance across NIST, ISO 27001, PCI-DSS, and SOC 2 frameworks."),
      bul("Display MITRE ATT&CK coverage table with 13 tactics and detection rule mappings."),
      bul("Allow AI-driven evaluation of each MITRE technique against current alert data."),

      p(""),
      h1("2. Non-Functional Requirements"),
      p(""),
      bul("The system shall use fire-and-forget logging to ensure request processing is never blocked by telemetry (maximum 800ms timeout on synchronous threat evaluation, fails open on timeout)."),
      bul("All AI API keys shall be stored server-side only and never transmitted to the client browser; keys are masked in the UI."),
      bul("Input sanitization shall strip passwords, tokens, and credit-card numbers from telemetry before storage."),
      bul("The system shall support CORS for cross-origin ingestion from any domain (browser script tag compatibility)."),
      bul("Detection rules shall be evaluated in real-time on every ingested event with a 5-minute cooldown to prevent duplicate alerts."),
      bul("The system shall cache IP geolocation results for 24 hours to minimize external API calls."),
      bul("The web interface shall use a skeleton loading animation during page transitions to indicate progress."),
      bul("All pages shall have real URL routes (not client-side state) for bookmarkability and browser navigation."),
      bul("The system shall be deployable on Vercel, Netlify, or any Node.js host with zero vendor lock-in."),
      bul("The system shall use SQLite as the database for zero-configuration deployment with no external database server required."),
      bul("The system shall handle up to 200 events per ingestion batch without performance degradation."),
      bul("The Playwright-based site scanner shall complete within 60 seconds for sites with up to 15 pages."),
      bul("All code shall be written in TypeScript with strict typing and pass ESLint validation with zero errors."),
      bul("The system shall be open-source under the MIT license with no proprietary dependencies."),

      p(""),
      h1("3. Data Requirements"),
      p(""),
      p("The following data is collected, processed, and stored by Bloom SIEM:", { bold: true }),
      p(""),

      h2("3.1 Traffic Event Data (from connected sites)"),
      bul("HTTP request method, path, host, and protocol."),
      bul("Client IP address (extracted from X-Forwarded-For, X-Real-IP, or CF-Connecting-IP headers)."),
      bul("User agent string and computed JA4 TLS fingerprint."),
      bul("IP geolocation data (country, country code, ASN) from ip-api.com."),
      bul("Form input field names and sanitized values (first 500 characters, passwords and credit cards stripped)."),
      bul("Button click events (element text and target path)."),
      bul("File upload metadata (SHA-256 hash, filename, file size, MIME type, scan verdict)."),
      bul("Session identifiers (for session replication detection and revocation)."),
      bul("HTTP response status code and response time in milliseconds."),
      bul("Action taken by the system (allowed, denied, challenged, logged, rate-limited) and the rule that triggered it."),

      p(""),
      h2("3.2 Alert and Investigation Data"),
      bul("Alert title, description, severity (low, medium, high, critical), and status (new, triaged, escalated, closed)."),
      bul("MITRE ATT&CK tactic and technique ID for each alert."),
      bul("AI analyst verdict (verdict, confidence score 0-100, summary, rationale, key findings, recommended actions)."),
      bul("AI provider and model used for the verdict (e.g., zai/glm-4.6)."),
      bul("Investigation title, assignee, summary, and malicious flag."),
      bul("Source IP, destination IP, and agent ID associated with each alert."),

      p(""),
      h2("3.3 Domain Analysis Data"),
      bul("DNS resolution results (A records, CNAME, MX, NS, TXT records)."),
      bul("SSL certificate details (subject, issuer, valid from, valid to, days until expiry, validity status)."),
      bul("HTTP reachability results (status code, response time, server header, content type, body preview)."),
      bul("TCP port scan results (port number, service name, open/closed status, response time)."),
      bul("AI-generated risk assessment (risk level, risk score 0-100, findings, recommendations)."),

      p(""),
      h2("3.4 Configuration and Rule Data"),
      bul("AI provider configurations (provider type, API key, base URL, model name, enabled status, default flag)."),
      bul("Automation rules (trigger type, condition JSON, action, cooldown period, fire count, enable/disable)."),
      bul("Custom WAF rules (condition, action, priority, hit count)."),
      bul("Intelligence configuration (heartbeat interval, offline threshold, auto-triage enabled, AI actions enabled, minimum severity for auto-action)."),
      bul("Telegram bot configuration (bot token, chat ID, notification preferences, approval requirement flag)."),
      bul("IP/domain blocklist entries (hostname, type, status, source, reason, hit count, blocked timestamp)."),
      bul("Session revocation records (session ID, project ID, reason, expiry time)."),
      bul("Compliance control records (framework, control ID, title, status, category, last checked)."),

      p(""),
      h2("3.5 Site Discovery Data"),
      bul("Discovered routes (path, HTTP method, status code, accessibility)."),
      bul("Discovered forms (action URL, method, field names, field types, required flags, placeholders)."),
      bul("Discovered standalone input fields (name, type, required, placeholder, ID, CSS class)."),
      bul("Discovered buttons (text, href, type — button, link, submit, role-button)."),
      bul("Discovered links (href, text)."),
      bul("Page title and meta description."),
      bul("Crawl metadata (pages crawled, scan duration, SPA detection flag)."),

      p(""),
      h2("3.6 System Data"),
      bul("Process metadata (PID, uptime, memory usage, CPU usage)."),
      bul("Host system metadata (OS, CPU model, core count, load average, total/used/free memory)."),
      bul("Database metadata (file size, total records, per-table counts)."),
      bul("Connected project data (project name, domain, API key, project ID, firewall status, bot protection status)."),
      bul("Log source configurations (name, type, endpoint, shared secret, events ingested, last event time)."),
    ],
  }],
});

const OUTPUT = "/home/z/my-project/download/Bloom_SIEM_Requirement_Analysis.docx";
Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(OUTPUT, buf);
  console.log(`Generated ${OUTPUT} (${(buf.length / 1024).toFixed(1)} KB)`);
});
