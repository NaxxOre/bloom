/* eslint-disable @typescript-eslint/no-require-imports */
const { PrismaClient } = require('@prisma/client')
const db = new PrismaClient()

async function main() {
  console.log('Clearing fake/mock data...')

  // Delete all fake seeded alerts, investigations, actions, logs
  const deleted = {
    autoActions: await db.autoAction.deleteMany({ where: { initiatedBy: 'ai' } }),
    autoActionRules: await db.autoActionRule.deleteMany({}),
    investigations: await db.investigation.deleteMany({}),
    alerts: await db.alert.deleteMany({}),
    logs: await db.log.deleteMany({}),
    analystVerdicts: await db.analystVerdict.deleteMany({}),
    agents: await db.agent.deleteMany({}),
    assets: await db.asset.deleteMany({}),
    dataConnectors: await db.dataConnector.deleteMany({}),
    complianceControls: await db.complianceControl.deleteMany({}),
    // Keep: IntelligenceConfig, AIProvider, Domain, LogSource (these are real config)
  }

  console.log('Deleted fake data:', deleted)

  // Verify real config is intact
  const real = {
    aIProviders: await db.aIProvider.count(),
    domains: await db.domain.count(),
    logSources: await db.logSource.count(),
    intelligenceConfig: await db.intelligenceConfig.count(),
    monitoredTargets: await db.monitoredTarget.count(),
  }
  console.log('Real config preserved:', real)

  // Add a real default log source if none exists
  if (real.logSources === 0) {
    await db.logSource.create({
      data: {
        name: 'default-webhook',
        sourceType: 'webhook',
        endpoint: '/api/ingest?source=default-webhook',
        sharedSecret: '',
        enabled: true,
      }
    })
    console.log('Created default log source')
  }

  // Add localhost:3000 as a real monitored target (this Next.js app itself)
  if (real.monitoredTargets === 0) {
    await db.monitoredTarget.create({
      data: {
        hostname: 'localhost:3000',
        kind: 'localhost',
        label: 'Bloom SIEM (self)',
        notes: 'The SIEM app itself — health check target',
      }
    })
    console.log('Added localhost:3000 as default monitored target')
  }
}

main().catch(console.error).finally(() => db.$disconnect())
