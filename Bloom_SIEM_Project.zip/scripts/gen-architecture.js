const {
  Document, Packer, Paragraph, TextRun, AlignmentType,
  LevelFormat, HeadingLevel, ImageRun,
} = require("docx");
const fs = require("fs");
const { imageSize } = require("image-size");

const FONT = { ascii: "Times New Roman", eastAsia: "Times New Roman" };
const SZ = 24;

function p(text, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.JUSTIFIED,
    spacing: { after: opts.after ?? 80, line: 312 },
    children: [new TextRun({ text, size: opts.size || SZ, font: FONT, bold: opts.bold, italics: opts.italics })],
  });
}
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 200 },
    children: [new TextRun({ text, bold: true, size: 28, font: FONT })],
  });
}
function center(text, sz = SZ, bold = true) {
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, size: sz, font: FONT, bold })] });
}
function bul(text) {
  return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "bl", level: 0 },
    spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] });
}
function num(text) {
  return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "nl", level: 0 },
    spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] });
}
function empty() { return new Paragraph({ spacing: { after: 60 }, children: [] }); }

// Read the diagram image
const imgPath = "/home/z/my-project/download/bloom_architecture.png";
const imgBuffer = fs.readFileSync(imgPath);
const imgDimensions = imageSize(imgBuffer);
// Scale to fit page width (max ~450pt for A4 with margins)
const maxW = 450;
const scale = maxW / imgDimensions.width;
const imgW = Math.round(imgDimensions.width * scale);
const imgH = Math.round(imgDimensions.height * scale);

const doc = new Document({
  creator: "Bloom", title: "Bloom SIEM Security Design Architecture",
  styles: { default: { document: { run: { font: FONT, size: SZ }, paragraph: { spacing: { line: 312 } } } } },
  numbering: { config: [
    { reference: "nl", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "bl", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: [
      // ======== HEADER ========
      center("University of Information Technology", 28),
      center("Faculty of Computer Systems and Technologies", 26),
      center("Network & Internet Security (CST-8415)", 26),
      empty(),
      center("Security Design Architecture", 28),
      center("Bloom SIEM: Real-Time Security Monitoring with AI-Driven Threat Detection and Automated Response", 24),
      empty(),
      p("Student: \u3010Student Name\u3011", { bold: true }),
      p("Student ID: \u3010Student ID\u3011", { bold: true }),
      p("Major: Cyber Security (Semester 8)", { bold: true }),
      p("Supervisor: \u3010Supervisor Name\u3011", { bold: true }),
      empty(),

      // ======== SECURITY DESIGN ARCHITECTURE ========
      h1("Security Design Architecture"),

      // Embed the architecture diagram
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 200, after: 200 },
        children: [new ImageRun({
          data: imgBuffer,
          transformation: { width: imgW, height: imgH },
          type: 'png',
        })],
      }),
      empty(),

      // ======== ARCHITECTURE COMPONENTS ========
      h1("Architecture Components"),

      p("Host System", { bold: true }),
      p("The application server runs on Node.js 24 with Next.js 16, deployed on Vercel. It provides the web dashboard, API endpoints, and detection engine. SQLite is used as the database via Prisma ORM for zero-configuration deployment."),
      empty(),

      p("Client Integration Layer", { bold: true }),
      p("Connected websites integrate via lightweight middleware:"),
      bul("Next.js Middleware \u2014 calls Bloom's evaluate API on every request, returns 403 if blocked."),
      bul("HTML Script Tag \u2014 tracks pageviews, form inputs, and button clicks on any website."),
      bul("PHP / Express \u2014 server-side integration for WordPress, Laravel, and Node.js apps."),
      empty(),

      p("Ingestion and Evaluation", { bold: true }),
      p("Two API endpoints handle incoming traffic:"),
      bul("POST /api/sdk/evaluate \u2014 synchronous threat check (blocklist, geo, sessions, WAF rules). Returns ALLOW or BLOCK within 800ms."),
      bul("POST /api/sdk/ingest \u2014 logs events with IP geolocation, bot detection, SQLi/XSS pattern matching, and country rule enforcement."),
      empty(),

      p("Detection Rule Engine", { bold: true }),
      p("Six MITRE ATT&CK-mapped detection rules run on every batch of ingested events:"),
      empty(),

      // Detection rules table as text (simple, like the reference)
      bul("Brute Force (T1110) \u2014 5+ failed logins from same IP in 10 min \u2192 Block IP + Telegram + AI"),
      bul("SQL Injection (T1190) \u2014 UNION SELECT, OR 1=1, DROP TABLE patterns \u2192 Block IP + Telegram + AI"),
      bul("XSS (T1059) \u2014 <script>, javascript:, onerror= payloads \u2192 Block IP + Telegram + AI"),
      bul("Malware Upload (T1204) \u2014 double extension, hash match \u2192 Block + Revoke Session + Quarantine"),
      bul("Route Scanning (T1595) \u2014 5+ 404/403 from same IP \u2192 Telegram + AI"),
      bul("Session Replication (T1078) \u2014 same session from multiple IPs \u2192 Revoke Session + Telegram + AI"),
      empty(),

      p("AI Analyst Verdict", { bold: true }),
      p("After a rule fires, the AI analyst (Z.ai GLM-4.6) generates a confidence-scored verdict (0-100%), summary, rationale, key findings, and recommended actions. Falls back to rule-based scoring if the LLM is unreachable."),
      empty(),

      p("Automated Response", { bold: true }),
      p("Playbook executes after detection:"),
      num("Create alert with MITRE tactic and technique ID."),
      num("AI analyst generates confidence score and recommendations."),
      num("Block IP via blocklist (middleware returns 403 on next request)."),
      num("Revoke session (middleware polls revocation list every 5 seconds)."),
      num("Send Telegram alert with Approve/Deny inline buttons."),
      empty(),

      p("Site Discovery", { bold: true }),
      p("Playwright headless Chromium crawls connected sites, renders JavaScript, clicks buttons to discover hidden forms, and extracts all routes, inputs, buttons, and links from the rendered DOM."),
      empty(),

      p("Domain Analysis", { bold: true }),
      bul("DNS Resolution \u2014 A, CNAME, MX, NS, TXT records via Node.js dns module."),
      bul("SSL Certificate \u2014 issuer, validity, days until expiry via tls.connect."),
      bul("HTTP Reachability \u2014 status code, response time, server header via fetch."),
      bul("TCP Port Scanning \u2014 ports 22, 80, 443, 3000, 3306, 5432, 6379, 8080, 9200 via net.createConnection."),
      empty(),

      p("Threat Intelligence", { bold: true }),
      p("Resources include:"),
      bul("MITRE ATT&CK Framework \u2014 858 techniques loaded, 11 actively detected."),
      bul("ip-api.com \u2014 IP geolocation for country-based blocking (24h cache)."),
      bul("Telegram Bot API \u2014 real-time alerts with webhook-based Approve/Deny."),
      empty(),

      p("Presentation Layer", { bold: true }),
      p("Dark-themed dashboard with 17 routed pages including Command Home, Traffic Overview, Live Logs, Reports, Alerts, Automation, and MITRE ATT&CK matrix. Real-time activity feed via Server-Sent Events."),
    ],
  }],
});

const OUTPUT = "/home/z/my-project/download/Bloom_SIEM_Design_Architecture.docx";
Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(OUTPUT, buf);
  console.log(`Generated ${OUTPUT} (${(buf.length / 1024).toFixed(1)} KB)`);
});
