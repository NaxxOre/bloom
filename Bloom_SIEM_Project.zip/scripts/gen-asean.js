const {
  Document, Packer, Paragraph, TextRun, AlignmentType,
  LevelFormat, HeadingLevel, Table, TableRow, TableCell,
  WidthType, BorderStyle, ShadingType, TableLayoutType,
} = require("docx");
const fs = require("fs");

const FONT = { ascii: "Times New Roman", eastAsia: "Times New Roman" };
const SZ = 24; const H1 = 32; const H2 = 28;
const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "808080" };
const allCellBorders = { top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder, insideHorizontal: cellBorder, insideVertical: cellBorder };

function p(text, opts = {}) {
  return new Paragraph({ alignment: opts.align || AlignmentType.JUSTIFIED, spacing: { after: opts.after ?? 80, line: 312 },
    children: [new TextRun({ text, size: opts.size || SZ, font: FONT, bold: opts.bold, italics: opts.italics, color: opts.color })] });
}
function h1(text) { return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 200 }, children: [new TextRun({ text, bold: true, size: H1, font: FONT })] }); }
function h2(text) { return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 280, after: 160 }, children: [new TextRun({ text, bold: true, size: H2, font: FONT })] }); }
function center(text, sz = SZ, bold = true) { return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80, line: 312 }, children: [new TextRun({ text, size: sz, font: FONT, bold })] }); }
function bul(text) { return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "bl", level: 0 }, spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] }); }
function num(text) { return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "nl", level: 0 }, spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] }); }
function empty() { return new Paragraph({ spacing: { after: 60 }, children: [] }); }
function tCell(text, opts = {}) {
  return new TableCell({ width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
    shading: opts.shading ? { type: ShadingType.CLEAR, fill: opts.shading } : undefined, margins: { top: 80, bottom: 80, left: 100, right: 100 },
    children: [new Paragraph({ alignment: opts.align || AlignmentType.LEFT, spacing: { line: 280 },
      children: [new TextRun({ text, size: opts.size || 22, font: FONT, bold: opts.bold, color: opts.color })] })] });
}
function makeTable(headers, rows, widths) {
  const headerRow = new TableRow({ tableHeader: true, cantSplit: true, children: headers.map((h, i) => tCell(h, { width: widths[i], shading: "1F4E79", color: "FFFFFF", bold: true, align: AlignmentType.CENTER })) });
  const dataRows = rows.map((row, ri) => new TableRow({ cantSplit: true, children: row.map((cell, ci) => tCell(cell, { width: widths[ci], shading: ri % 2 ? "D9E2F3" : undefined })) }));
  return new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, layout: TableLayoutType.FIXED, borders: allCellBorders, rows: [headerRow, ...dataRows] });
}

const doc = new Document({
  creator: "Bloom", title: "ASEAN GEO FUSION 2026 Project Setup",
  styles: { default: { document: { run: { font: FONT, size: SZ }, paragraph: { spacing: { line: 312 } } } } },
  numbering: { config: [
    { reference: "nl", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "bl", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: [
      center("ASEAN GeoAI FUSION 2026", 36),
      center("Bootcamp & Hackathon", 26),
      empty(),
      center("Project Setup", 28),
      empty(),
      center("ASEAN Shield: GeoAI-Powered Cyber Threat Mapping", 26),
      center("and Incident Response Platform", 22),
      empty(),
      p("Challenge Domain: Security", { align: AlignmentType.CENTER, bold: true, size: 22 }),
      p("Strengthen network resilience, threat mapping and risk visibility.", { align: AlignmentType.CENTER, italics: true, size: 22 }),
      empty(),
      p("Team: \u3010Team Name\u3011", { bold: true }),
      p("Members: \u3010Member 1, Member 2, Member 3\u3011", { bold: true }),
      p("Institution: \u3010University Name\u3011", { bold: true }),
      empty(),

      // ===== IDENTIFIED PROBLEM =====
      h1("1. Identified Problem"),
      p("Southeast Asia is one of the most targeted regions for cyberattacks globally. In 2024, the region accounted for 31% of global cyber incidents, with over 53 million brute-force attacks detected by Kaspersky alone. INTERPOL reported 135,274 ransomware attacks blocked across Southeast Asia \u2014 an average of 400 per day. Indonesia, Vietnam, Thailand, and the Philippines are the hardest hit, with Vietnam and Thailand together accounting for 25% of all regional attacks.", { bold: true }),
      empty(),

      p("The core problems affecting most ASEAN countries are:", { bold: true }),
      empty(),

      h2("Problem 1: Fragmented Threat Visibility"),
      p("ASEAN countries lack a unified, real-time view of cyber threats. Each country's CERT/CSIRT operates in silos \u2014 there is no shared platform where Myanmar, Vietnam, Indonesia, and the Philippines can see the same attack campaign targeting multiple countries simultaneously. A phishing campaign originating from Cambodia may hit Laos, Vietnam, and Myanmar on the same day, but each country responds independently with no shared intelligence."),

      h2("Problem 2: No Geographic Threat Mapping"),
      p("Current SIEM tools show IP addresses and log entries, but they do not visualize WHERE attacks come from geographically. When an ASEAN SOC analyst sees 1,000 attacks from IP addresses, they cannot quickly identify that 60% originate from a specific region in a neighboring country. There is no heatmap showing which ASEAN provinces or cities are attack hotspots, and no way to correlate submarine cable landing points with attack surges."),

      h2("Problem 3: Slow Incident Response"),
      p("The average time to detect a breach in Southeast Asia is 277 days (IBM Cost of a Data Breach 2024). Most ASEAN organizations still rely on manual log review and email-based alerting. When an attack is detected, the response is delayed because analysts must manually correlate logs, check threat feeds, and decide whether to block an IP \u2014 by which time the attacker has already moved laterally."),

      h2("Problem 4: Critical Infrastructure Vulnerability"),
      p("In February 2023, all five submarine cables connecting Vietnam to the global internet malfunctioned simultaneously, causing massive disruptions. ASEAN's critical infrastructure \u2014 submarine cables, power grids, telecom towers \u2014 is increasingly targeted. There is no platform that monitors these assets in real-time, detects when they are under attack, and maps the geographic impact of infrastructure disruptions."),

      h2("Problem 5: AI Not Applied to Regional Threat Intelligence"),
      p("AI is used for generic threat detection, but no platform applies AI specifically to ASEAN threat patterns \u2014 such as detecting when an attack campaign follows the region's submarine cable routes, or when botnet activity spikes in countries with known APT groups. The AI does not understand ASEAN-specific context like the MITRE ATT&CK techniques most commonly used against Southeast Asian government and telecom sectors."),
      empty(),

      // ===== PROPOSED SOLUTION =====
      h1("2. Proposed Solution"),
      p("ASEAN Shield is a GeoAI-powered cyber threat mapping and incident response platform that fuses real-time network traffic monitoring, geospatial threat visualization, and AI-driven automated response. It addresses all five problems above:", { bold: true }),
      empty(),

      makeTable(
        ["Problem", "How ASEAN Shield Solves It"],
        [
          ["Fragmented threat visibility", "Unified dashboard where connected ASEAN websites feed real-time traffic to a shared platform. SOC analysts across Myanmar, Vietnam, and Indonesia see the same attack campaigns in real-time."],
          ["No geographic threat mapping", "Interactive ASEAN map showing attack origins as geographic heatmaps. Each attacking IP is geolocated and plotted on the map, with country-level risk scoring and submarine cable landing point correlation."],
          ["Slow incident response", "AI analyst generates confidence-scored verdicts (0-100%) within 5 seconds of detection. Automated response playbook blocks IPs, revokes sessions, and sends Telegram alerts with Approve/Deny buttons \u2014 reducing response time from days to seconds."],
          ["Critical infrastructure vulnerability", "Domain analysis module monitors ASEAN infrastructure (DNS, SSL certs, port status) and alerts when critical assets go down. Submarine cable landing point monitoring detects connectivity disruptions."],
          ["AI not applied to regional threats", "MITRE ATT&CK detection rules mapped to techniques most common in ASEAN (T1110 brute force, T1190 SQLi, T1071 C2 beaconing). AI understands ASEAN context \u2014 it factors in the source country's threat profile when scoring confidence."],
        ],
        [25, 75]
      ),
      empty(),

      // ===== PROJECT NAME =====
      h1("3. Project Name"),
      p("ASEAN Shield: GeoAI-Powered Cyber Threat Mapping and Incident Response Platform"),
      p("A real-time platform that ingests web traffic from connected ASEAN sites, detects threats using MITRE ATT&CK rules, maps attack origins geographically across ASEAN, and automates response with AI-driven confidence scoring.", { italics: true }),
      empty(),

      // ===== PROJECT OBJECTIVE =====
      h1("4. Project Objective"),
      p("To build a production-ready, open-source GeoAI platform that visualizes cyber threats on an interactive ASEAN map and automates incident response, specifically addressing the fragmented threat visibility and slow response times plaguing Southeast Asian network infrastructure."),
      empty(),
      num("Ingest real-time web traffic from connected ASEAN websites via lightweight middleware."),
      num("Geolocate every attacking IP and plot it on an interactive ASEAN geographic heatmap."),
      num("Detect threats using 6 MITRE ATT&CK-mapped rules (brute force, SQLi, XSS, malware, route scanning, session replication)."),
      num("Generate AI-driven confidence-scored verdicts using LLM APIs with ASEAN threat context."),
      num("Automate response: block IPs at the edge, revoke sessions, quarantine files, send Telegram alerts with Approve/Deny."),
      num("Perform deep site discovery (Playwright) to map routes, input fields, and buttons on connected ASEAN sites."),
      num("Monitor ASEAN critical infrastructure (DNS, SSL, ports, submarine cable landing points)."),
      num("Provide risk dashboards with country-level threat scores, top attacking IPs per country, and MITRE ATT&CK coverage."),
      empty(),

      // ===== PROJECT AGENDA / WORK PLAN =====
      h1("5. Project Agenda / Work Plan"),
      empty(),
      makeTable(
        ["Phase", "Timeline", "Activities", "Deliverables"],
        [
          ["Phase 1: Core Platform", "Weeks 1-2", "Build Next.js dashboard with 17 pages. Deploy on Vercel. Set up Prisma + SQLite with 20 models.", "Working dashboard + DB schema"],
          ["Phase 2: Traffic Pipeline", "Weeks 3-4", "Build SDK middleware (Next.js/HTML/PHP). Implement ingestion + evaluation APIs with CORS + IP geolocation.", "Connected site pipeline + geo-tagged events"],
          ["Phase 3: GeoAI Threat Map", "Weeks 5-6", "Build interactive ASEAN map with country heatmaps, attack origin plotting, submarine cable overlay, and country risk scoring.", "ASEAN threat map + geo-visualization"],
          ["Phase 4: Detection + AI", "Weeks 7-8", "Implement 6 MITRE ATT&CK rules. Build AI analyst (GLM-4.6) with confidence scoring. Load all 858 ATT&CK techniques.", "Detection engine + AI verdicts + MITRE matrix"],
          ["Phase 5: Automation", "Weeks 9-10", "Build country-based blocking, session revocation, Telegram bot with Approve/Deny webhook, and automated response playbooks.", "Country blocking + Telegram + playbooks"],
          ["Phase 6: Infrastructure Monitor", "Weeks 11-12", "Add domain analysis (DNS, SSL, ports), submarine cable monitoring, site discovery (Playwright deep crawl).", "Infrastructure monitoring + site scanner"],
          ["Phase 7: Testing + Demo", "Weeks 13-14", "End-to-end testing on real ASEAN websites. Performance optimization. Final documentation and live demo.", "Test report + documentation + demo"],
        ],
        [15, 12, 43, 30]
      ),
      empty(),

      // ===== EXPECTED OUTCOMES =====
      h1("6. Expected Outcome"),
      bul("A working GeoAI platform deployed on Vercel, ingesting real traffic from connected ASEAN websites."),
      bul("Interactive ASEAN threat map showing live attack origins as geographic heatmaps across all 10 ASEAN countries."),
      bul("Country-level risk scoring: each ASEAN country has a dynamic risk score based on attack volume, type, and origin."),
      bul("AI-generated confidence-scored verdicts on every alert within 5 seconds."),
      bul("Automated IP blocking enforced by middleware (HTTP 403) for real-time threat containment."),
      bul("MITRE ATT&CK coverage: all 858 techniques loaded, 11+ actively detected with ASEAN-specific detection rules."),
      bul("Telegram bot with working Approve/Deny inline buttons for admin approval of automated actions."),
      bul("Critical infrastructure monitoring: DNS, SSL certificates, open ports, and submarine cable landing point status."),
      bul("Deep site discovery reports for connected ASEAN sites (routes, input fields, buttons, inaccessible paths)."),
      bul("Open-source codebase on GitHub (MIT license) for ASEAN-wide adoption by CERTs, universities, and SMEs."),
      empty(),

      // ===== ASEAN IMPACT =====
      h1("7. Why This Matters for ASEAN"),
      p("ASEAN countries face over 53 million cyberattacks annually, with Indonesia, Vietnam, Thailand, and the Philippines bearing the brunt. The region accounts for 31% of global cyber incidents despite having only 8.5% of the world's population. The average breach costs Southeast Asian organizations $2.7 million, and detection takes 277 days.", { bold: true }),
      empty(),
      p("ASEAN Shield addresses this by providing a platform that any ASEAN country can deploy for free. A university in Myanmar can connect their website today and immediately see where attacks are coming from on the ASEAN map. A CERT in Vietnam can share threat intelligence with Laos in real-time. A small business in the Philippines can get AI-powered threat verdicts that previously required a $50,000/year Splunk license."),
      empty(),
      p("The GeoAI fusion is what makes this project uniquely suited for ASEAN GEO FUSION 2026 \u2014 it combines geospatial intelligence (mapping attack origins across ASEAN geography) with AI (confidence-scored verdicts and automated response) to solve a real problem that affects every ASEAN member state."),
      empty(),

      // ===== TECH STACK =====
      h1("8. Technology Stack"),
      bul("Next.js 16 + TypeScript + Tailwind CSS 4 \u2014 dashboard with 17 routed pages"),
      bul("Prisma ORM + SQLite \u2014 20 models, zero-configuration"),
      bul("Z.ai GLM-4.6 \u2014 AI analyst for confidence-scored verdicts"),
      bul("ip-api.com \u2014 IP geolocation for ASEAN attack origin mapping"),
      bul("Playwright (headless Chromium) \u2014 deep site crawler for SPA rendering"),
      bul("Node.js dns/tls/net \u2014 real DNS, SSL, port scanning on ASEAN infrastructure"),
      bul("Server-Sent Events \u2014 real-time threat feed"),
      bul("Telegram Bot API + Webhook \u2014 alerts with Approve/Deny buttons"),
      bul("Interactive map (Leaflet/Mapbox) \u2014 ASEAN geographic threat visualization"),
      bul("Vercel + GitHub \u2014 deployment and open-source distribution"),
    ],
  }],
});

const OUTPUT = "/home/z/my-project/download/ASEAN_GEO_FUSION_2026_Project_Setup.docx";
Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(OUTPUT, buf); console.log(`Generated ${OUTPUT} (${(buf.length/1024).toFixed(1)} KB)`); });
