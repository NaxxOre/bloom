/* eslint-disable @typescript-eslint/no-require-imports */
const { PrismaClient } = require('@prisma/client')

const db = new PrismaClient()

const SAMPLE_IPS = [
  '185.220.101.45', '193.27.228.142', '45.155.205.83', '91.219.236.166',
  '194.169.175.10', '103.97.176.30', '212.193.30.25', '167.94.138.44',
  '198.235.24.34', '139.59.8.173', '51.158.144.21', '92.255.85.42',
]

const MITRE_TACTICS = [
  'Reconnaissance', 'Resource Development', 'Initial Access', 'Execution',
  'Persistence', 'Privilege Escalation', 'Defense Evasion', 'Credential Access',
  'Discovery', 'Lateral Movement', 'Collection', 'Command & Control',
  'Exfiltration', 'Impact'
]

const ALERT_TITLES = [
  { title: 'Brute Force SSH Login Detected', severity: 'high', tactic: 'Credential Access', technique: 'T1110', source: 'network' },
  { title: 'Suspicious PowerShell Encoded Command', severity: 'high', tactic: 'Execution', technique: 'T1059.001', source: 'endpoint' },
  { title: 'C2 Beacon to Known Malicious Host', severity: 'critical', tactic: 'Command & Control', technique: 'T1071', source: 'network' },
  { title: 'Mimikatz Credential Dump Detected', severity: 'critical', tactic: 'Credential Access', technique: 'T1003', source: 'endpoint' },
  { title: 'Unusual Data Exfiltration Pattern', severity: 'high', tactic: 'Exfiltration', technique: 'T1041', source: 'behavior' },
  { title: 'Port Scan from External Source', severity: 'low', tactic: 'Reconnaissance', technique: 'T1046', source: 'external' },
  { title: 'New Service Created on Host', severity: 'medium', tactic: 'Persistence', technique: 'T1543.003', source: 'endpoint' },
  { title: 'Failed Login Storm (50+ attempts)', severity: 'medium', tactic: 'Credential Access', technique: 'T1110.001', source: 'external' },
  { title: 'Suspicious Registry Modification', severity: 'medium', tactic: 'Defense Evasion', technique: 'T1112', source: 'endpoint' },
  { title: 'Anomalous User Behavior - Off Hours', severity: 'medium', tactic: 'Discovery', technique: 'T1087', source: 'behavior' },
  { title: 'Malware Signature Match - Trojan', severity: 'critical', tactic: 'Execution', technique: 'T1204', source: 'endpoint' },
  { title: 'DNS Tunneling Suspected', severity: 'high', tactic: 'Command & Control', technique: 'T1071.004', source: 'network' },
  { title: 'Privileged Account Created', severity: 'high', tactic: 'Persistence', technique: 'T1136', source: 'endpoint' },
  { title: 'Lateral Movement via SMB', severity: 'high', tactic: 'Lateral Movement', technique: 'T1021.002', source: 'network' },
  { title: 'Defense Evasion - AV Service Stopped', severity: 'critical', tactic: 'Defense Evasion', technique: 'T1562.001', source: 'endpoint' },
]

const HOSTS = [
  'web-prod-01', 'web-prod-02', 'db-prod-01', 'db-prod-02', 'app-prod-01',
  'app-prod-02', 'mail-srv-01', 'vpn-gw-01', 'dc-01', 'dc-02',
  'fileshare-01', 'bastion-01', 'k8s-master-01', 'k8s-worker-01', 'k8s-worker-02',
  'jump-host-01', 'analytics-01', 'monitor-01', 'backup-srv-01', 'logging-01',
]

const LOG_SOURCES = ['firewall', 'endpoint', 'auth', 'network', 'cloud', 'dns']
const LOG_SEVERITIES = ['info', 'low', 'medium', 'high', 'critical']
const OS_LIST = ['Ubuntu 22.04', 'Windows Server 2022', 'CentOS 8', 'Debian 12', 'RHEL 9', 'Windows 11']

function random(arr) { return arr[Math.floor(Math.random() * arr.length)] }
function randomInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min }
function randomDate(daysBack, hoursBack = 0) {
  const d = new Date()
  d.setDate(d.getDate() - daysBack)
  d.setHours(d.getHours() - hoursBack)
  d.setMinutes(d.getMinutes() - randomInt(0, 60))
  return d
}

async function main() {
  console.log('Clearing existing data...')
  await db.autoAction.deleteMany()
  await db.autoActionRule.deleteMany()
  await db.investigation.deleteMany()
  await db.alert.deleteMany()
  await db.log.deleteMany()
  await db.agent.deleteMany()
  await db.asset.deleteMany()
  await db.intelligenceConfig.deleteMany()
  await db.dataConnector.deleteMany()
  await db.complianceControl.deleteMany()
  await db.finding.deleteMany()

  const config = await db.intelligenceConfig.create({
    data: {
      heartbeatInterval: 5,
      offlineThreshold: 15,
      autoTriageEnabled: true,
      aiActionsEnabled: true,
      correlationWindow: 10,
      logRetentionDays: 90,
      alertRetentionDays: 365,
      minSeverityForAuto: 'high',
    }
  })
  console.log('Created intelligence config:', config.id)

  console.log('Creating agents...')
  for (const host of HOSTS) {
    const isOnline = Math.random() > 0.15
    await db.agent.create({
      data: {
        hostname: host,
        ipAddress: `10.0.${randomInt(1, 50)}.${randomInt(2, 254)}`,
        os: random(OS_LIST),
        status: isOnline ? 'online' : (Math.random() > 0.5 ? 'degraded' : 'offline'),
        lastSeen: randomDate(0, isOnline ? 0 : randomInt(1, 12)),
        version: `2.4.${randomInt(0, 3)}`,
        installedAt: randomDate(randomInt(30, 180)),
      }
    })
  }
  const agents = await db.agent.findMany()

  console.log('Creating assets...')
  for (const host of HOSTS) {
    await db.asset.create({
      data: {
        name: host,
        type: random(['server', 'endpoint', 'container', 'cloud', 'network_device']),
        ipAddress: `10.0.${randomInt(1, 50)}.${randomInt(2, 254)}`,
        os: random(OS_LIST),
        location: random(['US-East-1', 'US-West-2', 'EU-West-1', 'AP-South-1', 'On-Prem']),
        criticality: random(['low', 'medium', 'high', 'critical']),
        owner: random(['secops', 'infra', 'platform', 'data-team']),
        lastSeen: randomDate(0, randomInt(0, 2)),
      }
    })
  }

  console.log('Creating logs (sample of 3000)...')
  const logBatch = []
  for (let i = 0; i < 3000; i++) {
    logBatch.push({
      agentId: Math.random() > 0.2 ? random(agents).id : null,
      source: random(LOG_SOURCES),
      severity: Math.random() > 0.85 ? random(['high', 'critical']) : random(LOG_SEVERITIES),
      message: random([
        'TCP connection from external host',
        'SSH authentication failed',
        'HTTP request to suspicious domain',
        'File modified in system directory',
        'User login from new location',
        'DNS query to known DGA domain',
        'Firewall rule blocked connection',
        'Process spawned with elevated privileges',
        'Outbound HTTPS connection',
        'Failed privilege escalation attempt',
        'New listening port opened',
        'Scheduled task created',
        'Powershell script executed',
        'Network share accessed',
        'User added to admin group',
      ]),
      srcIp: Math.random() > 0.5 ? random(SAMPLE_IPS) : `10.0.${randomInt(1,50)}.${randomInt(2,254)}`,
      dstIp: `10.0.${randomInt(1,50)}.${randomInt(2,254)}`,
      dstPort: random([22, 80, 443, 3389, 445, 53, 8080, 5432, 3306, 6379]),
      protocol: random(['TCP', 'UDP', 'ICMP', 'HTTPS']),
      timestamp: randomDate(0, randomInt(0, 48)),
    })
  }
  await db.log.createMany({ data: logBatch })
  console.log('Created', logBatch.length, 'logs')

  console.log('Creating alerts...')
  const alertBatch = []
  for (let i = 0; i < 250; i++) {
    const tmpl = random(ALERT_TITLES)
    const created = randomDate(randomInt(0, 30), randomInt(0, 12))
    const age = Date.now() - created.getTime()
    let status = 'new'
    if (age > 1000 * 60 * 60 * 12) status = Math.random() > 0.3 ? 'triaged' : 'new'
    if (age > 1000 * 60 * 60 * 24) status = Math.random() > 0.5 ? 'escalated' : 'triaged'
    if (age > 1000 * 60 * 60 * 48) status = Math.random() > 0.4 ? 'closed' : 'escalated'
    alertBatch.push({
      title: tmpl.title,
      description: `${tmpl.title} — detected by ${random(['correlation engine', 'behavioral analytics', 'signature match', 'AI threat model'])}. Source IP: ${random(SAMPLE_IPS)}. Mitre: ${tmpl.tactic} (${tmpl.technique}).`,
      severity: tmpl.severity,
      status,
      mitreTactic: tmpl.tactic,
      mitreTechnique: tmpl.technique,
      source: tmpl.source,
      srcIp: random(SAMPLE_IPS),
      dstIp: `10.0.${randomInt(1,50)}.${randomInt(2,254)}`,
      agentId: Math.random() > 0.3 ? random(agents).id : null,
      triggeredBy: Math.random() > 0.6 ? 'ai' : (Math.random() > 0.5 ? 'rule' : 'correlation'),
      createdAt: created,
    })
  }
  await db.alert.createMany({ data: alertBatch })
  console.log('Created', alertBatch.length, 'alerts')

  console.log('Creating investigations...')
  const createdAlerts = await db.alert.findMany({ where: { status: { in: ['escalated', 'closed'] } }, take: 80 })
  for (const a of createdAlerts) {
    const malicious = Math.random() < 0.1
    await db.investigation.create({
      data: {
        alertId: a.id,
        title: `Investigation: ${a.title}`,
        status: malicious ? (Math.random() > 0.5 ? 'contained' : 'closed') : random(['open', 'in_progress', 'closed']),
        severity: a.severity,
        assignee: random(['analyst-jane', 'analyst-mike', 'soc-lead', 'ai-responder']),
        summary: malicious
          ? 'Confirmed malicious activity. Auto-response actions executed. Threat contained.'
          : 'Investigation in progress. Initial indicators suggest benign activity. Monitoring continues.',
        malicious,
        createdAt: a.createdAt,
      }
    })
  }

  console.log('Creating AI auto-action rules...')
  const rules = [
    { name: 'Auto-Block Repeated Offender IPs', description: 'Block source IP after 3 high-severity alerts within 10 minutes', trigger: 'source_ip_repeat', action: 'block_ip', cooldownMin: 30 },
    { name: 'Isolate Compromised Host', description: 'Network-isolate endpoint on critical malware detection', trigger: 'malware_detected', action: 'isolate_host', cooldownMin: 60 },
    { name: 'Disable brute-forced accounts', description: 'Disable user account after 50+ failed login attempts', trigger: 'brute_force', action: 'disable_user', cooldownMin: 15 },
    { name: 'Quarantine malicious files', description: 'Auto-quarantine files matching known malware signatures', trigger: 'malware_detected', action: 'quarantine_file', cooldownMin: 5 },
    { name: 'Auto-create critical incident ticket', description: 'Open incident ticket for any critical-severity alert', trigger: 'alert_severity', action: 'create_ticket', cooldownMin: 10 },
    { name: 'Notify SOC team on C2 beacon', description: 'Page on-call SOC engineer when C2 beaconing detected', trigger: 'mitre_tactic', action: 'notify', cooldownMin: 5 },
    { name: 'Block C2 destination IPs', description: 'Auto-add C2 IPs to firewall blocklist', trigger: 'mitre_tactic', action: 'block_ip', cooldownMin: 30 },
  ]
  for (const r of rules) {
    await db.autoActionRule.create({
      data: {
        ...r,
        enabled: Math.random() > 0.15,
        condition: JSON.stringify({ minSeverity: 'high' }),
        triggerCount: randomInt(5, 250),
        lastFiredAt: Math.random() > 0.3 ? randomDate(0, randomInt(0, 8)) : null,
      }
    })
  }

  console.log('Creating auto-action history...')
  const allAlerts = await db.alert.findMany({ take: 100 })
  const allRules = await db.autoActionRule.findMany()
  const actionTargets = {
    block_ip: SAMPLE_IPS,
    isolate_host: HOSTS,
    disable_user: ['admin', 'svc_account', 'analyst-jane', 'developer-01', 'guest'],
    quarantine_file: ['a1b2c3d4e5f6...', 'f9e8d7c6b5a4...', '9a8b7c6d5e4f...'],
    create_ticket: ['INC-2026-001', 'INC-2026-002', 'INC-2026-003'],
    notify: ['soc-team@bloom.io', 'oncall@bloom.io'],
  }
  for (let i = 0; i < 80; i++) {
    const rule = Math.random() > 0.2 ? random(allRules) : null
    const action = rule?.action || random(['block_ip', 'isolate_host', 'disable_user', 'quarantine_file', 'create_ticket', 'notify'])
    const alert = Math.random() > 0.3 ? random(allAlerts) : null
    await db.autoAction.create({
      data: {
        ruleId: rule?.id || null,
        alertId: alert?.id || null,
        action,
        target: random(actionTargets[action] || ['unknown']),
        status: Math.random() > 0.1 ? 'success' : random(['failed', 'pending', 'rolled_back']),
        details: `AI executed ${action} via rule "${rule?.name || 'manual'}" in response to ${alert?.severity || 'high'} severity event`,
        initiatedBy: Math.random() > 0.85 ? 'user' : 'ai',
        createdAt: randomDate(0, randomInt(0, 12)),
      }
    })
  }

  console.log('Creating data connectors...')
  const connectors = [
    { name: 'Palo Alto Firewall', vendor: 'Palo Alto', type: 'syslog' },
    { name: 'Microsoft Defender for Endpoint', vendor: 'Microsoft', type: 'api' },
    { name: 'AWS CloudTrail', vendor: 'AWS', type: 'cloud' },
    { name: 'Okta Identity', vendor: 'Okta', type: 'api' },
    { name: 'CrowdStrike Falcon', vendor: 'CrowdStrike', type: 'agent' },
    { name: 'Windows Event Logs', vendor: 'Microsoft', type: 'agent' },
    { name: 'Cisco ASA', vendor: 'Cisco', type: 'syslog' },
    { name: 'GCP Audit Logs', vendor: 'Google', type: 'cloud' },
    { name: 'Kubernetes Audit', vendor: 'CNCF', type: 'api' },
    { name: 'Splunk Forwarder', vendor: 'Splunk', type: 'agent' },
  ]
  for (const c of connectors) {
    await db.dataConnector.create({
      data: {
        ...c,
        status: Math.random() > 0.15 ? 'active' : random(['paused', 'error']),
        eventsPerSec: Math.round(Math.random() * 5000) / 10,
        lastEvent: randomDate(0, 0),
      }
    })
  }

  console.log('Creating compliance controls...')
  const controls = [
    { framework: 'NIST', controlId: 'AC-1', title: 'Access Control Policy', category: 'Access Control' },
    { framework: 'NIST', controlId: 'AU-2', title: 'Audit Events', category: 'Audit' },
    { framework: 'NIST', controlId: 'AU-6', title: 'Audit Review, Analysis, Reporting', category: 'Audit' },
    { framework: 'NIST', controlId: 'IR-4', title: 'Incident Handling', category: 'Incident Response' },
    { framework: 'NIST', controlId: 'SI-3', title: 'Malicious Code Protection', category: 'System Protection' },
    { framework: 'NIST', controlId: 'SC-7', title: 'Boundary Protection', category: 'Communications' },
    { framework: 'ISO27001', controlId: 'A.9', title: 'Access Control', category: 'Access Management' },
    { framework: 'ISO27001', controlId: 'A.12.4', title: 'Logging and Monitoring', category: 'Operations' },
    { framework: 'ISO27001', controlId: 'A.16.1', title: 'Management of Incidents', category: 'Incident Management' },
    { framework: 'PCI-DSS', controlId: '10.2', title: 'Audit Trails', category: 'Logging' },
    { framework: 'PCI-DSS', controlId: '11.5', title: 'File Integrity Monitoring', category: 'Monitoring' },
    { framework: 'SOC2', controlId: 'CC7.2', title: 'System Operations Monitoring', category: 'Monitoring' },
    { framework: 'SOC2', controlId: 'CC7.3', title: 'Incident Response Procedures', category: 'Incident Response' },
  ]
  for (const c of controls) {
    await db.complianceControl.create({
      data: {
        ...c,
        description: `${c.title} — ${c.framework} requirement for ${c.category.toLowerCase()} controls.`,
        status: Math.random() > 0.2 ? 'compliant' : random(['partial', 'non_compliant', 'not_assessed']),
        lastChecked: randomDate(0, randomInt(0, 24)),
      }
    })
  }

  console.log('Creating findings...')
  const findingTemplates = [
    { title: 'Outdated TLS 1.0 enabled on web-prod-01', severity: 'medium' },
    { title: 'Default credentials on Redis container', severity: 'critical' },
    { title: 'Missing security patches on db-prod-02', severity: 'high' },
    { title: 'Open RDP port on bastion-01 to internet', severity: 'critical' },
    { title: 'Excessive user permissions on fileshare-01', severity: 'medium' },
    { title: 'No MFA enforced on admin account', severity: 'high' },
    { title: 'Weak cipher suite on mail-srv-01', severity: 'low' },
    { title: 'Unencrypted SMB traffic detected', severity: 'medium' },
    { title: 'Stale local admin accounts on dc-02', severity: 'medium' },
    { title: 'Exposed Kubernetes API on public IP', severity: 'critical' },
  ]
  for (const f of findingTemplates) {
    await db.finding.create({
      data: {
        title: f.title,
        description: `${f.title}. Auto-detected during continuous security assessment. Remediation recommended within ${f.severity === 'critical' ? '24' : f.severity === 'high' ? '72' : '168'} hours.`,
        severity: f.severity,
        status: random(['open', 'remediated', 'open', 'open', 'accepted']),
        assetName: random(HOSTS),
        detectedAt: randomDate(randomInt(0, 14)),
      }
    })
  }

  console.log('\n=== SEED COMPLETE ===')
  const counts = {
    agents: await db.agent.count(),
    logs: await db.log.count(),
    alerts: await db.alert.count(),
    investigations: await db.investigation.count(),
    assets: await db.asset.count(),
    autoActionRules: await db.autoActionRule.count(),
    autoActions: await db.autoAction.count(),
    dataConnectors: await db.dataConnector.count(),
    complianceControls: await db.complianceControl.count(),
    findings: await db.finding.count(),
  }
  console.log(counts)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
