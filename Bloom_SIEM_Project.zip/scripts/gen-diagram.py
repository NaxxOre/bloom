import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
import matplotlib.font_manager as fm

fig, ax = plt.subplots(1, 1, figsize=(10, 12))
ax.set_xlim(0, 10)
ax.set_ylim(0, 14)
ax.axis('off')

# Colors
DARK = '#1a1d21'
CARD = '#232629'
ORANGE = '#f39c12'
BLUE = '#4a90e2'
GREEN = '#2ecc71'
RED = '#e74c3c'
PURPLE = '#9b59b6'
WHITE = '#ffffff'
GRAY = '#8e9296'

def box(x, y, w, h, text, color=DARK, textcolor=WHITE, fontsize=9, bold=False):
    rect = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.15", 
                          facecolor=color, edgecolor=color, linewidth=1.5)
    ax.add_patch(rect)
    weight = 'bold' if bold else 'normal'
    ax.text(x + w/2, y + h/2, text, ha='center', va='center',
            fontsize=fontsize, color=textcolor, fontweight=weight, wrap=True)

def arrow(x1, y1, x2, y2, label=''):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=GRAY, lw=1.5))
    if label:
        mx, my = (x1+x2)/2, (y1+y2)/2
        ax.text(mx+0.15, my, label, fontsize=7, color=GRAY, ha='left', va='center')

# ===== Layer 1: Connected Website (Top) =====
box(2.5, 12.5, 5, 0.8, 'Connected Website\n(e.g., yay-thal-woman.vercel.app)', BLUE, WHITE, 9, True)
arrow(5, 12.5, 5, 11.8)

# ===== Layer 2: Bloom Middleware =====
box(2.5, 11, 5, 0.7, 'Bloom Middleware\n(Next.js / HTML Script / PHP / Express)', ORANGE, DARK, 8, True)
arrow(5, 11, 5, 10.3)

# ===== Layer 3: Split - Evaluate + Ingest =====
box(0.3, 9.3, 4.2, 0.8, 'Threat Evaluation\nPOST /api/sdk/evaluate\n(Check blocklist, geo, sessions)', CARD, WHITE, 7)
box(5.5, 9.3, 4.2, 0.8, 'Event Ingestion\nPOST /api/sdk/ingest\n(Log traffic, inputs, files)', CARD, WHITE, 7)

arrow(3.5, 11, 2.4, 10.1, 'Block?')
arrow(6.5, 11, 7.6, 10.1, 'Log')

# Block arrow
arrow(0.3, 9.7, -0.3, 9.7)
box(-1.5, 9.4, 1.5, 0.5, '403 Blocked', RED, WHITE, 7, True)

# ===== Layer 4: Detection Engine + AI =====
arrow(7.6, 9.3, 7.6, 8.6)
box(5.5, 7.8, 4.2, 0.8, 'Detection Rule Engine\n(6 MITRE-mapped rules)\nBrute Force | SQLi | XSS | Malware', PURPLE, WHITE, 7)

arrow(7.6, 7.8, 7.6, 7.1)
box(5.5, 6.3, 4.2, 0.8, 'AI Analyst Verdict\n(Z.ai GLM-4.6)\nConfidence Score + Recommendations', GREEN, DARK, 7, True)

# ===== Layer 5: Evidence Collection =====
arrow(7.6, 6.3, 5, 5.5)
arrow(2.4, 9.3, 5, 5.5)
box(3, 4.7, 4, 0.7, 'Evidence Collection\n(Alerts + Verdicts + IOCs + IPs)', CARD, WHITE, 8, True)

# ===== Layer 6: Split - MITRE + Auto Response =====
arrow(4, 4.7, 2.4, 4)
arrow(6, 4.7, 7.6, 4)

box(0.3, 3.2, 4.2, 0.7, 'MITRE ATT&CK Mapping\n(858 techniques, 11 actively detected)', BLUE, WHITE, 7)
box(5.5, 3.2, 4.2, 0.7, 'Automated Response\n(Block IP | Revoke Session | Quarantine)', RED, WHITE, 7)

# ===== Layer 7: Telegram =====
arrow(7.6, 3.2, 7.6, 2.5)
box(5.5, 1.8, 4.2, 0.7, 'Telegram Bot Alert\n(Approve / Deny buttons)', ORANGE, DARK, 7, True)

# ===== Layer 8: Dashboard (Bottom) =====
arrow(2.4, 3.2, 5, 2)
arrow(7.6, 1.8, 5, 1.3)
box(2.5, 0.3, 5, 0.8, 'Bloom SIEM Dashboard\n(Live Logs + Traffic + Reports + Controls)', DARK, ORANGE, 9, True)

# Save
plt.tight_layout()
plt.savefig('/home/z/my-project/download/bloom_architecture.png', dpi=200, bbox_inches='tight',
            facecolor='#1a1d21', edgecolor='none')
print("Saved architecture diagram")
