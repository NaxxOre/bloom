const {
  Document, Packer, Paragraph, TextRun, AlignmentType,
  LevelFormat, HeadingLevel, Table, TableRow, TableCell,
  WidthType, BorderStyle, ShadingType, TableLayoutType,
} = require("docx");
const fs = require("fs");

const FONT = { ascii: "Times New Roman", eastAsia: "Times New Roman" };
const SZ = 24; const H1 = 32; const H2 = 28;
const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "808080" };
const allCellBorders = { ...cellBorder, top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder, insideHorizontal: cellBorder, insideVertical: cellBorder };

function p(text, opts = {}) {
  return new Paragraph({ alignment: opts.align || AlignmentType.JUSTIFIED, spacing: { after: opts.after ?? 80, line: 312 },
    children: [new TextRun({ text, size: opts.size || SZ, font: FONT, bold: opts.bold, italics: opts.italics, color: opts.color })] });
}
function h1(text) { return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 200 }, children: [new TextRun({ text, bold: true, size: H1, font: FONT })] }); }
function h2(text) { return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 280, after: 160 }, children: [new TextRun({ text, bold: true, size: H2, font: FONT })] }); }
function h3(text) { return new Paragraph({ spacing: { before: 200, after: 100 }, children: [new TextRun({ text, bold: true, size: SZ, font: FONT, color: "1F4E79" })] }); }
function center(text, sz = SZ, bold = true) { return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80, line: 312 }, children: [new TextRun({ text, size: sz, font: FONT, bold })] }); }
function bul(text) { return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "bl", level: 0 }, spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] }); }
function num(text) { return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "nl", level: 0 }, spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] }); }
function empty() { return new Paragraph({ spacing: { after: 60 }, children: [] }); }
function tCell(text, opts = {}) {
  return new TableCell({ width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
    shading: opts.shading ? { type: ShadingType.CLEAR, fill: opts.shading } : undefined, margins: { top: 80, bottom: 80, left: 100, right: 100 },
    children: [new Paragraph({ alignment: opts.align || AlignmentType.LEFT, spacing: { line: 280 },
      children: [new TextRun({ text, size: opts.size || 22, font: FONT, bold: opts.bold, color: opts.color })] })] });
}
function makeTable(headers, rows, widths) {
  const headerRow = new TableRow({ tableHeader: true, cantSplit: true, children: headers.map((h, i) => tCell(h, { width: widths[i], shading: "1F4E79", color: "FFFFFF", bold: true, align: AlignmentType.CENTER })) });
  const dataRows = rows.map((row, ri) => new TableRow({ cantSplit: true, children: row.map((cell, ci) => tCell(cell, { width: widths[ci], shading: ri % 2 ? "D9E2F3" : undefined })) }));
  return new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, layout: TableLayoutType.FIXED, borders: allCellBorders, rows: [headerRow, ...dataRows] });
}

const ideas = [
  {
    name: "1. ASEAN Shield: GeoAI Cyber Threat Heatmap",
    problem: "ASEAN faces 31% of global cyberattacks but has no unified geographic visualization of where attacks originate. SOC analysts see IP addresses but cannot map them to physical locations across ASEAN borders.",
    geoai: "Interactive ASEAN map that plots every attacking IP as a geographic point. AI clusters attack patterns by region and predicts which countries will be targeted next based on historical attack trajectories.",
    data: "Real-time web traffic logs from connected ASEAN websites, IP geolocation data (ip-api.com), MITRE ATT&CK technique mappings, historical INTERPOL/Kaspersky threat reports.",
    impact: "Any ASEAN CERT can deploy this for free and see attacks across the entire region in real-time, enabling cross-border threat intelligence sharing."
  },
  {
    name: "2. Submarine Cable Sentinel: GeoAI Infrastructure Risk Monitor",
    problem: "In 2023-2024, Vietnam lost 5 of 6 submarine cables simultaneously. 44 cable damages reported globally in 2024-2025. ASEAN has no real-time system to monitor cable health, predict failures, or map the cascading impact on internet connectivity.",
    geoai: "Geographic map of all ASEAN submarine cable landing points with real-time health monitoring. AI predicts failure risk based on cable age, geological activity, ship anchor density, and historical outage patterns. When a cable fails, the system maps which ASEAN provinces lose connectivity and predicts traffic rerouting.",
    data: "TeleGeography submarine cable database, earthquake/seaquake data from USGS, AIS ship tracking data near cable routes, ISP outage reports from RIPE Atlas probes.",
    impact: "Telecom regulators in Vietnam, Indonesia, and the Philippines can predict cable failures before they happen and reroute traffic proactively."
  },
  {
    name: "3. PhishGeo: AI-Powered Phishing Geography Tracker",
    problem: "330,000 financial phishing attacks hit Southeast Asia in early 2024 (41% increase). Philippines, Vietnam, Malaysia, and Thailand are top targets. Victims lost SGD 1.1 billion in 2024. There is no system that maps WHERE phishing victims are located and WHERE phishing infrastructure is hosted.",
    geoai: "Map showing phishing attack origins (server locations) AND victim concentrations (by province/city). AI analyzes phishing URL patterns, detects new campaigns geographically, and predicts which ASEAN regions will be targeted next based on language, banking patterns, and social media trends.",
    data: "PhishTank verified phishing URLs, URLhaus malicious URL feeds, Kaspersky spam statistics, ASEAN banking sector data, regional language analysis.",
    impact: "Banks and government agencies can warn citizens in specific provinces before phishing campaigns hit their area."
  },
  {
    name: "4. CellTower Guard: 5G Base Station Anomaly Detector",
    problem: "5G infrastructure across ASEAN is expanding rapidly, but base stations are vulnerable to rogue cell attacks, jamming, and physical tampering. There is no geospatial system that monitors tower health and detects anomalies across a national 5G network.",
    geoai: "Map of all registered 5G cell towers with real-time signal strength monitoring. AI detects rogue towers (IMSI catchers) by comparing signal fingerprints against known tower locations. Anomalies are plotted geographically, showing where attacks are happening in real-time.",
    data: "Telecom regulator tower databases, OpenCelliD crowd-sourced cell tower data, RF signal measurements, drive-test data from telecom operators.",
    impact: "Malaysia's MCMC and Vietnam's MIC can detect rogue cell towers within hours instead of months, protecting millions of subscribers."
  },
  {
    name: "5. RansomRoute: Geographic Ransomware Spread Predictor",
    problem: "135,274 ransomware attacks hit Southeast Asia in 2024 (INTERPOL). Indonesia had the most attacks. There is no system that tracks how ransomware spreads geographically across ASEAN countries and predicts the next target.",
    geoai: "Map showing ransomware infection hotspots across ASEAN. AI analyzes ransomware payment addresses, C2 server locations, and infection timestamps to model the geographic spread pattern. The system predicts which country or city will be hit next based on attack propagation velocity and border-crossing patterns.",
    data: "INTERPOL ransomware reports, blockchain transaction data (ransom payments), C2 server IP geolocations from AbuseIPDB, incident response reports from ASEAN CERTs.",
    impact: "CERTs can proactively warn organizations in predicted target areas before the ransomware campaign reaches them."
  },
  {
    name: "6. DDoS GeoRadar: Distributed Attack Origin Mapper",
    problem: "DDoS attacks against ASEAN surged 92% in 2024 (INTERPOL). When a DDoS attack hits a Vietnamese bank, the security team sees thousands of IPs but cannot visualize the global botnet geography or identify the command infrastructure.",
    geoai: "Real-time world map showing the geographic distribution of DDoS attack sources. AI identifies botnet clusters, correlates them with known IoT device densities in ASEAN countries (compromised routers/cameras), and visualizes the attack topology as a geographic network graph.",
    data: "NetFlow data from ASEAN ISPs, honeypot data from Shadowserver, botnet C2 intelligence from ThreatFox, IoT device census data per ASEAN country.",
    impact: "ISPs can identify which ASEAN countries are harboring the most compromised IoT devices and coordinate cleanup efforts."
  },
  {
    name: "7. BorderNet: Cross-Border Traffic Anomaly Detector",
    problem: "ASEAN has porous digital borders. Attack traffic flows between Myanmar, Thailand, Laos, and Cambodia with no monitoring. Criminal syndicates operate from border regions (e.g., cybercrime compounds in Myanmar's border areas) but there is no geospatial system that maps cross-border attack flows.",
    geoai: "Geographic flow map showing cyber attack traffic between ASEAN countries. AI detects anomalous cross-border traffic patterns (e.g., sudden spike from Cambodia to Vietnam), identifies border-region attack corridors, and flags geographic clusters associated with known cybercrime compounds.",
    data: "BGP routing data from RIPE/RIRs, NetFlow summaries from ASEAN IXPs (Internet Exchange Points), threat intelligence on known cybercrime locations, INTERPOL cybercrime reports.",
    impact: "Law enforcement can visualize where attack traffic crosses borders and target cybercrime infrastructure geographically."
  },
  {
    name: "8. VulnMap ASEAN: Critical Infrastructure Vulnerability Atlas",
    problem: "ASEAN critical infrastructure (power grids, water treatment, telecom hubs) has known vulnerabilities, but there is no geographic atlas that maps which infrastructure assets are exposed, vulnerable, and near attack hotspots.",
    geoai: "Interactive map layering: (1) critical infrastructure locations (power plants, data centers, cable landing points), (2) known CVEs/exploits affecting devices at each location, (3) real-time attack heatmaps. AI calculates a geographic risk score for each infrastructure asset based on its vulnerability profile and proximity to active attack zones.",
    data: "Shodan/Censys exposed device scans, NVD CVE database, ASEAN infrastructure GIS datasets, real-time attack telemetry from honeypots.",
    impact: "Governments can prioritize which infrastructure to patch first based on geographic risk scoring."
  },
  {
    name: "9. GeoScam: AI Social Engineering Campaign Mapper",
    problem: "Scam operations in Southeast Asia (especially Myanmar-Cambodia-Thailand border region) use targeted social engineering. Victims are selected by location, language, and demographic. SGD 1.1 billion lost in 2024 alone. No system maps scam campaigns geographically.",
    geoai: "Map showing scam campaign origins (known compounds), victim distribution by province, and AI-predicted targeting patterns. The system analyzes scam message language, phone number prefixes, and payment app patterns to predict which ASEAN province will be targeted next.",
    data: "INTERPOL scam reports, ASEAN police cybercrime data, WhatsApp/Telegram scam message samples, mobile number portability data, payment app transaction patterns.",
    impact: "Police can issue geo-targeted warnings to citizens in provinces predicted to be hit by the next scam wave."
  },
  {
    name: "10. GridGuard: Power Grid Cyber-Physical Attack Monitor",
    problem: "ASEAN power grids are adopting smart meters and SCADA IoT, creating cyber-physical attack surfaces. A cyberattack on Vietnam's power grid could cascade to Cambodia and Laos. No system monitors both the cyber threats AND the geographic impact of grid disruptions.",
    geoai: "Twin map: (1) cyber threat layer showing attacks targeting SCADA/ICS systems, (2) physical grid layer showing power flow and substation locations. AI correlates cyber attacks with physical grid topology to predict which provinces would lose power if a specific substation's SCADA is compromised.",
    data: "Shodan SCADA device scans, ICS-CERT advisories, ASEAN power grid topology maps, weather/geological data, utility company incident reports.",
    impact: "Energy ministries can simulate cyber-physical attack scenarios and prepare geographic emergency response plans."
  },
  {
    name: "11. MalwareAtlas: AI Malware Propagation Geography",
    problem: "When a new malware strain emerges (e.g., a new ransomware variant), there is no geographic visualization of how it spreads across ASEAN. Security teams react to individual infections without seeing the regional propagation pattern.",
    geoai: "Animated geographic map showing malware spread across ASEAN over time. AI models the propagation velocity (how fast it moves between countries), infection vectors (email vs. USB vs. network), and predicts the next country/city to be infected based on flight routes, trade routes, and network topology.",
    data: "VirusTotal malware submission geolocations, Microsoft Defender telemetry, Kaspersky regional statistics, airline route data (propagation vector), bilateral trade data.",
    impact: "CERTs can issue travel/trade advisories and pre-position malware signatures in predicted target countries."
  },
  {
    name: "12. SatCom Shield: GPS Spoofing & Satellite Interference Mapper",
    problem: "GPS spoofing attacks near ASEAN airports and critical infrastructure are increasing. Aircraft approaching airports in the region have reported GPS interference. No system maps GPS spoofing zones across ASEAN airspace and maritime routes.",
    geoai: "Map overlaying: (1) reported GPS interference zones (red circles), (2) ASEAN flight corridors and shipping lanes, (3) known spoofing equipment locations. AI predicts which flight paths and maritime routes are at highest risk based on interference patterns and geopolitical tensions.",
    data: "Aviation GPS interference reports (ICAO/FAA), ADS-B flight tracking data (FlightRadar24), maritime AIS data, GPS signal monitoring station data.",
    impact: "Aviation authorities can reroute flights away from predicted GPS spoofing zones and warn ships about maritime interference."
  },
  {
    name: "13. SupplyChain GeoRisk: AI Vendor Risk Geography",
    problem: "ASEAN organizations use software/hardware vendors across the region. A compromised vendor in one country (e.g., a Malaysian hosting provider) can cascade attacks to clients in Vietnam, Thailand, and Singapore. No system maps the geographic supply chain risk.",
    geoai: "Network graph map showing vendor-client relationships across ASEAN borders, overlaid with real-time threat data for each vendor's infrastructure. AI calculates a cascading risk score: if Vendor X in Malaysia is compromised, which clients in which countries are affected?",
    data: "SSL certificate data (vendor infrastructure mapping), ASN/BGP routing data, breach disclosure databases, company registry data across ASEAN.",
    impact: "Organizations can visualize their geographic supply chain risk and diversify vendors to avoid single-country concentration."
  },
  {
    name: "14. DroneDefense Geo: Counter-Drone Threat Mapper",
    problem: "Unauthorized drones near ASEAN critical infrastructure (airports, refineries, government buildings) are increasing. Rogue drones can be used for physical attacks, surveillance, or smuggling. No system maps drone incursion patterns geographically.",
    geoai: "Map showing drone detection zones around critical infrastructure with real-time incursion alerts. AI classifies drone types (consumer vs. modified), predicts flight paths, and identifies geographic patterns (e.g., drones always approaching from the same province). The system maps no-fly zone violations and correlates them with cyber attack patterns.",
    data: "RF drone detection sensor data, DJI AeroScope telemetry, ASEAN airport no-fly zone GIS data, critical infrastructure location databases.",
    impact: "Airport security and critical facility operators can visualize drone threat patterns and deploy countermeasures geographically."
  },
  {
    name: "15. CyberClimate: AI Climate-Cyber Attack Correlator",
    problem: "During natural disasters (typhoons, floods) in ASEAN, cyber attacks spike because defenses are down. When Vietnam floods, phishing attacks targeting disaster relief increase. No system correlates climate events with cyber attack patterns geographically.",
    geoai: "Twin-layer map: (1) real-time climate hazard layer (typhoons, floods, earthquakes from weather satellites), (2) cyber attack heatmap. AI correlates disaster events with attack surges, predicts post-disaster phishing campaigns targeting affected provinces, and maps the geographic overlap of climate vulnerability and cyber threat.",
    data: "NASA/NOAA satellite weather data, USGS earthquake feeds, phishing URL feeds (URLhaus), ASEAN disaster management reports, social media disaster keyword monitoring.",
    impact: "Disaster management agencies can pre-deploy cyber defenses in provinces predicted to be hit by post-disaster phishing campaigns."
  },
];

const doc = new Document({
  creator: "Bloom", title: "ASEAN GEO FUSION 2026 — 15 GeoAI Cybersecurity Project Ideas",
  styles: { default: { document: { run: { font: FONT, size: SZ }, paragraph: { spacing: { line: 312 } } } } },
  numbering: { config: [
    { reference: "nl", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "bl", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: [
      center("ASEAN GeoAI FUSION 2026", 36),
      center("Bootcamp & Hackathon", 26),
      empty(),
      center("15 GeoAI + Cybersecurity Project Ideas", 28),
      center("Challenge Domain: Security", 22),
      center("Strengthen network resilience, threat mapping and risk visibility", 20),
      empty(),
      p("Team: \u3010Team Name\u3011    Members: \u3010Member 1, Member 2, Member 3\u3011    Institution: \u3010University Name\u3011", { align: AlignmentType.CENTER, size: 22 }),
      empty(),

      // Research context
      h1("ASEAN Cybersecurity Reality (Research Findings)"),
      p("Before choosing a project idea, it is critical to understand the real cybersecurity problems affecting ASEAN. The following statistics come from INTERPOL, Kaspersky, and IBM reports (2024-2025):", { bold: true }),
      empty(),
      bul("Southeast Asia accounts for 31% of global cyber incidents despite having only 8.5% of the world's population."),
      bul("53 million brute-force attacks detected by Kaspersky in Southeast Asia in 2024."),
      bul("135,274 ransomware attacks blocked by INTERPOL across Southeast Asia in 2024 (average 400/day)."),
      bul("330,000 financial phishing attacks in early 2024 alone (41% increase from 2023). Scam victims lost SGD 1.1 billion in 2024."),
      bul("DDoS attacks surged 92% in 2024. Southeast Asian threat actors increased by 600% from February to mid-2024."),
      bul("Average breach detection time: 277 days. Average breach cost: USD 2.7 million per incident."),
      bul("Most attacked countries: Thailand (27%), Vietnam (21%), Singapore (20%), Indonesia, Philippines, Malaysia."),
      bul("In 2023, all 5 submarine cables connecting Vietnam to the global internet malfunctioned simultaneously."),
      bul("44 publicly reported submarine cable damages globally in 2024-2025, several in ASEAN waters."),
      bul("Cybercrime compounds in Myanmar's border regions operate with impunity, targeting victims across ASEAN."),
      empty(),

      h1("What is GeoAI Fusion?"),
      p("GeoAI = Geospatial Artificial Intelligence. It is the intersection of geographic/spatial data and AI/ML. For the cybersecurity challenge domain, GeoAI fusion means:", { bold: true }),
      bul("Geographic visualization of cyber threats (WHERE attacks come from, WHERE they target)"),
      bul("AI-powered analysis of spatial attack patterns (WHY this region, WHAT comes next)"),
      bul("Correlation of physical infrastructure (cables, towers, power grids) with cyber threats"),
      bul("Predictive modeling of attack propagation across ASEAN geography"),
      bul("Risk scoring that combines physical vulnerability + cyber exposure + geographic context"),
      empty(),

      // THE 15 IDEAS
      h1("15 Project Ideas for ASEAN GEO FUSION 2026"),

      ...ideas.flatMap((idea, idx) => {
        const children = [];
        children.push(h2(idea.name));
        children.push(h3("Problem"));
        children.push(p(idea.problem));
        children.push(h3("GeoAI Solution"));
        children.push(p(idea.geoai));
        children.push(h3("Data Sources"));
        children.push(p(idea.data));
        children.push(h3("Expected Impact"));
        children.push(p(idea.impact));
        children.push(empty());
        return children;
      }),

      // Ranking
      h1("Recommendation: Which Idea to Choose?"),
      p("The judges will evaluate projects on: (1) real ASEAN problem identification, (2) GeoAI fusion (not just AI, not just maps — both combined), (3) scalability across ASEAN, (4) feasibility of prototype, and (5) data availability.", { bold: true }),
      empty(),
      p("Top 3 recommendations based on judge appeal + feasibility:", { bold: true }),
      empty(),
      makeTable(
        ["Rank", "Project", "Why Judges Will Love It"],
        [
          ["#1", "Idea 2: Submarine Cable Sentinel", "Directly addresses ASEAN telecom infrastructure (the hackathon's core theme). Combines physical cable geography + AI failure prediction. Real, visible problem (Vietnam lost all 5 cables). Data is available (TeleGeography, USGS, AIS). Scalable to all ASEAN countries with submarine cables."],
          ["#2", "Idea 1: ASEAN Shield Threat Heatmap", "Combines real-time threat detection + geographic visualization + AI prediction. Any ASEAN country can deploy it. Clear demo: connect a website, watch attacks appear on the map. Strong GeoAI fusion."],
          ["#3", "Idea 3: PhishGeo Phishing Tracker", "330,000 phishing attacks + SGD 1.1B lost. Maps both attacker AND victim geography. AI predicts next target province. Immediate social impact — saves real money for real people."],
        ],
        [8, 25, 67]
      ),
      empty(),

      // Submission requirements
      h1("Submission Requirements (3 Deliverables)"),
      empty(),
      makeTable(
        ["#", "Deliverable", "Format", "Content"],
        [
          ["1", "Problem-Data-GeoAI Solution (PDGS) Canvas", "PDF", "Telecom problem, target users, datasets, GeoAI approach, expected outcomes, impact, scalability"],
          ["2", "Presentation Slide Deck", "PDF", "Introduction, Objective, Problem Statement, Solution Methodology, Benefit, Limitation, Scalability & Sustainability"],
          ["3", "Recorded Presentation", "YouTube link (max 5 min)", "Team intro, problem, solution, prototype demo, maps/outputs, impact and value"],
        ],
        [5, 25, 15, 55]
      ),
      empty(),
      p("File naming format: HACK_MM_137_PDGS_v01, HACK_MM_137_SLDK_v01, HACK_MM_137_PRES_v01", { italics: true, size: 22 }),
    ],
  }],
});

const OUTPUT = "/home/z/my-project/download/ASEAN_GEO_FUSION_15_GeoAI_Cyber_Ideas.docx";
Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(OUTPUT, buf); console.log(`Generated ${OUTPUT} (${(buf.length/1024).toFixed(1)} KB)`); });
