/**
 * Bloom SIEM — NISec Project Proposal (simple format, matches reference doc)
 * Style: Times New Roman 12pt, single section, no cover, bold inline headings,
 *        numbered list for Objectives, bullet lists for Scope/Tools/Expected Outcomes.
 * Output: /home/z/my-project/download/Bloom_SIEM_Project_Proposal.docx
 */

const {
  Document, Packer, Paragraph, TextRun, AlignmentType,
  LevelFormat, convertInchesToTwip,
} = require("docx");
const fs = require("fs");

// ── Font / size constants ──
const FONT = { ascii: "Times New Roman", eastAsia: "Times New Roman" };
const SZ_BODY = 24;       // 12pt
const SZ_HEADER = 28;     // 14pt (header university block)
const SZ_HEADER_SUB = 26; // 13pt
const SZ_HEADER_3 = 24;   // 12pt bold for section headings

// ── Helpers ──

// Top university header lines (centered, 14pt bold)
function uniHeader(text, size = SZ_HEADER) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size, font: FONT })],
  });
}

// Bold section heading (12pt bold, justified)
function heading(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { before: 240, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: SZ_HEADER_3, font: FONT })],
  });
}

// Body paragraph (justified, 12pt)
function body(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, size: SZ_BODY, font: FONT })],
  });
}

// Plain non-heading line (e.g. student name)
function line(text, bold = false) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: 60, line: 312 },
    children: [new TextRun({ text, size: SZ_BODY, font: FONT, bold })],
  });
}

// Numbered list item — uses docx-js numbering reference "obj-list"
function numItem(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    numbering: { reference: "obj-list", level: 0 },
    spacing: { after: 60, line: 312 },
    children: [new TextRun({ text, size: SZ_BODY, font: FONT })],
  });
}

// Bulleted list item — uses docx-js numbering reference "bullet-list"
function bulletItem(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    numbering: { reference: "bullet-list", level: 0 },
    spacing: { after: 60, line: 312 },
    children: [new TextRun({ text, size: SZ_BODY, font: FONT })],
  });
}

// ── Document body (single section, no cover) ──

const children = [
  // University header block (centered, bold)
  uniHeader("University of Information Technology"),
  uniHeader("Faculty of Computer Systems and Technologies", SZ_HEADER_SUB),
  uniHeader("Network & Internet Security (CST-8415)", SZ_HEADER_SUB),

  // Project Title
  heading("Project Title"),
  line("Bloom SIEM: Design and Implementation of a Real, Open-Source Security Information and Event Management Platform with AI-Driven Analyst Verdicts and Heartbeat-Based Agent Monitoring", false),

  // Student
  heading("Student"),
  line("【Student Full Name】"),
  line("【Student ID】"),
  line("Cyber Security (Semester 8)"),

  // Project Background
  heading("Project Background"),
  body("Modern organizations face a continuous volume of network intrusions, credential attacks, ransomware, and lateral movement attempts. Security Operations Center (SOC) teams rely on Security Information and Event Management (SIEM) platforms to centralize log ingestion, correlate events, surface alerts, and orchestrate response. However, commercial SIEM tools are expensive, opaque, and lock customers into per-gigabyte ingestion pricing that places them out of reach for universities, small enterprises, and individual security researchers."),
  body("It is entirely possible to build a custom SIEM using open-source tools. Many organizations build in-house SIEMs to save on licensing costs and to keep total control of their data. This project, Bloom SIEM, demonstrates that a single developer can build a production-grade SIEM using a modern JavaScript stack (Next.js, TypeScript, Prisma, SQLite) augmented with real Large Language Model (LLM) capabilities. The platform ingests real logs, runs real detection rules mapped to MITRE ATT&CK tactics, performs real DNS, SSL, HTTP, and port analysis on user-supplied domains and localhost endpoints, and calls real LLM APIs to produce confidence-scored analyst verdicts and recommended response actions."),
  body("Unlike classroom simulations that rely on mock data, every metric shown in Bloom SIEM is real. There are no seeded fake alerts, no mock CPU figures, and no vendor-logo placeholders. Logs arrive through an HTTP ingestion endpoint, are persisted to a Prisma-managed SQLite database, and are evaluated against eight detection rules that map directly to MITRE ATT&CK tactics. The platform monitors what it cannot see indirectly: real DNS resolution, SSL certificate inspection, HTTP reachability checks, and TCP port scans are performed against user-added targets, with an AI-generated risk assessment layered on top."),

  // Objectives (numbered list)
  heading("Objectives"),
  numItem("Design and implement a real log ingestion subsystem exposed as POST /api/ingest that validates source credentials and persists events to SQLite."),
  numItem("Build a rule-based detection engine with at least eight rules mapped to MITRE ATT&CK tactics that inspect every ingested log and create real alerts when patterns match."),
  numItem("Implement a configurable agent heartbeat detection subsystem with a default five-minute interval that the user can adjust on the Intelligence page."),
  numItem("Integrate real LLM APIs through an opencode-style multi-provider abstraction layer supporting Z.ai, OpenAI, Anthropic, Groq, and Mistral."),
  numItem("Build a Bloom AI SOC analyst panel that generates structured verdicts, confidence scores, summaries, rationale, key findings, and recommended actions for every alert."),
  numItem("Implement a monitored-targets subsystem where users add domains or localhost URLs and receive real DNS, HTTP, SSL, and port scan analysis."),
  numItem("Implement a domain and IP blocklist with block, monitor, and allow states and automatic hit counter for blocked sources."),
  numItem("Deliver a complete web interface with real-time activity feed, AI auto-action rules, and live system statistics."),

  // Scope (bulleted)
  heading("Scope"),
  bulletItem("Real-time log ingestion via HTTP endpoint"),
  bulletItem("Rule-based detection engine with MITRE ATT&CK mapping"),
  bulletItem("Configurable agent heartbeat detection"),
  bulletItem("AI Analyst Verdict panel calling real LLM APIs"),
  bulletItem("Opencode-style multi-provider AI configuration"),
  bulletItem("Real domain and localhost analysis (DNS, SSL, HTTP, ports)"),
  bulletItem("Domain and IP blocklist management"),
  bulletItem("AI auto-action rules (block IP, isolate host, disable user)"),
  bulletItem("Live activity feed via Server-Sent Events"),
  bulletItem("Compliance control tracking (NIST, ISO 27001, PCI-DSS, SOC 2)"),

  // Tools (bulleted)
  heading("Tools"),
  bulletItem("Next.js 16 with TypeScript"),
  bulletItem("Prisma ORM with SQLite"),
  bulletItem("Tailwind CSS with shadcn/ui"),
  bulletItem("Z.ai GLM-4.6 (default LLM provider)"),
  bulletItem("OpenAI / Anthropic / Groq / Mistral APIs"),
  bulletItem("Node.js dns, tls, net modules (real analysis)"),
  bulletItem("Server-Sent Events (real-time feed)"),
  bulletItem("Git and GitHub"),
  bulletItem("Kali Linux (testing)"),
  bulletItem("curl and Postman (ingestion testing)"),

  // Expected Outcomes (bulleted)
  heading("Expected Outcomes"),
  bulletItem("Working Bloom SIEM web application deployable from GitHub"),
  bulletItem("Real log ingestion endpoint that creates real alerts from real logs"),
  bulletItem("Detection engine with eight MITRE-mapped rules"),
  bulletItem("AI Analyst Verdict panel producing confidence-scored verdicts"),
  bulletItem("Real domain and localhost analysis (DNS, SSL, HTTP, ports)"),
  bulletItem("Domain and IP blocklist with automatic hit counter"),
  bulletItem("Live activity feed streaming heartbeats, logs, alerts, and actions"),
  bulletItem("Final project documentation and demonstration video"),
];

// ── Document assembly ──

const doc = new Document({
  creator: "Bloom SIEM",
  title: "Bloom SIEM — NISec Project Proposal",
  description: "Project proposal for the Network & Internet Security (CST-8415) individual project.",
  subject: "Cybersecurity individual project proposal",
  styles: {
    default: {
      document: {
        run: { font: FONT, size: SZ_BODY },
        paragraph: { spacing: { line: 312 } },
      },
    },
  },
  numbering: {
    config: [
      {
        reference: "obj-list",
        levels: [{
          level: 0,
          format: LevelFormat.DECIMAL,
          text: "%1.",
          alignment: AlignmentType.START,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
      {
        reference: "bullet-list",
        levels: [{
          level: 0,
          format: LevelFormat.BULLET,
          text: "\u2022",
          alignment: AlignmentType.START,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } },
        }],
      },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },
        margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 },
      },
    },
    children,
  }],
});

const OUTPUT = "/home/z/my-project/download/Bloom_SIEM_Project_Proposal.docx";
Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(OUTPUT, buf);
  console.log(`✓ Generated ${OUTPUT} (${(buf.length / 1024).toFixed(1)} KB)`);
});
