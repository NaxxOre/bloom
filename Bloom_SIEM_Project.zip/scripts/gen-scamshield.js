const {
  Document, Packer, Paragraph, TextRun, AlignmentType,
  LevelFormat, HeadingLevel, Table, TableRow, TableCell,
  WidthType, BorderStyle, ShadingType, TableLayoutType,
} = require("docx");
const fs = require("fs");

const FONT = { ascii: "Times New Roman", eastAsia: "Times New Roman" };
const SZ = 24; const H1 = 32; const H2 = 28;
const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "808080" };
const allCellBorders = { ...cellBorder, top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder, insideHorizontal: cellBorder, insideVertical: cellBorder };

function p(text, opts = {}) {
  return new Paragraph({ alignment: opts.align || AlignmentType.JUSTIFIED, spacing: { after: opts.after ?? 80, line: 312 },
    children: [new TextRun({ text, size: opts.size || SZ, font: FONT, bold: opts.bold, italics: opts.italics, color: opts.color })] });
}
function h1(text) { return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 200 }, children: [new TextRun({ text, bold: true, size: H1, font: FONT })] }); }
function h2(text) { return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 280, after: 160 }, children: [new TextRun({ text, bold: true, size: H2, font: FONT })] }); }
function h3(text) { return new Paragraph({ spacing: { before: 200, after: 100 }, children: [new TextRun({ text, bold: true, size: SZ, font: FONT, color: "1F4E79" })] }); }
function center(text, sz = SZ, bold = true) { return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80, line: 312 }, children: [new TextRun({ text, size: sz, font: FONT, bold })] }); }
function bul(text) { return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "bl", level: 0 }, spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] }); }
function num(text) { return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "nl", level: 0 }, spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] }); }
function empty() { return new Paragraph({ spacing: { after: 60 }, children: [] }); }
function tCell(text, opts = {}) {
  return new TableCell({ width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
    shading: opts.shading ? { type: ShadingType.CLEAR, fill: opts.shading } : undefined, margins: { top: 80, bottom: 80, left: 100, right: 100 },
    children: [new Paragraph({ alignment: opts.align || AlignmentType.LEFT, spacing: { line: 280 },
      children: [new TextRun({ text, size: opts.size || 22, font: FONT, bold: opts.bold, color: opts.color })] })] });
}
function makeTable(headers, rows, widths) {
  const headerRow = new TableRow({ tableHeader: true, cantSplit: true, children: headers.map((h, i) => tCell(h, { width: widths[i], shading: "1F4E79", color: "FFFFFF", bold: true, align: AlignmentType.CENTER })) });
  const dataRows = rows.map((row, ri) => new TableRow({ cantSplit: true, children: row.map((cell, ci) => tCell(cell, { width: widths[ci], shading: ri % 2 ? "D9E2F3" : undefined })) }));
  return new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, layout: TableLayoutType.FIXED, borders: allCellBorders, rows: [headerRow, ...dataRows] });
}

const doc = new Document({
  creator: "Bloom", title: "ASEAN GEO FUSION 2026 — ScamShield GeoAI Project Setup",
  styles: { default: { document: { run: { font: FONT, size: SZ }, paragraph: { spacing: { line: 312 } } } } },
  numbering: { config: [
    { reference: "nl", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "bl", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: [
      // ===== COVER =====
      center("ASEAN GeoAI FUSION 2026", 36),
      center("Bootcamp & Hackathon", 26),
      empty(),
      center("Project Setup", 28),
      empty(),
      center("ScamShield GeoAI", 30),
      center("Geospatial AI-Powered Scam & Phishing Campaign Tracker", 24),
      center("for ASEAN Telecom Network Resilience", 22),
      empty(),
      p("Challenge Domain: Security", { align: AlignmentType.CENTER, bold: true, size: 22 }),
      p("Strengthen network resilience, threat mapping and risk visibility.", { align: AlignmentType.CENTER, italics: true, size: 22 }),
      empty(),
      p("Team: \u3010Team Name\u3011    Members: \u3010Member 1, Member 2, Member 3\u3011    Institution: \u3010University Name\u3011", { align: AlignmentType.CENTER, size: 22 }),
      empty(),

      // ===== WHAT IS GEOAI =====
      h1("What is GeoAI? (And How We Adapt It)"),
      p("GeoAI = Geospatial data + Artificial Intelligence. It uses AI to understand or predict something based on WHERE it happened, WHEN it happened, WHAT exists nearby, HOW events are spatially connected, and WHICH locations will probably be affected next.", { bold: true }),
      empty(),
      p("Normal AI asks: \u201cIs this event malicious?\u201d", { italics: true }),
      p("GeoAI asks: \u201cIs this event malicious, where is it concentrated, why is it happening there, how is it spreading, and which location is at risk next?\u201d", { italics: true, bold: true }),
      empty(),

      h2("The Four Required Parts of GeoAI"),
      p("A credible GeoAI project must contain all four parts. If the location column is removed and the system still works exactly the same, it does not genuinely need GeoAI.", { bold: true }),
      empty(),
      makeTable(
        ["Part", "Meaning", "How ScamShield GeoAI Implements It"],
        [
          ["1. Geospatial Input", "Data contains location", "Scam reports include township/district, cell-tower area, or IP geolocation of the victim and scam source"],
          ["2. Spatial Processing", "System calculates geographic relationships", "DBSCAN clustering finds scam density hotspots. Distance analysis compares townships. H3 hexagonal grid aggregates incidents"],
          ["3. AI / Intelligent Model", "Detects or predicts a pattern", "NLP classifies scam type (banking, job, investment). Time-series model detects sudden surges. Spatial prediction model forecasts next target areas"],
          ["4. Geographic Output", "Produces a location-based decision", "Risk heatmap showing predicted spread. Warning alerts: \u201cHigh probability of banking smishing spreading toward Kamayut within 6 hours\u201d"],
        ],
        [18, 25, 57]
      ),
      empty(),

      h2("How We Adapt Cybersecurity to GeoAI"),
      p("We follow this formula:", { bold: true }),
      center("Cyber event + location + time + spatial context \u2192 GeoAI analysis \u2192 location-based action", 22, true),
      empty(),
      num("Step 1: Begin with a telecom-security problem \u2014 scam SMS, phishing links, and social engineering attacks use telecom networks to target ASEAN subscribers."),
      num("Step 2: Give every event a geographic unit \u2014 township, district, cell-tower coverage area, or H3 hexagonal grid (for privacy, aggregated grids are better than exact user locations)."),
      num("Step 3: Add geographic context \u2014 population density, telecom coverage, urban/rural classification, historical incident density, distance to commercial areas."),
      num("Step 4: Perform a real spatial task \u2014 hotspot detection (where are scams concentrated?), spread prediction (where will the campaign move next?), risk prediction (which areas will be hit?)."),
      num("Step 5: Produce an operational action \u2014 warn subscribers in these districts, block this campaign in the affected region, deploy response team here."),
      empty(),

      // ===== IDENTIFIED PROBLEM =====
      h1("1. Identified Problem"),
      p("Across ASEAN, telecom subscribers are bombarded with scam SMS, fake bank messages, phishing links, impersonation calls, job/investment scams, and mass messages from SIM boxes. These attacks travel through telecom networks and are frequently targeted by location, language, and local events.", { bold: true }),
      empty(),
      p("The real-world evidence:", { bold: true }),
      bul("Scam victims across ASEAN lost an estimated USD 88.3 billion to USD 114.1 billion in 2025 (UNODC)."),
      bul("330,000 financial phishing attacks hit Southeast Asia in early 2024 alone (Kaspersky, 41% increase)."),
      bul("68% of scam victims in ASEAN reported losing money in 2025 (ASEAN Consumer Scam Report)."),
      bul("At least 120,000 people are trafficked to work in scam compounds in Myanmar's border regions (UN report)."),
      bul("Scam centers use spoofed calls, SMS phishing, and social media platforms (Telegram, WeChat, Viber) to target victims across ASEAN."),
      bul("These scams often go unnoticed because they land in spam folders or victims do not report them \u2014 making the true scale invisible."),
      empty(),

      h2("The Five Core Problems"),
      empty(),
      makeTable(
        ["Problem", "Description"],
        [
          ["1. No Geographic Visibility", "When 1,000 scam SMS reports come in, telecom operators and regulators see numbers and categories but cannot visualize WHERE victims are located or WHERE the scam infrastructure operates. There is no map showing scam hotspots across ASEAN townships."],
          ["2. No Spread Prediction", "Scam campaigns are not random \u2014 they spread geographically. A banking smishing campaign that hits Yangon today will likely target Hlaing and Kamayut tomorrow. No system predicts this geographic spread."],
          ["3. Slow Response", "By the time a scam is reported, hundreds of victims have already lost money. There is no early warning system that detects an emerging scam cluster and alerts nearby areas before the campaign reaches them."],
          ["4. No Cross-Platform Correlation", "Scams spread across SMS, Telegram, WeChat, Viber, and email. No platform correlates scam reports across these channels and maps them geographically to identify coordinated campaigns."],
          ["5. Spam Folder Invisibility", "Most phishing emails and scam messages go to spam folders, meaning victims never see them and never report them. The true scale of scam activity is hidden \u2014 our system needs to analyze spam data, not just reported incidents."],
        ],
        [25, 75]
      ),
      empty(),

      // ===== PROPOSED SOLUTION =====
      h1("2. Proposed Solution: ScamShield GeoAI"),
      p("ScamShield GeoAI is a geospatial AI platform that ingests scam reports (SMS, email, social media), classifies them using NLP, detects geographic clusters using DBSCAN, predicts where the scam campaign will spread next, and generates location-based warnings for telecom operators and regulators.", { bold: true }),
      empty(),

      h2("How It Works (End-to-End Workflow)"),
      num("Ingest scam reports from multiple sources: SMS forwarding (user-submitted), email spam folder analysis, Telegram/WeChat/Viber scam group monitoring, and threat intelligence feeds (URLhaus, PhishTank)."),
      num("NLP Classification: AI classifies each report as banking scam, job scam, investment scam, impersonation, or phishing link. The model also extracts the scammer's phone number, URL, and message content."),
      num("Geocoding: Each report is assigned a geographic unit \u2014 the victim's township/district (from phone number area code or user-submitted location) and the scammer's location (from phone number prefix, URL hosting IP, or known scam compound locations)."),
      num("DBSCAN Spatial Clustering: The system runs DBSCAN (Density-Based Spatial Clustering of Applications with Noise) on the geographic coordinates to detect scam hotspots \u2014 areas where scam density is significantly higher than the baseline."),
      num("Time-Series Surge Detection: For each detected cluster, the system tracks the number of reports over time. When a sudden increase is detected (e.g., 50 reports in 2 hours from the same township), it flags an emerging campaign."),
      num("Geographic Spread Prediction: Using historical scam propagation patterns (how campaigns moved between townships in the past), the AI predicts which nearby areas are likely to be targeted next within a 6-hour window."),
      num("Risk Scoring: Each township receives a dynamic risk score (0-100) based on: current scam density, rate of increase, predicted spread probability, population density, and historical vulnerability."),
      num("Location-Based Action: The system generates actionable warnings: \u201cHigh probability of banking smishing activity spreading toward Kamayut and Hlaing within the next 6 hours. Recommend issuing SMS warning to subscribers in these districts.\u201d"),
      empty(),

      h2("What the AI Does (GeoAI Components)"),
      empty(),
      makeTable(
        ["AI Component", "What It Does", "GeoAI or Just AI?"],
        [
          ["NLP Classifier", "Classifies scam messages as banking, job, investment, phishing, impersonation", "AI (not GeoAI) \u2014 but provides input for spatial analysis"],
          ["DBSCAN Clustering", "Finds geographic scam clusters \u2014 areas where scam density is abnormally high", "GeoAI \u2014 uses location coordinates; cannot work without geography"],
          ["Time-Series Anomaly Detection", "Detects sudden surges in scam reports per township over time", "GeoAI \u2014 spatial time-series; location + time combined"],
          ["Spatial Spread Prediction", "Predicts which nearby townships will be targeted next based on historical propagation patterns", "GeoAI \u2014 pure spatial prediction model"],
          ["Risk Scoring", "Calculates dynamic risk score per district using density + surge + spread + population context", "GeoAI \u2014 combines physical context (population) with cyber data"],
        ],
        [20, 45, 35]
      ),
      empty(),

      h2("Live Demonstration Flow (5-Minute Story for Judges)"),
      num("Display the ASEAN map initially showing normal activity (green/low risk across all townships)."),
      num("Introduce several new scam reports from different Yangon townships (replay historical data)."),
      num("Red hotspots begin appearing as DBSCAN detects geographic clusters."),
      num("The model identifies a coordinated banking scam campaign across 3 townships."),
      num("GeoAI predicts the campaign's likely next target areas (Kamayut, Hlaing) within 6 hours."),
      num("The dashboard generates a warning: \u201cHigh probability of banking smishing spreading toward Kamayut and Hlaing. Recommend issuing SMS warning.\u201d"),
      num("Show one evaluation metric (e.g., prediction accuracy: 82% of predicted townships were actually hit within 6 hours)."),
      empty(),

      // ===== PROJECT NAME =====
      h1("3. Project Name"),
      p("ScamShield GeoAI: Geospatial AI-Powered Scam & Phishing Campaign Tracker for ASEAN Telecom Network Resilience"),
      empty(),

      // ===== PROJECT OBJECTIVE =====
      h1("4. Project Objective"),
      p("To build a working GeoAI prototype that ingests scam reports from ASEAN telecom subscribers, detects geographic scam clusters using spatial clustering, predicts where scam campaigns will spread next, and generates location-based early warnings for telecom operators and regulators \u2014 reducing the time from scam campaign launch to public warning from days to hours."),
      empty(),
      p("Specific objectives:", { bold: true }),
      num("Build an NLP classifier that categorizes scam messages (banking, job, investment, phishing, impersonation) from SMS, email spam, and social media platforms."),
      num("Implement DBSCAN spatial clustering to detect geographic scam hotspots across ASEAN townships."),
      num("Develop a time-series anomaly detection model that flags sudden scam report surges per district."),
      num("Build a spatial spread prediction model that forecasts which nearby areas will be targeted next within a 6-hour window."),
      num("Create an interactive ASEAN risk map showing real-time hotspots, predicted spread zones, and risk scores per township."),
      num("Generate actionable location-based warnings for telecom operators: which districts to issue SMS alerts to."),
      empty(),

      // ===== PROJECT AGENDA / WORK PLAN =====
      h1("5. Project Agenda / Work Plan"),
      empty(),
      makeTable(
        ["Phase", "Timeline", "Activities", "Deliverables"],
        [
          ["Phase 1: Data & NLP", "Weeks 1-2", "Create synthetic ASEAN scam-report dataset (10,000+ records with township, message, timestamp, scam type). Train NLP classifier (scikit-learn) to categorize scam types.", "Dataset + trained NLP model"],
          ["Phase 2: Spatial Clustering", "Weeks 3-4", "Implement DBSCAN clustering on geographic coordinates. Detect hotspots. Calculate density per township using H3 hexagonal grid.", "DBSCAN model + hotspot detection"],
          ["Phase 3: Spread Prediction", "Weeks 5-6", "Build spatial spread prediction model using historical propagation patterns. Train on past campaign movements between townships.", "Spread prediction model + accuracy metrics"],
          ["Phase 4: Risk Map UI", "Weeks 7-8", "Build interactive map (Folium/PyDeck) showing real-time hotspots, predicted spread zones, risk scores. Add warning generation system.", "Interactive ASEAN risk map dashboard"],
          ["Phase 5: Integration", "Weeks 9-10", "Connect NLP \u2192 DBSCAN \u2192 spread prediction \u2192 risk map \u2192 warning generation. End-to-end pipeline testing.", "Working end-to-end prototype"],
          ["Phase 6: Demo & Docs", "Weeks 11-12", "Prepare 5-minute demo script. Record presentation. Create PDGS canvas and slide deck. Test with judges' questions.", "All 3 submission deliverables"],
        ],
        [15, 12, 43, 30]
      ),
      empty(),

      // ===== EXPECTED OUTCOMES =====
      h1("6. Expected Outcome"),
      bul("A working GeoAI prototype that ingests scam reports and produces a geographic risk map with predicted spread zones."),
      bul("NLP classifier achieving 85%+ accuracy on scam type classification (banking, job, investment, phishing, impersonation)."),
      bul("DBSCAN clustering that correctly identifies scam hotspots across ASEAN townships."),
      bul("Spatial spread prediction model achieving 80%+ accuracy on predicting the next targeted township within a 6-hour window."),
      bul("Interactive ASEAN map showing: (1) real-time scam hotspots as red zones, (2) predicted spread zones as orange zones, (3) risk scores per township, (4) recommended warning districts."),
      bul("Automated warning generation: \u201cHigh probability of [scam type] spreading toward [township names] within [timeframe]. Recommend issuing SMS warning to subscribers in these districts.\u201d"),
      bul("Evaluation metrics proving the GeoAI model works (prediction accuracy, hotspot detection precision/recall, false-positive rate)."),
      bul("Simple prototype stack: Streamlit + Python + Folium/PyDeck + scikit-learn + GeoPandas + SQLite. No real telecom data required \u2014 synthetic ASEAN dataset."),
      empty(),

      // ===== DATA SOURCES =====
      h1("7. Data Sources"),
      p("No confidential telecom data is required. The prototype uses:", { bold: true }),
      bul("Synthetic ASEAN scam-report dataset: 10,000+ records with fields: timestamp, victim township/district, message content, scammer phone/URL, channel (SMS/Telegram/WeChat/Viber/email), scam type label."),
      bul("PhishTank: Verified phishing URLs for the phishing-type classifier training."),
      bul("URLhaus (Abuse.ch): Malicious URL feed for real-time phishing detection."),
      bul("ASEAN administrative boundaries: GIS shapefiles for township/district polygons (from Humanitarian Data Exchange / GADM)."),
      bul("Population density data: WorldPop gridded population data for ASEAN countries (for risk scoring context)."),
      bul("H3 hexagonal grid: Uber's H3 library for privacy-preserving spatial aggregation."),
      empty(),

      // ===== TECH STACK =====
      h1("8. Technology Stack"),
      bul("Python 3.11 \u2014 core language"),
      bul("Streamlit \u2014 interactive web dashboard"),
      bul("Folium / PyDeck \u2014 geographic map visualization"),
      bul("scikit-learn \u2014 NLP classifier (TF-IDF + Naive Bayes / Logistic Regression) and DBSCAN clustering"),
      bul("GeoPandas \u2014 geospatial data processing"),
      bul("H3 (Uber) \u2014 hexagonal spatial grid for aggregation"),
      bul("SQLite / CSV \u2014 data storage (no external database needed)"),
      bul("Pandas + NumPy \u2014 data manipulation"),
      empty(),

      // ===== JUDGE ALIGNMENT =====
      h1("9. How This Project Answers Judges' Questions"),
      empty(),
      makeTable(
        ["Judge's Question", "How ScamShield GeoAI Answers It"],
        [
          ["Is this a real problem?", "USD 88-114B lost to scams in ASEAN in 2025. 330K phishing attacks. Everyone receives scam SMS. The problem is visible and daily."],
          ["Why does geography matter?", "Scam campaigns spread geographically. Without location, you cannot detect clusters, predict spread, or target warnings to specific districts."],
          ["Where is the AI?", "NLP classifier (scam type), DBSCAN (hotspot detection), time-series anomaly detection (surge detection), spatial prediction model (spread forecasting). Four distinct AI models."],
          ["Is it just a map?", "No. The map is the output. The AI components (NLP + DBSCAN + prediction) do the analysis. If you remove the location column, the prediction model cannot work."],
          ["Who will use it?", "Telecom operators (MPT, Viettel, Globe, Telkomsel), regulators (MCMC, MIC, NTC), and ASEAN CERTs."],
          ["Can it work?", "Yes. Uses synthetic data + open-source tools. No confidential telecom access required. Prototype can be demonstrated live."],
          ["Is the result useful?", "Yes \u2014 generates specific actionable warnings: \u201cIssue SMS alert to subscribers in Kamayut and Hlaing within 6 hours.\u201d"],
          ["Can it scale?", "Yes \u2014 the same workflow works for any ASEAN country. Add a new country's township shapefile and the system adapts."],
          ["Is it responsible?", "Yes \u2014 uses H3 hexagonal aggregation for privacy (no individual user locations). Includes false-positive controls and uncertainty metrics."],
          ["Can the team explain it?", "Yes \u2014 simple architecture: ingest \u2192 classify \u2192 cluster \u2192 predict \u2192 warn. Clear metrics. Honest limitations."],
        ],
        [25, 75]
      ),
      empty(),

      // ===== SUBMISSION DELIVERABLES =====
      h1("10. Submission Deliverables"),
      empty(),
      makeTable(
        ["#", "Deliverable", "Format", "File Name", "Content"],
        [
          ["1", "PDGS Canvas", "PDF", "HACK_MM_137_PDGS_v01", "Telecom problem, target users, datasets, GeoAI approach, expected outcomes, impact, scalability"],
          ["2", "Slide Deck", "PDF", "HACK_MM_137_SLDK_v01", "Introduction, Objective, Problem Statement, Solution Methodology, Benefit, Limitation, Scalability & Sustainability"],
          ["3", "Recorded Presentation", "YouTube (max 5 min)", "HACK_MM_137_PRES_v01", "Team intro, problem, solution, prototype demo, maps/outputs, impact and value"],
        ],
        [5, 18, 12, 25, 40]
      ),
      empty(),

      // ===== WHAT TO AVOID =====
      h1("11. What We Avoid (Weaknesses to Prevent)"),
      bul("Putting ordinary scam alerts on a map without spatial analysis \u2014 we use DBSCAN + prediction, not just markers."),
      bul("Displaying scammer IP countries without spatial reasoning \u2014 we analyze WHY scams concentrate in specific townships."),
      bul("Using ChatGPT as the main AI \u2014 we use scikit-learn models (NLP + DBSCAN + time-series) that are transparent and evaluable."),
      bul("Building only a dashboard with no working model \u2014 our prediction model has accuracy metrics."),
      bul("Claiming to predict attacks without evaluation \u2014 we show prediction accuracy (target: 80%+)."),
      bul("Selecting a problem requiring confidential telecom data \u2014 we use synthetic data + open feeds."),
      bul("Showing only code without geographic output \u2014 our demo shows the map changing in real-time."),
      bul("Creating a project so complex the demo fails \u2014 our stack is simple: Streamlit + Python + Folium + scikit-learn."),
    ],
  }],
});

const OUTPUT = "/home/z/my-project/download/ScamShield_GeoAI_Project_Setup.docx";
Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(OUTPUT, buf); console.log(`Generated ${OUTPUT} (${(buf.length/1024).toFixed(1)} KB)`); });
