import { Document, Packer, Paragraph, TextRun, AlignmentType, LevelFormat, HeadingLevel, Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType, TableLayoutType } from "docx";
import * as fs from "fs";

const FONT = { ascii: "Times New Roman", eastAsia: "Times New Roman" };
const SZ = 24; const H1 = 32; const H2 = 28;

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };
const cellBorder = { style: BorderStyle.SINGLE, size: 4, color: "808080" };
const allCellBorders = { ...cellBorder, top: cellBorder, bottom: cellBorder, left: cellBorder, right: cellBorder, insideHorizontal: cellBorder, insideVertical: cellBorder };

function p(text: string, opts: any = {}) {
  return new Paragraph({ alignment: opts.align || AlignmentType.JUSTIFIED, spacing: { after: opts.after ?? 80, line: 312 },
    children: [new TextRun({ text, size: opts.size || SZ, font: FONT, bold: opts.bold, italics: opts.italics, color: opts.color })] });
}
function h1(text: string) {
  return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 200 },
    children: [new TextRun({ text, bold: true, size: H1, font: FONT })] });
}
function h2(text: string) {
  return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 280, after: 160 },
    children: [new TextRun({ text, bold: true, size: H2, font: FONT })] });
}
function center(text: string, sz = SZ, bold = true) {
  return new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, size: sz, font: FONT, bold })] });
}
function bul(text: string) {
  return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "bl", level: 0 },
    spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] });
}
function num(text: string) {
  return new Paragraph({ alignment: AlignmentType.JUSTIFIED, numbering: { reference: "nl", level: 0 },
    spacing: { after: 60, line: 312 }, children: [new TextRun({ text, size: SZ, font: FONT })] });
}
function empty() { return new Paragraph({ spacing: { after: 60 }, children: [] }); }

function tCell(text: string, opts: any = {}) {
  return new TableCell({ width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
    shading: opts.shading ? { type: ShadingType.CLEAR, fill: opts.shading } : undefined,
    margins: { top: 80, bottom: 80, left: 100, right: 100 },
    children: [new Paragraph({ alignment: opts.align || AlignmentType.LEFT, spacing: { line: 280 },
      children: [new TextRun({ text, size: opts.size || 22, font: FONT, bold: opts.bold, color: opts.color })] })] });
}
function makeTable(headers: string[], rows: string[][], widths: number[]) {
  const headerRow = new TableRow({ tableHeader: true, cantSplit: true,
    children: headers.map((h, i) => tCell(h, { width: widths[i], shading: "1F4E79", color: "FFFFFF", bold: true, align: AlignmentType.CENTER })) });
  const dataRows = rows.map((row, ri) => new TableRow({ cantSplit: true,
    children: row.map((cell, ci) => tCell(cell, { width: widths[ci], shading: ri % 2 ? "D9E2F3" : undefined })) }));
  return new Table({ width: { size: 100, type: WidthType.PERCENTAGE }, layout: TableLayoutType.FIXED, borders: allCellBorders, rows: [headerRow, ...dataRows] });
}

const doc = new Document({
  creator: "Bloom SIEM", title: "ASEAN GEO FUSION 2026 — Project Setup",
  styles: { default: { document: { run: { font: FONT, size: SZ }, paragraph: { spacing: { line: 312 } } } } },
  numbering: { config: [
    { reference: "nl", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    { reference: "bl", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: [
      // ===== COVER =====
      center("ASEAN GEO FUSION 2026", 36),
      center("Project Setup", 28),
      empty(),
      center("BloomGeoAI: Geo-AI Powered Cyber Threat Intelligence Platform", 26),
      center("for ASEAN Network Resilience", 22),
      empty(),
      p("Challenge Domain: Security — Strengthen network resilience, threat mapping and risk visibility.", { align: AlignmentType.CENTER, italics: true, size: 22 }),
      p("Focus Areas: Asset vulnerability | Incident response | Threat detection | Risk dashboards", { align: AlignmentType.CENTER, italics: true, size: 22 }),
      empty(),
      empty(),
      p("Team: \u3010Team Name\u3011", { bold: true }),
      p("Members: \u3010Member 1, Member 2, Member 3\u3011", { bold: true }),
      p("Institution: \u3010University Name\u3011", { bold: true }),
      p("Date: \u3010Date\u3011", { bold: true }),
      empty(),

      // ===== PROJECT SETUP =====
      h1("Project Setup"),
      p("This document defines the project before proceeding to the final Project Submission layer. It covers the project name, objective, agenda / work plan, and expected outcomes.", { bold: true }),
      empty(),

      // ===== PROJECT NAME =====
      h2("Project Name"),
      p("BloomGeoAI: A Geo-AI Powered Cyber Threat Intelligence Platform for ASEAN Network Resilience"),
      p("A real-time SIEM platform that fuses geospatial threat intelligence with AI-driven detection to visualize, map, and respond to cyber threats across ASEAN network infrastructure.", { italics: true }),
      empty(),

      // ===== PROJECT OBJECTIVE =====
      h2("Project Objective"),
      p("To build a production-ready, open-source cyber threat intelligence platform that combines real-time network traffic monitoring, AI-powered threat analysis, and geospatial threat mapping to strengthen network resilience across ASEAN. The platform ingests live web traffic from connected sites, detects threats using MITRE ATT&CK-mapped rules, generates AI confidence-scored verdicts, and visualizes attack origins, patterns, and risk levels on an interactive geographic dashboard."),
      empty(),
      p("Specific objectives:", { bold: true }),
      num("Ingest real-time web traffic from connected ASEAN websites via lightweight middleware (Next.js, HTML, PHP, Express)."),
      num("Detect cyber threats using 6 MITRE ATT&CK-mapped detection rules (brute force, SQLi, XSS, malware, route scanning, session replication)."),
      num("Generate AI-driven threat verdicts with confidence scores (0-100%) using LLM APIs (Z.ai GLM-4.6)."),
      num("Perform IP geolocation and map attack origins to ASEAN countries on an interactive dashboard."),
      num("Automate response actions: block IPs, revoke sessions, quarantine files, send Telegram alerts with Approve/Deny buttons."),
      num("Perform deep site discovery (Playwright headless crawler) to map all routes, input fields, and buttons on connected sites."),
      num("Perform real domain analysis (DNS, SSL, HTTP, port scanning) on monitored ASEAN infrastructure."),
      num("Provide risk dashboards with top IPs, AS names, attack patterns, MITRE ATT&CK coverage, and country-based threat heatmaps."),
      empty(),

      // ===== PROJECT AGENDA / WORK PLAN =====
      h2("Project Agenda / Work Plan"),
      empty(),
      makeTable(
        ["Phase", "Timeline", "Activities", "Deliverables"],
        [
          ["Phase 1: Foundation", "Weeks 1-2", "Set up Next.js 16 + Prisma + SQLite. Build dashboard with 17 routed pages. Deploy Bloom SIEM on Vercel.", "Working dashboard + database schema + initial deployment"],
          ["Phase 2: Traffic Pipeline", "Weeks 3-4", "Build SDK middleware (Next.js/HTML/PHP/Express). Implement /api/sdk/ingest + /api/sdk/evaluate with CORS. Add IP geolocation (ip-api.com).", "Connected site pipeline + real traffic ingestion + geolocation"],
          ["Phase 3: Detection Engine", "Weeks 5-6", "Implement 6 MITRE ATT&CK detection rules. Build AI analyst verdict system (Z.ai GLM-4.6). Create automated response playbooks.", "Detection rules + AI verdicts + automated blocking + session revocation"],
          ["Phase 4: GeoAI Threat Map", "Weeks 7-8", "Build interactive ASEAN map showing attack origins, country heatmaps, top IPs per country, and real-time threat feed. Add risk scoring per country.", "GeoAI threat map + country risk dashboards"],
          ["Phase 5: Site Discovery", "Weeks 9-10", "Implement Playwright deep crawler. Add domain analysis (DNS, SSL, ports). Build MITRE ATT&CK matrix with all 858 techniques.", "Site scanner + domain analyzer + MITRE matrix"],
          ["Phase 6: Automation + Telegram", "Weeks 11-12", "Build country-based automation rules. Add Telegram bot with Approve/Deny webhook. Implement brute-force and session replication detection.", "Country blocking + Telegram alerts + webhook handler"],
          ["Phase 7: Testing + Polish", "Weeks 13-14", "End-to-end testing on real ASEAN websites. Performance optimization. Skeleton loading animations. Final documentation.", "Test report + documentation + live demo"],
        ],
        [15, 12, 43, 30]
      ),
      empty(),

      // ===== EXPECTED OUTCOMES =====
      h2("Expected Outcome"),
      bul("A working GeoAI cyber threat intelligence platform deployed on Vercel, ingesting real traffic from connected ASEAN websites."),
      bul("Interactive ASEAN threat map showing live attack origins, country-based risk heatmaps, and top attacking IPs per country."),
      bul("AI-generated confidence-scored verdicts on every alert (target: under 5 seconds response time)."),
      bul("Automated IP blocking enforced by middleware (HTTP 403 response) for threats detected in real-time."),
      bul("MITRE ATT&CK coverage matrix with all 858 techniques loaded and 11+ actively detected."),
      bul("Telegram bot integration with working Approve/Deny inline buttons for admin approval of automated actions."),
      bul("Deep site discovery reports showing all routes, input fields, buttons, and inaccessible paths on connected sites."),
      bul("Real domain analysis (DNS, SSL certificate, HTTP reachability, TCP port scan) on monitored ASEAN infrastructure."),
      bul("Country-based automation: block traffic from high-risk countries (e.g., known APT origin countries) with one click."),
      bul("Open-source codebase on GitHub (MIT license) with full documentation for ASEAN-wide adoption."),
      empty(),

      // ===== WHY THIS PROJECT =====
      h1("Why This Project Stands Out"),
      empty(),
      p("1. Real, Not Simulated", { bold: true }),
      p("Unlike classroom SIEM projects that use mock data, BloomGeoAI ingests real web traffic from real ASEAN websites. Every metric on the dashboard \u2014 top IPs, attack patterns, country heatmaps \u2014 comes from actual visitor data, not seeded databases."),
      empty(),
      p("2. GeoAI Fusion", { bold: true }),
      p("The platform fuses two powerful concepts: geospatial intelligence (where attacks come from) and AI-driven analysis (what the attack means). The ASEAN threat map visualizes attack origins in real-time, while the AI analyst generates confidence-scored verdicts with recommended responses \u2014 combining the 'where' and 'what' of cyber threats."),
      empty(),
      p("3. ASEAN-Relevant", { bold: true }),
      p("The platform includes country-specific threat intelligence for all 10 ASEAN member states. IP geolocation identifies which ASEAN countries are being attacked and which countries the attacks originate from. Country-based automation rules can block traffic from high-risk regions, making it directly applicable to ASEAN network resilience challenges."),
      empty(),
      p("4. MITRE ATT&CK Aligned", { bold: true }),
      p("The platform loads all 858 MITRE ATT&CK Enterprise techniques and actively detects 11+ techniques with real detection rules. Each alert is mapped to a MITRE tactic and technique ID, making the threat intelligence recognized and defensible."),
      empty(),
      p("5. Production-Ready", { bold: true }),
      p("Built with Next.js 16, TypeScript, Prisma ORM, and Tailwind CSS. Deployable on Vercel with zero configuration. Open-source under MIT license. The code is on GitHub at github.com/NaxxOre/Bloom_SIEM with full documentation."),
      empty(),

      // ===== TECH STACK =====
      h1("Technology Stack"),
      empty(),
      makeTable(
        ["Layer", "Technology", "Purpose"],
        [
          ["Frontend", "Next.js 16 + TypeScript + Tailwind CSS 4", "Dark-themed dashboard with 17 routed pages"],
          ["Backend", "Next.js API Routes (Node.js runtime)", "20+ API endpoints for ingestion, evaluation, analysis"],
          ["Database", "Prisma ORM + SQLite", "20 models, zero-configuration, type-safe queries"],
          ["AI", "Z.ai GLM-4.6 + OpenAI-compatible HTTP", "Multi-provider LLM for confidence-scored verdicts"],
          ["GeoAI", "ip-api.com + Playwright + Node.js dns/tls/net", "IP geolocation, site crawling, domain analysis"],
          ["Real-time", "Server-Sent Events (SSE)", "Live activity feed streaming threats"],
          ["Automation", "Telegram Bot API + Webhook", "Real-time alerts with Approve/Deny buttons"],
          ["Mapping", "Interactive ASEAN map + risk heatmaps", "Visualize attack origins and country risk levels"],
        ],
        [15, 30, 55]
      ),
      empty(),

      // ===== CHALLENGE ALIGNMENT =====
      h1("Challenge Domain Alignment"),
      p("Challenge: Security \u2014 Strengthen network resilience, threat mapping and risk visibility.", { bold: true }),
      empty(),
      makeTable(
        ["Focus Area", "How BloomGeoAI Addresses It"],
        [
          ["Asset vulnerability", "Deep site discovery (Playwright) scans connected ASEAN sites for all routes, input fields, buttons, and inaccessible paths. Domain analysis checks DNS, SSL certificates, HTTP reachability, and open ports on monitored infrastructure."],
          ["Incident response", "Automated response playbook: block IPs, revoke sessions, quarantine files, send Telegram alerts with Approve/Deny. AI analyst generates confidence-scored verdicts with recommended actions within 5 seconds."],
          ["Threat detection", "6 MITRE ATT&CK-mapped detection rules (brute force, SQLi, XSS, malware, route scanning, session replication) run on every ingested event. All 858 ATT&CK techniques loaded with 11+ actively detected."],
          ["Risk dashboards", "Interactive ASEAN threat map with country heatmaps, top attacking IPs per country, real-time traffic overview (Vercel-style), brute-force detection, session replication alerts, and IP spike graphs."],
        ],
        [25, 75]
      ),
    ],
  }],
});

const OUTPUT = "/home/z/my-project/download/ASEAN_GEO_FUSION_2026_BloomGeoAI.docx";
Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(OUTPUT, buf); console.log(`Generated ${OUTPUT} (${(buf.length/1024).toFixed(1)} KB)`); });
