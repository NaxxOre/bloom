const {
  Document, Packer, Paragraph, TextRun, AlignmentType,
  LevelFormat,
} = require("docx");
const fs = require("fs");

const FONT = { ascii: "Times New Roman", eastAsia: "Times New Roman" };
const SZ = 24; // 12pt

function p(text, opts = {}) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, size: SZ, font: FONT, ...opts })],
  });
}
function bold(text) { return p(text, { bold: true }); }
function num(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    numbering: { reference: "nl", level: 0 },
    spacing: { after: 60, line: 312 },
    children: [new TextRun({ text, size: SZ, font: FONT })],
  });
}
function bul(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    numbering: { reference: "bl", level: 0 },
    spacing: { after: 60, line: 312 },
    children: [new TextRun({ text, size: SZ, font: FONT })],
  });
}
function center(text, sz = SZ) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 80, line: 312 },
    children: [new TextRun({ text, size: sz, font: FONT, bold: true })],
  });
}

const doc = new Document({
  creator: "Bloom",
  title: "Bloom SIEM Project Proposal",
  styles: { default: { document: { run: { font: FONT, size: SZ }, paragraph: { spacing: { line: 312 } } } } },
  numbering: {
    config: [
      { reference: "nl", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "bl", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.START, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ],
  },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: [
      center("University of Information Technology", 28),
      center("Faculty of Computer Systems and Technologies", 26),
      center("Network & Internet Security (CST-8415)", 26),
      p(""),
      bold("Project Title"),
      p("Bloom SIEM: Real-Time Security Monitoring with AI-Driven Threat Detection and Automated Response"),
      p(""),
      bold("Student"),
      p("【Student Name】"),
      p("【Student ID】"),
      p("Cyber Security (Semester 8)"),
      p(""),
      bold("Project Background"),
      p("Commercial SIEM platforms like Splunk and QRadar cost thousands per GB ingested, locking organizations into vendor pricing with no control over their data. This project builds Bloom SIEM, an open-source alternative that ingests real web traffic through a lightweight middleware, detects threats using MITRE ATT&CK rules and AI, and automates responses like IP blocking and session revocation — all self-hosted with zero licensing fees."),
      p(""),
      bold("Objectives"),
      num("Deploy a real log ingestion pipeline via HTTP middleware that captures live web traffic."),
      num("Implement AI-driven threat analysis using LLM APIs (Z.ai GLM-4.6) to score alert confidence and recommend actions."),
      num("Build automated response rules for country blocking, brute-force protection, and malware file quarantine."),
      num("Perform real domain analysis (DNS, SSL, HTTP, port scanning) on monitored targets."),
      num("Integrate Telegram bot for real-time security alerts with approve/deny inline buttons."),
      num("Track input fields, buttons, and routes on connected sites through live SDK events."),
      p(""),
      bold("Scope"),
      bul("Real-time traffic ingestion via Next.js / HTML / PHP / Express middleware"),
      bul("AI analyst verdicts with confidence scores on every alert"),
      bul("Country-based IP blocking with geolocation lookup (ip-api.com)"),
      bul("Brute-force detection and session replication alerts"),
      bul("Malware file scanning (hash signature + double-extension detection)"),
      bul("Telegram notifications with webhook-based approve/deny"),
      bul("Site discovery scanner (routes, forms, buttons, inaccessible paths)"),
      bul("MITRE ATT&CK playbook with AI-driven technique evaluation"),
      p(""),
      bold("Tools"),
      bul("Next.js 16 + TypeScript + Tailwind CSS"),
      bul("Prisma ORM + SQLite"),
      bul("Z.ai GLM-4.6 (AI analyst)"),
      bul("Node.js dns / tls / net modules (real analysis)"),
      bul("Server-Sent Events (real-time feed)"),
      bul("Telegram Bot API"),
      bul("Vercel (deployment)"),
      bul("Git + GitHub"),
      p(""),
      bold("Expected Outcomes"),
      bul("Working SIEM dashboard with live traffic from connected sites"),
      bul("AI-generated verdicts on alerts in under 5 seconds"),
      bul("Automated IP blocking enforced by middleware (403 response)"),
      bul("Real domain analysis with DNS, SSL cert, HTTP status, and port scan"),
      bul("Telegram alerts with working approve/deny buttons"),
      bul("Site discovery report showing all routes, input fields, and buttons"),
      bul("Final project documentation and live demonstration"),
    ],
  }],
});

const OUTPUT = "/home/z/my-project/download/Bloom_SIEM_Proposal.docx";
Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(OUTPUT, buf);
  console.log(`✓ Generated ${OUTPUT}`);
});
