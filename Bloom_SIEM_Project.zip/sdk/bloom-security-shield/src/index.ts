/**
 * @bloom-security/shield — main exports
 */

export { BloomClient } from './client';
export type { BloomConfig, SiteEventPayload, ThreatDecision, FileScanResult, SessionCheckResult } from './client';

// Framework wrappers — import from subpaths to avoid pulling in unused deps
export { bloomExpressMiddleware, Bloom as BloomExpress } from './express';
export { bloomNextMiddleware, Bloom as BloomNext } from './next';

// Default export: a unified "Bloom" namespace.
// Users should import from `/express` or `/next` subpath explicitly.
import { bloomExpressMiddleware } from './express';
import { bloomNextMiddleware } from './next';

export const Bloom = {
  express: bloomExpressMiddleware,
  next: bloomNextMiddleware,
  /** Alias — picks Express variant. Use `/next` subpath for Next.js. */
  init: bloomExpressMiddleware,
};
