/**
 * @bloom-security/shield — Express middleware wrapper
 *
 * Usage:
 *   import { Bloom } from '@bloom-security/shield/express';
 *   app.use(Bloom.init({ projectId, apiKey, features: { trackInputs: true } }));
 */

import { BloomClient, BloomConfig, SiteEventPayload } from './client';

// Minimal type defs — we don't want to bundle express as a hard dep
interface ExpressRequest {
  method: string;
  path: string;
  hostname?: string;
  headers: Record<string, string | string[] | undefined>;
  ip?: string;
  socket: { remoteAddress?: string };
  body?: unknown;
  files?: unknown;
  cookies?: Record<string, string>;
}
interface ExpressResponse {
  statusCode: number;
  status(code: number): ExpressResponse;
  json(body: unknown): void;
  send(body?: unknown): void;
}
type ExpressNext = () => void;

export function bloomExpressMiddleware(config: BloomConfig) {
  const bloom = new BloomClient(config);
  const trackInputs = config.features?.trackInputs ?? false;
  const trackSessions = config.features?.trackSessions ?? false;
  const blockInline = config.features?.blockInline ?? true;

  return async (req: ExpressRequest, res: ExpressResponse, next: ExpressNext) => {
    const startTime = Date.now();

    // Build the event payload
    const event: SiteEventPayload = {
      method: req.method,
      path: req.path,
      host: req.hostname || (req.headers.host as string) || '',
      ip: req.ip || req.socket.remoteAddress || '0.0.0.0',
      userAgent: (req.headers['user-agent'] as string) || undefined,
      ja4: req.headers['user-agent']
        ? BloomClient.computeJA4(req.headers['user-agent'] as string, req.headers['accept-language'] as string)
        : undefined,
    };

    // Track session if enabled
    if (trackSessions) {
      const authHeader = req.headers['authorization'] as string | undefined;
      const sessionId =
        authHeader?.replace(/^Bearer\s+/i, '') ||
        req.cookies?.session ||
        (req.headers['x-session-id'] as string);
      if (sessionId) {
        event.sessionId = sessionId.slice(0, 64);
        // Check revocation list (cached)
        const sessionCheck = await bloom.checkSession(sessionId);
        if (sessionCheck.revoked) {
          return res.status(401).json({
            error: 'Session revoked by Bloom SIEM',
            reason: sessionCheck.reason,
          });
        }
      }
    }

    // Track inputs (sanitized) if enabled
    if (trackInputs && req.body) {
      const sanitized = BloomClient.sanitizeInput(req.body);
      if (sanitized) {
        event.inputSnippet = sanitized;
        // Inline SQLi/XSS detection
        if (BloomClient.detectMaliciousInput(sanitized)) {
          event.inputSnippet = sanitized;
          // Mark for evaluation
        }
      }
    }

    // Scan uploaded files if enabled
    if (config.features?.scanFiles && req.files) {
      const files = Array.isArray(req.files) ? req.files : Object.values(req.files);
      for (const f of files as any[]) {
        // Compute SHA-256 using Web Crypto API (works in Edge Runtime + Node.js)
        try {
          const buf = f.data || f.buffer;
          let hash: string;
          if (buf instanceof ArrayBuffer) {
            const digest = await crypto.subtle.digest('SHA-256', buf);
            hash = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
          } else if (buf instanceof Uint8Array) {
            const digest = await crypto.subtle.digest('SHA-256', buf);
            hash = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
          } else if (typeof buf === 'string') {
            const encoder = new TextEncoder();
            const digest = await crypto.subtle.digest('SHA-256', encoder.encode(buf));
            hash = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
          } else {
            // Fallback: skip file scan if buffer type is unknown
            continue;
          }
          const scan = await bloom.scanFile({
            hash,
            name: f.name,
            size: f.size,
            mimeType: f.mimetype,
          });
          event.fileHash = hash;
          event.fileName = f.name;
          if (scan.verdict === 'malicious' && blockInline) {
            // Log + block
            bloom.trackEvent({ ...event, statusCode: 403, responseTime: Date.now() - startTime });
            return res.status(403).json({
              error: 'File blocked by Bloom SIEM',
              verdict: scan.verdict,
              signature: scan.signature,
            });
          }
        } catch {
          // Skip file scan on error
        }
      }
    }

    // Synchronous threat evaluation (cached, 500ms timeout, fails open)
    if (blockInline) {
      const decision = await bloom.evaluateThreat(event);
      if (decision.action === 'BLOCK') {
        bloom.trackEvent({
          ...event,
          statusCode: 403,
          responseTime: Date.now() - startTime,
        });
        return res.status(403).json({
          error: 'Access Denied by Bloom SIEM',
          rule: decision.rule,
        });
      }
    }

    // Hook response to capture status code + response time
    const originalSend = res.send.bind(res);
    res.send = (body?: any) => {
      event.statusCode = res.statusCode;
      event.responseTime = Date.now() - startTime;
      bloom.trackEvent(event);
      return originalSend(body);
    };

    next();
  };
}

// Convenience alias
export const Bloom = { init: bloomExpressMiddleware };
