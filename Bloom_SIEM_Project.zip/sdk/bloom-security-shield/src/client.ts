/**
 * @bloom-security/shield — Core Client
 *
 * The core engine that handles:
 *   - Authenticating to Bloom SIEM via BLOOM_PROJECT_ID + BLOOM_API_KEY
 *   - Fire-and-forget event logging (never blocks the user's request)
 *   - Threat evaluation (queries Bloom for block decisions)
 *   - File malware scanning (sends hash + metadata to Bloom sandbox API)
 *   - Session revocation polling (checks if any sessions should be killed)
 */

export interface BloomConfig {
  /** Bloom Project ID (generated when you add a domain on the dashboard) */
  projectId: string;
  /** Bloom API Key (secret — keep in environment variables) */
  apiKey: string;
  /** Bloom SIEM ingestion endpoint. Defaults to the cloud-hosted URL. */
  endpoint?: string;
  /** Feature toggles */
  features?: {
    trackInputs?: boolean;      // Capture form body / JSON body metadata
    scanFiles?: boolean;        // Hash uploaded files and check against Bloom
    trackSessions?: boolean;    // Read session cookies/JWT for revocation
    blockInline?: boolean;      // Synchronously block requests Bloom flags
  };
  /** Override the default log sampling rate (1.0 = log everything) */
  sampleRate?: number;
}

export interface SiteEventPayload {
  method: string;
  path: string;
  host: string;
  ip: string;
  userAgent?: string;
  ja3?: string;
  ja4?: string;
  asn?: string;
  countryCode?: string;
  statusCode?: number;
  responseTime?: number;
  sessionId?: string;
  inputSnippet?: string;   // sanitized, first 500 chars of body
  fileHash?: string;
  fileName?: string;
  fileSize?: number;
}

export interface ThreatDecision {
  action: 'ALLOW' | 'BLOCK' | 'CHALLENGE' | 'LOG';
  rule?: string;
  reason?: string;
}

export interface FileScanResult {
  verdict: 'clean' | 'malicious' | 'suspicious' | 'unknown';
  signature?: string;
  rule?: string;
}

export interface SessionCheckResult {
  revoked: boolean;
  reason?: string;
}

const DEFAULT_ENDPOINT = 'https://bloom-siem.com/api/sdk';

export class BloomClient {
  private config: BloomConfig;
  private endpoint: string;
  private revokedSessions: Set<string> = new Set();
  private lastSessionCheck = 0;
  private sessionCacheMs = 5000; // refresh revocation list every 5s

  constructor(config: BloomConfig) {
    if (!config.projectId || !config.apiKey) {
      throw new Error('Bloom Shield requires projectId and apiKey');
    }
    this.config = config;
    this.endpoint = (config.endpoint || DEFAULT_ENDPOINT).replace(/\/$/, '');
  }

  /**
   * Fire-and-forget: send event to Bloom. NEVER throws, NEVER blocks.
   * If Bloom is unreachable, the event is silently dropped so the user's
   * application is never affected.
   */
  public trackEvent(event: SiteEventPayload): void {
    // Sampling
    const rate = this.config.sampleRate ?? 1.0;
    if (rate < 1.0 && Math.random() > rate) return;

    const payload = {
      ...event,
      projectId: this.config.projectId,
      timestamp: new Date().toISOString(),
    };

    fetch(`${this.endpoint}/ingest`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Bloom-Project': this.config.projectId,
        'X-Bloom-Key': this.config.apiKey,
      },
      body: JSON.stringify(payload),
    }).catch(() => {
      // Silent — never break the user's app
    });
  }

  /**
   * Synchronous threat evaluation. Queries Bloom's blocklist for the
   * given IP/session. Cached locally for 5 seconds to avoid latency.
   */
  public async evaluateThreat(event: Partial<SiteEventPayload>): Promise<ThreatDecision> {
    try {
      const res = await fetch(`${this.endpoint}/evaluate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Bloom-Project': this.config.projectId,
          'X-Bloom-Key': this.config.apiKey,
        },
        body: JSON.stringify({
          ip: event.ip,
          path: event.path,
          userAgent: event.userAgent,
          sessionId: event.sessionId,
        }),
        signal: AbortSignal.timeout(500), // 500ms hard timeout
      });
      if (!res.ok) return { action: 'ALLOW' };
      return (await res.json()) as ThreatDecision;
    } catch {
      // Network error or timeout — fail open (allow) so we don't break the user's site
      return { action: 'ALLOW' };
    }
  }

  /**
   * Scan a file before allowing the upload to proceed.
   * Sends SHA-256 hash to Bloom; if malicious, the SDK returns BLOCK.
   */
  public async scanFile(file: { hash: string; name: string; size: number; mimeType?: string }): Promise<FileScanResult> {
    try {
      const res = await fetch(`${this.endpoint}/scan-file`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Bloom-Project': this.config.projectId,
          'X-Bloom-Key': this.config.apiKey,
        },
        body: JSON.stringify({
          hash: file.hash,
          name: file.name,
          size: file.size,
          mimeType: file.mimeType,
        }),
        signal: AbortSignal.timeout(2000),
      });
      if (!res.ok) return { verdict: 'unknown' };
      return (await res.json()) as FileScanResult;
    } catch {
      return { verdict: 'unknown' };
    }
  }

  /**
   * Check if a session ID has been revoked by the Bloom dashboard.
   * Polls Bloom's revocation list (cached 5s locally).
   */
  public async checkSession(sessionId: string): Promise<SessionCheckResult> {
    // Fast path — check local cache
    if (this.revokedSessions.has(sessionId)) {
      return { revoked: true, reason: 'revoked by Bloom dashboard' };
    }

    // Refresh cache every 5s
    const now = Date.now();
    if (now - this.lastSessionCheck > this.sessionCacheMs) {
      this.lastSessionCheck = now;
      try {
        const res = await fetch(`${this.endpoint}/revoked-sessions?projectId=${this.config.projectId}`, {
          headers: {
            'X-Bloom-Project': this.config.projectId,
            'X-Bloom-Key': this.config.apiKey,
          },
          signal: AbortSignal.timeout(500),
        });
        if (res.ok) {
          const data = (await res.json()) as { sessions: string[] };
          this.revokedSessions = new Set(data.sessions);
          if (this.revokedSessions.has(sessionId)) {
            return { revoked: true, reason: 'revoked by Bloom dashboard' };
          }
        }
      } catch {
        // Fail open
      }
    }

    return { revoked: false };
  }

  /**
   * Compute a JA4-style TLS fingerprint string.
   * (Simplified — real JA4 needs raw TLS bytes; this is a heuristic
   *  from User-Agent + accept-headers for SDK contexts that don't
   *  have access to the raw TLS layer.)
   */
  public static computeJA4(userAgent: string, acceptLanguage?: string): string {
    // Deterministic 36-char hash from UA + lang
    const input = `${userAgent}|${acceptLanguage || ''}`;
    let hash = 0;
    for (let i = 0; i < input.length; i++) {
      hash = ((hash << 5) - hash) + input.charCodeAt(i);
      hash |= 0;
    }
    const hex = Math.abs(hash).toString(16).padStart(8, '0');
    return `t13d5212h1_${hex}b3658495_8e6e362c5eac`.slice(0, 36);
  }

  /**
   * Sanitize an input string for telemetry — keep first 500 chars,
   * strip passwords/credit-card patterns.
   */
  public static sanitizeInput(input: unknown): string | undefined {
    if (!input) return undefined;
    let str: string;
    try {
      str = typeof input === 'string' ? input : JSON.stringify(input);
    } catch {
      return undefined;
    }
    // Strip password fields
    str = str.replace(/"(password|passwd|pwd|secret|token|creditcard|ccv)"\s*:\s*"[^"]*"/gi, '"$1":"***"');
    // Strip credit-card-like numbers
    str = str.replace(/\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g, '****-****-****-****');
    return str.slice(0, 500);
  }

  /**
   * Quick heuristic SQLi / XSS detector — used inline before the
   * round-trip to Bloom. Returns true if the input looks malicious.
   */
  public static detectMaliciousInput(input: string): boolean {
    const lower = input.toLowerCase();
    const sqliPatterns = [
      /'\s*or\s*'?1'?\s*=?\s*1/i,
      /union\s+select/i,
      /;\s*drop\s+table/i,
      /\bexec\s*\(/i,
      /xp_cmdshell/i,
      /information_schema/i,
    ];
    const xssPatterns = [
      /<script[^>]*>/i,
      /javascript:/i,
      /onerror\s*=/i,
      /onload\s*=/i,
      /<iframe/i,
      /document\.cookie/i,
    ];
    return sqliPatterns.some((p) => p.test(lower)) || xssPatterns.some((p) => p.test(lower));
  }
}
