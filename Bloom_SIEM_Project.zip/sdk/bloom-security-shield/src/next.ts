/**
 * @bloom-security/shield — Next.js middleware wrapper
 *
 * Usage (in middleware.ts at project root):
 *
 *   import { Bloom } from '@bloom-security/shield/next';
 *
 *   export default Bloom.init({
 *     projectId: process.env.BLOOM_PROJECT_ID!,
 *     apiKey: process.env.BLOOM_API_KEY!,
 *     features: { trackInputs: true, trackSessions: true },
 *   });
 *
 *   export const config = {
 *     matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
 *   };
 */

import { BloomClient, BloomConfig, SiteEventPayload } from './client';

// Minimal Next.js type shims — we don't want to bundle next as a hard dep
interface NextRequestShim {
  method: string;
  nextUrl: { pathname: string; host: string };
  headers: { get(name: string): string | null };
  cookies: { get(name: string): { value: string } | undefined };
  text(): Promise<string>;
}
interface NextResponseShim {
  status: number;
  json(body: unknown): NextResponseShim;
  next(): NextResponseShim;
}
interface NextResponseStatic {
  json(body: unknown, init?: { status: number }): NextResponseShim;
  next(): NextResponseShim;
}
const NextResponse: NextResponseStatic = {
  json(body) { return { status: 200, json: () => ({ status: 200, json: () => ({} as NextResponseShim), next: () => ({} as NextResponseShim) }), next: () => ({} as NextResponseShim) } as NextResponseShim; },
  next() { return { status: 200, json: () => ({} as NextResponseShim), next: () => ({} as NextResponseShim) } as NextResponseShim; },
};

export function bloomNextMiddleware(config: BloomConfig) {
  const bloom = new BloomClient(config);
  const trackInputs = config.features?.trackInputs ?? false;
  const trackSessions = config.features?.trackSessions ?? false;
  const blockInline = config.features?.blockInline ?? true;

  return async (req: NextRequestShim): Promise<NextResponseShim> => {
    const startTime = Date.now();
    const url = req.nextUrl;

    // Skip static assets
    if (url.pathname.match(/\.(ico|png|jpg|jpeg|gif|svg|css|js|woff|woff2|ttf|map)$/)) {
      return NextResponse.next();
    }

    const event: SiteEventPayload = {
      method: req.method,
      path: url.pathname,
      host: url.host,
      ip: req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
          req.headers.get('x-real-ip') ||
          '0.0.0.0',
      userAgent: req.headers.get('user-agent') || undefined,
      ja4: req.headers.get('user-agent')
        ? BloomClient.computeJA4(
            req.headers.get('user-agent')!,
            req.headers.get('accept-language') || undefined
          )
        : undefined,
    };

    // Session tracking
    if (trackSessions) {
      const sessionId =
        req.headers.get('authorization')?.replace(/^Bearer\s+/i, '') ||
        req.cookies.get('session')?.value ||
        req.headers.get('x-session-id');
      if (sessionId) {
        event.sessionId = sessionId.slice(0, 64);
        const sessionCheck = await bloom.checkSession(sessionId);
        if (sessionCheck.revoked) {
          return NextResponse.json(
            { error: 'Session revoked by Bloom SIEM', reason: sessionCheck.reason },
            { status: 401 }
          );
        }
      }
    }

    // Input tracking (only for POST/PUT/PATCH)
    if (trackInputs && ['POST', 'PUT', 'PATCH'].includes(req.method)) {
      try {
        const body = await req.text();
        if (body) {
          const sanitized = BloomClient.sanitizeInput(body);
          if (sanitized) event.inputSnippet = sanitized;
        }
      } catch {
        // Skip if body can't be read
      }
    }

    // Threat evaluation
    if (blockInline) {
      const decision = await bloom.evaluateThreat(event);
      if (decision.action === 'BLOCK') {
        bloom.trackEvent({ ...event, statusCode: 403, responseTime: Date.now() - startTime });
        return NextResponse.json(
          { error: 'Access Denied by Bloom SIEM', rule: decision.rule },
          { status: 403 }
        );
      }
    }

    // Log the event (fire-and-forget)
    event.statusCode = 200;
    event.responseTime = Date.now() - startTime;
    bloom.trackEvent(event);

    return NextResponse.next();
  };
}

export const Bloom = { init: bloomNextMiddleware };
