# bloom-security-shield

Bloom SIEM Shield — middleware SDK for deep-visibility security monitoring.

## Install

```bash
npm install bloom-security-shield
# or
bun add bloom-security-shield
```

## Quick start (Next.js)

1. Add your domain on the Bloom SIEM dashboard → get `BLOOM_PROJECT_ID` and `BLOOM_API_KEY`.
2. Add to `.env.local`:

```
BLOOM_PROJECT_ID=proj_xxxxxxxx
BLOOM_API_KEY=xxxxx-xxxx-xxxx-xxxx
```

3. Create `middleware.ts` at your project root:

```ts
import { Bloom } from 'bloom-security-shield/next';

export default Bloom.init({
  projectId: process.env.BLOOM_PROJECT_ID!,
  apiKey: process.env.BLOOM_API_KEY!,
  features: {
    trackInputs: true,
    scanFiles: true,
    trackSessions: true,
    blockInline: true,
  },
});

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
```

## Quick start (Express)

```ts
import express from 'express';
import { Bloom } from 'bloom-security-shield/express';

const app = express();
app.use(express.json());
app.use(Bloom.init({
  projectId: process.env.BLOOM_PROJECT_ID!,
  apiKey: process.env.BLOOM_API_KEY!,
  features: { trackInputs: true, scanFiles: true, trackSessions: true },
}));
```

## Features

| Feature | What it does |
|---------|--------------|
| `trackInputs` | Sanitizes and streams form/JSON body metadata to Bloom for SQLi/XSS detection |
| `scanFiles` | SHA-256-hashes uploaded files and checks them against Bloom's malware signature DB before allowing the upload |
| `trackSessions` | Reads session cookies / JWT / Authorization header and checks Bloom's revocation list — instantly logs out flagged users |
| `blockInline` | Synchronously blocks requests Bloom's AI has flagged (500ms timeout, fails open) |

## How it works

```
[ User's App ] ──(Bloom SDK middleware)──> [ Bloom SIEM /api/sdk/ingest ]
                                              │
                                              ├─ Detect SQLi/XSS in inputs
                                              ├─ Hash + scan uploaded files
                                              ├─ Check session revocation list
                                              ├─ Run custom WAF rules
                                              └─ AI threat evaluation
```

The SDK is **fire-and-forget**: telemetry calls never block the request. Synchronous checks (threat evaluation, session revocation, file scan) have hard timeouts and fail open so your app stays up even if Bloom is unreachable.

## Privacy

- Passwords, tokens, and credit-card numbers are scrubbed from inputs before transmission
- Only the first 500 chars of any input are sent
- File contents are never sent — only SHA-256 hashes

## License

MIT
