#!/bin/bash
cd /home/z/my-project/mini-services/siem-realtime
nohup /usr/local/bin/bun index.ts > service.log 2>&1 &
PID=$!
echo $PID > service.pid
echo "Started with PID $PID"
