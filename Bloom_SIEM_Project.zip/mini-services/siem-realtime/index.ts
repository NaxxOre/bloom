import { createServer } from 'http'
import { Server } from 'socket.io'

// Global error handlers to prevent silent crashes
process.on('uncaughtException', (err) => {
  console.error('[Bloom SIEM] Uncaught exception:', err.message)
  console.error(err.stack)
})
process.on('unhandledRejection', (err) => {
  console.error('[Bloom SIEM] Unhandled rejection:', err)
})

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
})

// ============================================================
// Bloom SIEM — Real-time heartbeat + AI auto-action simulator
// ============================================================

const HOSTS = [
  'web-prod-01', 'web-prod-02', 'db-prod-01', 'db-prod-02', 'app-prod-01',
  'app-prod-02', 'mail-srv-01', 'vpn-gw-01', 'dc-01', 'dc-02',
  'fileshare-01', 'bastion-01', 'k8s-master-01', 'k8s-worker-01', 'k8s-worker-02',
]

const SAMPLE_IPS = [
  '185.220.101.45', '193.27.228.142', '45.155.205.83', '91.219.236.166',
  '194.169.175.10', '103.97.176.30', '212.193.30.25', '167.94.138.44',
  '198.235.24.34', '139.59.8.173',
]

const ALERT_TEMPLATES = [
  { title: 'SSH Brute Force Detected', severity: 'high', tactic: 'Credential Access', technique: 'T1110', source: 'network' },
  { title: 'Suspicious PowerShell Execution', severity: 'high', tactic: 'Execution', technique: 'T1059.001', source: 'endpoint' },
  { title: 'C2 Beacon to Malicious Host', severity: 'critical', tactic: 'Command & Control', technique: 'T1071', source: 'network' },
  { title: 'Mimikatz Detected', severity: 'critical', tactic: 'Credential Access', technique: 'T1003', source: 'endpoint' },
  { title: 'Data Exfiltration Pattern', severity: 'high', tactic: 'Exfiltration', technique: 'T1041', source: 'behavior' },
  { title: 'Port Scan from External', severity: 'low', tactic: 'Reconnaissance', technique: 'T1046', source: 'external' },
  { title: 'Malware Signature Match', severity: 'critical', tactic: 'Execution', technique: 'T1204', source: 'endpoint' },
  { title: 'DNS Tunneling Suspected', severity: 'high', tactic: 'Command & Control', technique: 'T1071.004', source: 'network' },
  { title: 'Privileged Account Created', severity: 'high', tactic: 'Persistence', technique: 'T1136', source: 'endpoint' },
  { title: 'Lateral Movement via SMB', severity: 'high', tactic: 'Lateral Movement', technique: 'T1021.002', source: 'network' },
  { title: 'AV Service Stopped', severity: 'critical', tactic: 'Defense Evasion', technique: 'T1562.001', source: 'endpoint' },
  { title: 'New Service Created', severity: 'medium', tactic: 'Persistence', technique: 'T1543.003', source: 'endpoint' },
  { title: 'Anomalous Off-Hours Login', severity: 'medium', tactic: 'Discovery', technique: 'T1087', source: 'behavior' },
  { title: 'Failed Login Storm', severity: 'medium', tactic: 'Credential Access', technique: 'T1110.001', source: 'external' },
]

const ACTION_TEMPLATES = [
  { action: 'block_ip', label: 'IP blocked at perimeter firewall' },
  { action: 'isolate_host', label: 'Host network-isolated via EDR' },
  { action: 'disable_user', label: 'User account disabled in AD' },
  { action: 'quarantine_file', label: 'File quarantined by endpoint agent' },
  { action: 'create_ticket', label: 'Incident ticket created (INC-2026-)' },
  { action: 'notify', label: 'SOC on-call paged via PagerDuty' },
]

const LOG_TEMPLATES = [
  'TCP connection from external host',
  'SSH authentication failed',
  'HTTP request to suspicious domain',
  'File modified in system directory',
  'User login from new location',
  'DNS query to known DGA domain',
  'Firewall rule blocked connection',
  'Process spawned with elevated privileges',
  'Outbound HTTPS connection',
  'New listening port opened',
]

// In-memory live state shared with clients
const state = {
  heartbeatIntervalMin: 5, // configurable from Intelligence page
  aiActionsEnabled: true,
  onlineAgents: HOSTS.length,
  totalAgents: HOSTS.length,
  lastHeartbeats: new Map<string, number>(),
}

function rand<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)] }
function randInt(min: number, max: number) { return Math.floor(Math.random() * (max - min + 1)) + min }

// Initialize heartbeats
HOSTS.forEach((h) => state.lastHeartbeats.set(h, Date.now()))

io.on('connection', (socket) => {
  console.log(`[Bloom SIEM] Client connected: ${socket.id}`)

  // Send current state on connect
  socket.emit('hello', {
    server: 'bloom-siem-realtime',
    version: '1.0.0',
    state: {
      heartbeatIntervalMin: state.heartbeatIntervalMin,
      aiActionsEnabled: state.aiActionsEnabled,
      onlineAgents: state.onlineAgents,
      totalAgents: state.totalAgents,
    },
  })

  // Allow client to push config changes from Intelligence page
  socket.on('config:update', (cfg: { heartbeatIntervalMin?: number; aiActionsEnabled?: boolean }) => {
    if (cfg.heartbeatIntervalMin !== undefined) {
      state.heartbeatIntervalMin = cfg.heartbeatIntervalMin
      console.log(`[Config] heartbeat interval = ${cfg.heartbeatIntervalMin} min`)
    }
    if (cfg.aiActionsEnabled !== undefined) {
      state.aiActionsEnabled = cfg.aiActionsEnabled
      console.log(`[Config] AI actions = ${cfg.aiActionsEnabled}`)
    }
    io.emit('config:updated', state)
  })

  socket.on('disconnect', () => {
    console.log(`[Bloom SIEM] Client disconnected: ${socket.id}`)
  })
})

// ============================================================
// Heartbeat loop — every 10 seconds, send a batch of heartbeats
// ============================================================
setInterval(() => {
  const now = Date.now()
  const intervalMs = state.heartbeatIntervalMin * 60 * 1000
  // Jitter: agents don't all check in at exactly the same time
  const jitter = randInt(0, 8000)

  // Each iteration, ~3 random agents check in
  for (let i = 0; i < 3; i++) {
    const host = rand(HOSTS)
    state.lastHeartbeats.set(host, now + jitter)
    io.emit('heartbeat', {
      hostname: host,
      ts: new Date().toISOString(),
      intervalMin: state.heartbeatIntervalMin,
    })
  }

  // Check for offline agents (last seen > offline threshold = 3x heartbeat interval)
  const offlineThresholdMs = intervalMs * 3
  let online = 0
  for (const host of HOSTS) {
    const last = state.lastHeartbeats.get(host) || 0
    if (now - last < offlineThresholdMs) online++
    else if (now - last < offlineThresholdMs + 60000) {
      // just went offline — emit alert
      io.emit('agent:offline', {
        hostname: host,
        ts: new Date().toISOString(),
        reason: `No heartbeat for ${Math.floor((now - last) / 60000)} min (threshold: ${Math.floor(offlineThresholdMs / 60000)} min)`,
      })
    }
  }
  state.onlineAgents = online
  io.emit('agents:stats', {
    online: online,
    total: state.totalAgents,
    coveragePct: Math.round((online / state.totalAgents) * 100),
  })
}, 10000)

// ============================================================
// Live log stream — emit every 3 seconds
// ============================================================
setInterval(() => {
  const severityRoll = Math.random()
  const severity =
    severityRoll > 0.95 ? 'critical' :
    severityRoll > 0.85 ? 'high' :
    severityRoll > 0.65 ? 'medium' :
    severityRoll > 0.35 ? 'low' : 'info'

  io.emit('log', {
    id: `log_${Date.now()}_${randInt(1000, 9999)}`,
    source: rand(['firewall', 'endpoint', 'auth', 'network', 'cloud', 'dns']),
    severity,
    message: rand(LOG_TEMPLATES),
    srcIp: Math.random() > 0.5 ? rand(SAMPLE_IPS) : `10.0.${randInt(1, 50)}.${randInt(2, 254)}`,
    dstPort: rand([22, 80, 443, 3389, 445, 53, 8080]),
    ts: new Date().toISOString(),
  })
}, 3000)

// ============================================================
// Alert + AI action stream — emit every ~12 seconds
// ============================================================
setInterval(() => {
  const tmpl = rand(ALERT_TEMPLATES)
  const alert = {
    id: `alert_${Date.now()}_${randInt(1000, 9999)}`,
    title: tmpl.title,
    severity: tmpl.severity,
    mitreTactic: tmpl.tactic,
    mitreTechnique: tmpl.technique,
    source: tmpl.source,
    srcIp: rand(SAMPLE_IPS),
    agent: rand(HOSTS),
    triggeredBy: Math.random() > 0.5 ? 'ai' : 'rule',
    ts: new Date().toISOString(),
  }
  io.emit('alert', alert)

  // If high/critical severity and AI actions enabled → trigger auto-action
  if (state.aiActionsEnabled && ['high', 'critical'].includes(tmpl.severity)) {
    setTimeout(() => {
      const act = rand(ACTION_TEMPLATES)
      const target =
        act.action === 'block_ip' ? alert.srcIp :
        act.action === 'isolate_host' ? alert.agent :
        act.action === 'disable_user' ? rand(['admin', 'svc_account', 'analyst-jane', 'developer-01']) :
        act.action === 'quarantine_file' ? `${rand(['a1b2', 'f9e8', '9a8b', 'c3d4'])}c3d4e5f6...` :
        act.action === 'create_ticket' ? `INC-2026-${randInt(100, 999)}` :
        'soc-team@bloom.io'

      io.emit('action', {
        id: `action_${Date.now()}_${randInt(1000, 9999)}`,
        action: act.action,
        target,
        label: act.label,
        alertId: alert.id,
        alertTitle: alert.title,
        severity: alert.severity,
        initiatedBy: 'ai',
        status: 'success',
        ts: new Date().toISOString(),
      })
    }, 1500 + randInt(0, 2000))
  }
}, 12000)

const PORT = 3003
httpServer.listen(PORT, () => {
  console.log(`[Bloom SIEM] Realtime service listening on port ${PORT}`)
  console.log(`[Bloom SIEM] Heartbeat interval: ${state.heartbeatIntervalMin} min | AI actions: ${state.aiActionsEnabled}`)
})

process.on('SIGTERM', () => {
  console.log('[Bloom SIEM] Shutting down...')
  httpServer.close(() => process.exit(0))
})
process.on('SIGINT', () => {
  console.log('[Bloom SIEM] Shutting down...')
  httpServer.close(() => process.exit(0))
})
