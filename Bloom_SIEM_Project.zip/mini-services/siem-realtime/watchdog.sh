#!/bin/bash
exec >> /home/z/my-project/mini-services/siem-realtime/service.log 2>&1
cd /home/z/my-project/mini-services/siem-realtime
while true; do
  echo "[$(date)] [watchdog] Starting siem-realtime..."
  /usr/local/bin/bun index.ts
  EXIT_CODE=$?
  echo "[$(date)] [watchdog] Process exited with code $EXIT_CODE, restarting in 2s..."
  sleep 2
done
