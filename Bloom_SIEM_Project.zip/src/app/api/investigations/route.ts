import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  const investigations = await db.investigation.findMany({
    orderBy: { createdAt: 'desc' },
    take: 100,
  })
  return NextResponse.json({ investigations })
}
