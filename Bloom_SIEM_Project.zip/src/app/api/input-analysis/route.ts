import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const projectId = searchParams.get('projectId')
  const windowHours = Number(searchParams.get('window') || '24')
  if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 })
  const since = new Date(Date.now() - windowHours * 60 * 60 * 1000)
  const events = await db.siteEvent.findMany({ where: { projectId, timestamp: { gt: since }, inputSnippet: { not: null } }, select: { ip: true, path: true, inputSnippet: true, timestamp: true, action: true }, take: 1000, orderBy: { timestamp: 'desc' } })
  const allEvents = await db.siteEvent.findMany({ where: { projectId, timestamp: { gt: since } }, select: { path: true, method: true, statusCode: true, inputSnippet: true, action: true, ip: true }, take: 2000, orderBy: { timestamp: 'desc' } })
  
  // Parse input fields
  const fieldStats: Record<string, { count: number; ips: Set<string>; paths: Set<string> }> = {}
  const ipFieldStats: Record<string, Record<string, { count: number; lastAt: number }>> = {}
  const spikeData: { time: string; ip: string; field: string; count: number }[] = []
  
  for (const evt of events) {
    if (!evt.inputSnippet) continue
    const fields = parseInputFields(evt.inputSnippet)
    for (const fieldName of fields) {
      if (!fieldStats[fieldName]) fieldStats[fieldName] = { count: 0, ips: new Set(), paths: new Set() }
      fieldStats[fieldName].count++; fieldStats[fieldName].ips.add(evt.ip); fieldStats[fieldName].paths.add(evt.path)
      if (!ipFieldStats[evt.ip]) ipFieldStats[evt.ip] = {}
      if (!ipFieldStats[evt.ip][fieldName]) ipFieldStats[evt.ip][fieldName] = { count: 0, lastAt: 0 }
      ipFieldStats[evt.ip][fieldName].count++
      const bucket = new Date(evt.timestamp); bucket.setMinutes(0, 0, 0)
      const bucketKey = bucket.toISOString().slice(11, 16)
      const existing = spikeData.find((s) => s.time === bucketKey && s.ip === evt.ip && s.field === fieldName)
      if (existing) existing.count++; else spikeData.push({ time: bucketKey, ip: evt.ip, field: fieldName, count: 1 })
    }
  }
  
  const bruteForceDetected: { ip: string; field: string; count: number; severity: string }[] = []
  for (const [ip, fields] of Object.entries(ipFieldStats)) {
    for (const [field, stats] of Object.entries(fields)) {
      if (stats.count >= 5) bruteForceDetected.push({ ip, field, count: stats.count, severity: stats.count >= 20 ? 'critical' : stats.count >= 10 ? 'high' : 'medium' })
    }
  }
  
  // Site discovery
  const routeMap: Record<string, { count: number; methods: Set<string>; statusCodes: Set<number> }> = {}
  for (const evt of allEvents) {
    if (!routeMap[evt.path]) routeMap[evt.path] = { count: 0, methods: new Set(), statusCodes: new Set() }
    routeMap[evt.path].count++; if (evt.method) routeMap[evt.path].methods.add(evt.method); if (evt.statusCode) routeMap[evt.path].statusCodes.add(evt.statusCode)
  }
  const allRoutes = Object.entries(routeMap).map(([path, data]) => ({ path, count: data.count, methods: Array.from(data.methods), statusCodes: Array.from(data.statusCodes), accessible: !Array.from(data.statusCodes).some((s) => s >= 400) })).sort((a, b) => b.count - a.count)
  const inaccessibleRoutes = allRoutes.filter((r) => !r.accessible)
  const allInputFields = Object.entries(fieldStats).map(([name, data]) => ({ name, count: data.count, paths: Array.from(data.paths) })).sort((a, b) => b.count - a.count)
  const allButtons: Record<string, number> = {}
  for (const evt of allEvents) { if (evt.inputSnippet && evt.inputSnippet.startsWith('click:')) { const btn = evt.inputSnippet.slice(6); allButtons[btn] = (allButtons[btn] || 0) + 1 } }
  const allButtonFields = Object.entries(allButtons).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count)
  
  return NextResponse.json({
    window: `${windowHours}h`, totalInputEvents: events.length,
    topFields: Object.entries(fieldStats).map(([name, stats]) => ({ name, count: stats.count, uniqueIps: stats.ips.size, paths: Array.from(stats.paths).slice(0, 3) })).sort((a, b) => b.count - a.count).slice(0, 15),
    topIpsPerField: Object.entries(ipFieldStats).map(([ip, fields]) => ({ ip, fields: Object.entries(fields).map(([field, stats]) => ({ field, count: stats.count })).sort((a, b) => b.count - a.count), totalRequests: Object.values(fields).reduce((s, f) => s + f.count, 0) })).sort((a, b) => b.totalRequests - a.totalRequests).slice(0, 10),
    bruteForceDetected: bruteForceDetected.sort((a, b) => b.count - a.count),
    spikeData: spikeData.sort((a, b) => a.time.localeCompare(b.time)).slice(0, 100),
    siteDiscovery: { totalRoutes: allRoutes.length, totalInputFields: allInputFields.length, totalButtons: allButtonFields.length, totalInaccessible: inaccessibleRoutes.length, allRoutes: allRoutes.slice(0, 50), inaccessibleRoutes: inaccessibleRoutes.slice(0, 20), allInputFields: allInputFields.slice(0, 30), allButtons: allButtonFields.slice(0, 20) },
  })
}

function parseInputFields(snippet: string): string[] {
  const fields: string[] = []
  if (!snippet) return fields
  if (snippet.startsWith('click:')) return [snippet]
  try { const json = JSON.parse(snippet); if (typeof json === 'object' && json !== null) { for (const key of Object.keys(json)) fields.push(key); return fields } } catch {}
  if (snippet.includes('=')) { const pairs = snippet.split('&'); for (const pair of pairs) { const eq = pair.indexOf('='); if (eq > 0) { const name = pair.slice(0, eq).trim(); if (name && name.length < 50) fields.push(name) } } }
  return fields
}
