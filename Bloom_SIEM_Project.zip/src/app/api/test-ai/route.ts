import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export const runtime = 'nodejs'
export const maxDuration = 30

/**
 * Real AI provider test — actually calls the configured LLM API
 * with a small test prompt and returns the response (or error).
 *
 * POST /api/test-ai
 * Body: { providerId?: string }
 * If no providerId, uses the default enabled provider.
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}))
  const { providerId } = body as { providerId?: string }

  // Find provider
  let provider
  if (providerId) {
    provider = await db.aIProvider.findUnique({ where: { id: providerId } })
  } else {
    provider = await db.aIProvider.findFirst({
      where: { enabled: true, NOT: { apiKey: '' } },
      orderBy: [{ isDefault: 'desc' }, { createdAt: 'asc' }],
    })
    // Fallback to built-in zai
    if (!provider) {
      provider = await db.aIProvider.findFirst({ where: { provider: 'zai' } })
    }
  }

  if (!provider) {
    return NextResponse.json({ error: 'No AI provider configured' }, { status: 404 })
  }

  if (!provider.apiKey && provider.provider !== 'zai') {
    return NextResponse.json({
      error: `${provider.label}: no API key set. Add a key first.`,
    }, { status: 400 })
  }

  const startTime = Date.now()
  const testPrompt = 'Reply with exactly: "Bloom SIEM AI test OK" and nothing else.'

  try {
    let response: string

    if (provider.provider === 'zai') {
      // Use built-in SDK
      const zai = await ZAI.create()
      const completion = await zai.chat.completions.create({
        messages: [
          { role: 'system', content: 'You are a connectivity test. Reply exactly as instructed.' },
          { role: 'user', content: testPrompt },
        ],
        temperature: 0,
        max_tokens: 20,
      })
      response = completion.choices[0]?.message?.content || '(empty response)'
    } else {
      // OpenAI-compatible HTTP API
      const baseUrl = (provider.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '')
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${provider.apiKey}`,
      }
      if (provider.provider === 'anthropic') {
        headers['x-api-key'] = provider.apiKey
        headers['anthropic-version'] = '2023-06-01'
        delete headers.Authorization
      }

      const url = provider.provider === 'anthropic'
        ? `${baseUrl}/messages`
        : `${baseUrl}/chat/completions`

      const reqBody = provider.provider === 'anthropic'
        ? {
            model: provider.model,
            max_tokens: 20,
            messages: [{ role: 'user', content: testPrompt }],
          }
        : {
            model: provider.model,
            temperature: 0,
            max_tokens: 20,
            messages: [
              { role: 'system', content: 'Reply exactly as instructed.' },
              { role: 'user', content: testPrompt },
            ],
          }

      const res = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(reqBody),
        signal: AbortSignal.timeout(20000),
      })

      if (!res.ok) {
        const errText = await res.text().catch(() => '(no error body)')
        return NextResponse.json({
          success: false,
          provider: provider.label,
          model: provider.model,
          latencyMs: Date.now() - startTime,
          error: `HTTP ${res.status} ${res.statusText}: ${errText.slice(0, 300)}`,
        }, { status: 200 })
      }

      const data = await res.json()
      response = provider.provider === 'anthropic'
        ? data.content?.[0]?.text
        : data.choices?.[0]?.message?.content
      response = response || '(empty response)'

      // Update lastUsedAt
      await db.aIProvider.update({
        where: { id: provider.id },
        data: { lastUsedAt: new Date() },
      })
    }

    return NextResponse.json({
      success: true,
      provider: provider.label,
      providerType: provider.provider,
      model: provider.model,
      latencyMs: Date.now() - startTime,
      response: response.trim(),
      timestamp: new Date().toISOString(),
    })
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({
      success: false,
      provider: provider.label,
      model: provider.model,
      latencyMs: Date.now() - startTime,
      error: msg,
    }, { status: 200 })
  }
}
