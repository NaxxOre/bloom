import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const assets = await db.asset.findMany({ orderBy: { name: 'asc' } })
  return NextResponse.json({ assets })
}
