import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const config = await db.telegramConfig.findFirst()
  if (!config) return NextResponse.json({ config: null })
  return NextResponse.json({ config: { ...config, botToken: config.botToken ? `${config.botToken.slice(0, 8)}…${config.botToken.slice(-4)}` : '' } })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { botToken, chatId, enabled, notifyOnBlock, notifyOnMalware, notifyOnHighSeverity, requireApprovalForBlock } = body
  if (!botToken || !chatId) return NextResponse.json({ error: 'botToken and chatId required' }, { status: 400 })
  try {
    const res = await fetch(`https://api.telegram.org/bot${botToken}/getMe`)
    const data = await res.json()
    if (!data.ok) return NextResponse.json({ error: `Telegram rejected bot token: ${data.description || 'invalid'}` }, { status: 400 })
  } catch (err) { return NextResponse.json({ error: `Failed to reach Telegram: ${err instanceof Error ? err.message : 'unknown'}` }, { status: 400 }) }
  const existing = await db.telegramConfig.findFirst()
  let saved
  if (existing) {
    saved = await db.telegramConfig.update({ where: { id: existing.id }, data: { botToken: String(botToken), chatId: String(chatId), enabled: enabled !== undefined ? Boolean(enabled) : true, notifyOnBlock: notifyOnBlock !== undefined ? Boolean(notifyOnBlock) : true, notifyOnMalware: notifyOnMalware !== undefined ? Boolean(notifyOnMalware) : true, notifyOnHighSeverity: notifyOnHighSeverity !== undefined ? Boolean(notifyOnHighSeverity) : true, requireApprovalForBlock: requireApprovalForBlock !== undefined ? Boolean(requireApprovalForBlock) : false } })
  } else {
    saved = await db.telegramConfig.create({ data: { botToken: String(botToken), chatId: String(chatId), enabled: enabled !== undefined ? Boolean(enabled) : true, notifyOnBlock: notifyOnBlock !== undefined ? Boolean(notifyOnBlock) : true, notifyOnMalware: notifyOnMalware !== undefined ? Boolean(notifyOnMalware) : true, notifyOnHighSeverity: notifyOnHighSeverity !== undefined ? Boolean(notifyOnHighSeverity) : true, requireApprovalForBlock: requireApprovalForBlock !== undefined ? Boolean(requireApprovalForBlock) : false } })
  }
  try { await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ chat_id: chatId, text: '🛡️ Bloom SIEM Telegram integration connected. You will receive security alerts here.', parse_mode: 'HTML' }) }) } catch {}
  return NextResponse.json({ config: { ...saved, botToken: `${saved.botToken.slice(0, 8)}…${saved.botToken.slice(-4)}` } })
}

export async function DELETE() {
  const existing = await db.telegramConfig.findFirst()
  if (existing) await db.telegramConfig.delete({ where: { id: existing.id } })
  return NextResponse.json({ success: true })
}
