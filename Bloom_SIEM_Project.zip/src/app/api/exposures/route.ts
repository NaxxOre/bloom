import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  const targets = await db.monitoredTarget.findMany()
  const exposures: any[] = []
  for (const t of targets) {
    if (!t.lastResult) continue
    let analysis: any
    try { analysis = JSON.parse(t.lastResult) } catch { continue }
    
    // SSL issues
    if (analysis.ssl && !analysis.ssl.valid) {
      exposures.push({ id: `${t.id}-ssl`, title: `Invalid SSL on ${t.hostname}`, description: `SSL certificate is invalid or expired`, severity: 'high', category: 'ssl_issue', assetName: t.hostname, status: 'open' })
    } else if (analysis.ssl && analysis.ssl.daysUntilExpiry !== undefined && analysis.ssl.daysUntilExpiry < 30) {
      exposures.push({ id: `${t.id}-ssl-exp`, title: `SSL expiring soon on ${t.hostname}`, description: `Certificate expires in ${analysis.ssl.daysUntilExpiry} days`, severity: 'medium', category: 'ssl_issue', assetName: t.hostname, status: 'open' })
    }
    // Server header
    if (analysis.http?.server) {
      exposures.push({ id: `${t.id}-srv`, title: `Server header reveals software on ${t.hostname}`, description: `Server: "${analysis.http.server}"`, severity: 'low', category: 'info_disclosure', assetName: t.hostname, status: 'open' })
    }
    // Sensitive ports
    const sensitive = (analysis.ports || []).filter((p: any) => p.open && [22, 23, 3389, 3306, 5432, 6379, 9200].includes(p.port))
    for (const p of sensitive) {
      exposures.push({ id: `${t.id}-port-${p.port}`, title: `Sensitive port ${p.port}/${p.service} open on ${t.hostname}`, description: `Port ${p.port} is reachable`, severity: p.port === 23 ? 'critical' : 'high', category: 'open_port', assetName: t.hostname, status: 'open' })
    }
  }
  return NextResponse.json({ exposures })
}
