import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  const sources = await db.logSource.findMany({ orderBy: { name: 'asc' } })
  return NextResponse.json({ sources })
}
