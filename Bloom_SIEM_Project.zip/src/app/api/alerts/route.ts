import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const status = searchParams.get('status') || 'all'
  const severity = searchParams.get('severity') || 'all'
  const limit = Number(searchParams.get('limit') || '100')

  const where: Record<string, unknown> = {}
  if (status !== 'all') where.status = status
  if (severity !== 'all') where.severity = severity

  const alerts = await db.alert.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: { actions: true },
  })

  return NextResponse.json({ alerts, total: alerts.length })
}

export async function PATCH(req: NextRequest) {
  const body = await req.json()
  const { alertId, action } = body as { alertId: string; action: 'triage' | 'escalate' | 'close' | 'reopen' }

  const statusMap = { triage: 'triaged', escalate: 'escalated', close: 'closed', reopen: 'new' } as const
  const updated = await db.alert.update({
    where: { id: alertId },
    data: { status: statusMap[action] },
  })
  return NextResponse.json({ alert: updated })
}
