import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const severity = searchParams.get('severity') || 'all'
  const source = searchParams.get('source') || 'all'
  const limit = Number(searchParams.get('limit') || '200')

  const where: Record<string, unknown> = {}
  if (severity !== 'all') where.severity = severity
  if (source !== 'all') where.source = source

  const logs = await db.log.findMany({
    where,
    orderBy: { timestamp: 'desc' },
    take: limit,
    include: { agent: true },
  })

  return NextResponse.json({ logs, total: logs.length })
}
