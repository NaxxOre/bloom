import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const config = await db.intelligenceConfig.findFirst()
  if (!config) {
    const created = await db.intelligenceConfig.create({ data: {} })
    return NextResponse.json({ config: created })
  }
  return NextResponse.json({ config })
}

export async function PATCH(req: NextRequest) {
  const body = await req.json()
  const {
    heartbeatInterval,
    offlineThreshold,
    autoTriageEnabled,
    aiActionsEnabled,
    correlationWindow,
    logRetentionDays,
    alertRetentionDays,
    minSeverityForAuto,
  } = body

  let config = await db.intelligenceConfig.findFirst()
  if (!config) {
    config = await db.intelligenceConfig.create({ data: {} })
  }

  const updated = await db.intelligenceConfig.update({
    where: { id: config.id },
    data: {
      ...(heartbeatInterval !== undefined && { heartbeatInterval }),
      ...(offlineThreshold !== undefined && { offlineThreshold }),
      ...(autoTriageEnabled !== undefined && { autoTriageEnabled }),
      ...(aiActionsEnabled !== undefined && { aiActionsEnabled }),
      ...(correlationWindow !== undefined && { correlationWindow }),
      ...(logRetentionDays !== undefined && { logRetentionDays }),
      ...(alertRetentionDays !== undefined && { alertRetentionDays }),
      ...(minSeverityForAuto !== undefined && { minSeverityForAuto }),
    },
  })

  return NextResponse.json({ config: updated })
}
