import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { promises as fs } from 'node:fs'
import path from 'node:path'
import os from 'node:os'

export const runtime = 'nodejs'

/**
 * Real system stats — no fake data.
 * Reports actual database record counts, real DB file size,
 * real process uptime, real memory usage of this Node process.
 */
export async function GET() {
  // Real DB table counts
  const [
    agentCount, logCount, alertCount, investigationCount,
    actionCount, ruleCount, providerCount, domainCount,
    logSourceCount, monitoredTargetCount, verdictCount,
    complianceCount, intelConfigCount,
  ] = await Promise.all([
    db.agent.count(),
    db.log.count(),
    db.alert.count(),
    db.investigation.count(),
    db.autoAction.count(),
    db.autoActionRule.count(),
    db.aIProvider.count(),
    db.domain.count(),
    db.logSource.count(),
    db.monitoredTarget.count(),
    db.analystVerdict.count(),
    db.complianceControl.count(),
    db.intelligenceConfig.count(),
  ])

  // Real DB file size on disk
  const dbPath = path.join(process.cwd(), 'db', 'custom.db')
  let dbFileSizeBytes = 0
  try {
    const stat = await fs.stat(dbPath)
    dbFileSizeBytes = stat.size
  } catch {
    // db file might be elsewhere
  }

  // Real process stats
  const memUsage = process.memoryUsage()
  const cpuUsage = process.cpuUsage()
  const uptimeSec = Math.floor(process.uptime())
  const startedAt = new Date(Date.now() - uptimeSec * 1000).toISOString()

  // Real system stats
  const totalMem = os.totalmem()
  const freeMem = os.freemem()
  const usedMem = totalMem - freeMem
  const loadAvg = os.loadavg()
  const cpuCount = os.cpus().length

  // Real table list
  const tables = [
    { name: 'Agent', count: agentCount, model: 'Agent' },
    { name: 'Log', count: logCount, model: 'Log' },
    { name: 'Alert', count: alertCount, model: 'Alert' },
    { name: 'Investigation', count: investigationCount, model: 'Investigation' },
    { name: 'AutoAction', count: actionCount, model: 'AutoAction' },
    { name: 'AutoActionRule', count: ruleCount, model: 'AutoActionRule' },
    { name: 'AIProvider', count: providerCount, model: 'AIProvider' },
    { name: 'Domain', count: domainCount, model: 'Domain' },
    { name: 'LogSource', count: logSourceCount, model: 'LogSource' },
    { name: 'MonitoredTarget', count: monitoredTargetCount, model: 'MonitoredTarget' },
    { name: 'AnalystVerdict', count: verdictCount, model: 'AnalystVerdict' },
    { name: 'ComplianceControl', count: complianceCount, model: 'ComplianceControl' },
    { name: 'IntelligenceConfig', count: intelConfigCount, model: 'IntelligenceConfig' },
  ]

  const totalRecords = tables.reduce((sum, t) => sum + t.count, 0)

  return NextResponse.json({
    database: {
      engine: 'SQLite (Prisma)',
      filePath: dbPath,
      fileSizeBytes: dbFileSizeBytes,
      fileSizeHuman: formatBytes(dbFileSizeBytes),
      totalRecords,
      tables,
    },
    process: {
      pid: process.pid,
      platform: process.platform,
      nodeVersion: process.version,
      uptimeSec,
      uptimeHuman: formatDuration(uptimeSec),
      startedAt,
      memory: {
        rss: memUsage.rss,
        rssHuman: formatBytes(memUsage.rss),
        heapUsed: memUsage.heapUsed,
        heapUsedHuman: formatBytes(memUsage.heapUsed),
        heapTotal: memUsage.heapTotal,
        heapTotalHuman: formatBytes(memUsage.heapTotal),
        external: memUsage.external,
        externalHuman: formatBytes(memUsage.external),
      },
      cpu: {
        user: cpuUsage.user,
        system: cpuUsage.system,
        userMs: `${(cpuUsage.user / 1000).toFixed(0)}ms`,
        systemMs: `${(cpuUsage.system / 1000).toFixed(0)}ms`,
      },
    },
    system: {
      hostname: os.hostname(),
      osType: os.type(),
      osRelease: os.release(),
      arch: os.arch(),
      cpuCount,
      cpuModel: os.cpus()[0]?.model || 'unknown',
      cpuSpeedMhz: os.cpus()[0]?.speed || 0,
      loadAvg1: loadAvg[0].toFixed(2),
      loadAvg5: loadAvg[1].toFixed(2),
      loadAvg15: loadAvg[2].toFixed(2),
      memory: {
        total: totalMem,
        totalHuman: formatBytes(totalMem),
        free: freeMem,
        freeHuman: formatBytes(freeMem),
        used: usedMem,
        usedHuman: formatBytes(usedMem),
        usedPct: ((usedMem / totalMem) * 100).toFixed(1) + '%',
      },
    },
    bloom: {
      version: '2.5.0',
      build: '20260630',
      license: 'Open Source (MIT)',
      repository: 'github.com/NaxxOre/Bloom_SIEM',
    },
  })
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`
}

function formatDuration(sec: number): string {
  const d = Math.floor(sec / 86400)
  const h = Math.floor((sec % 86400) / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = sec % 60
  if (d > 0) return `${d}d ${h}h ${m}m`
  if (h > 0) return `${h}h ${m}m ${s}s`
  if (m > 0) return `${m}m ${s}s`
  return `${s}s`
}
