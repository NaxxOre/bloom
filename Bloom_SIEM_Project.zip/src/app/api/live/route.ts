import { NextRequest } from 'next/server'
import { tickLiveEvents, getRecentEvents, getConfig, subscribe, type LiveEvent } from '@/lib/live-events'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export async function GET(req: NextRequest) {
  // Tick the event generator on each request
  tickLiveEvents()

  const since = Number(req.nextUrl.searchParams.get('since') || '0')
  const mode = req.nextUrl.searchParams.get('mode') || 'poll'

  if (mode === 'sse') {
    // Server-Sent Events stream
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      start(controller) {
        // Send recent events first
        const initial = getRecentEvents(since, 30)
        for (const e of initial) {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(e)}\n\n`))
        }
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: 'hello', config: getConfig() })}\n\n`))

        // Subscribe to live events
        const unsubscribe = subscribe((event: LiveEvent) => {
          try {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`))
          } catch {
            // controller may be closed
          }
        })

        // Heartbeat comment every 25s to keep connection alive
        const ping = setInterval(() => {
          try {
            controller.enqueue(encoder.encode(`: ping\n\n`))
          } catch {
            // closed
          }
        }, 25000)

        // Clean up on abort
        req.signal.addEventListener('abort', () => {
          clearInterval(ping)
          unsubscribe()
          try { controller.close() } catch { /* already closed */ }
        })
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no',
      },
    })
  }

  // Polling mode — return recent events
  const events = getRecentEvents(since, 50)
  return Response.json({ events, config: getConfig() })
}
