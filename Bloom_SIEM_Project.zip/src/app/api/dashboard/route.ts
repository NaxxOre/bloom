import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const rangeDays = Number(req.nextUrl.searchParams.get('days') || '21')

  // REAL counts — no fake 1.6M logs or 1100 alerts
  const [agents, alerts, investigations, logCount, actions, allAlerts, monitoredTargets, domains, logSources] = await Promise.all([
    db.agent.findMany(),
    db.alert.findMany({ take: 500, orderBy: { createdAt: 'desc' } }),
    db.investigation.findMany(),
    db.log.count(),
    db.autoAction.findMany({ take: 100, orderBy: { createdAt: 'desc' } }),
    db.alert.findMany({ take: 1000 }),
    db.monitoredTarget.count(),
    db.domain.count(),
    db.logSource.count(),
  ])

  const escalatedCount = alerts.filter((a) => ['escalated', 'closed'].includes(a.status)).length
  const triagedCount = alerts.filter((a) => a.status !== 'new').length
  const closedCount = alerts.filter((a) => a.status === 'closed').length
  const maliciousCount = investigations.filter((i) => i.malicious).length

  const totalAlerts = alerts.length
  const alertsTriagedPct = totalAlerts ? Math.round((triagedCount / totalAlerts) * 100) : 0
  const alertsClosedPct = totalAlerts ? Math.round((closedCount / totalAlerts) * 100) : 0
  const alertsEscalatedPct = totalAlerts ? Math.round((escalatedCount / totalAlerts) * 100) : 0
  const maliciousPct = investigations.length ? Math.round((maliciousCount / investigations.length) * 100) : 0

  // Coverage = how many monitored targets are up
  const targets = await db.monitoredTarget.findMany()
  const upTargets = targets.filter((t) => t.lastStatus === 'up').length
  const coveragePct = targets.length ? Math.round((upTargets / targets.length) * 100) : 0

  // Coverage trend — build from real target check history (or just show current as flat line if no history)
  const now = Date.now()
  const coverageSeries = Array.from({ length: rangeDays }, (_, i) => {
    const day = new Date(now - (rangeDays - 1 - i) * 24 * 60 * 60 * 1000)
    return { date: day.toISOString().slice(5, 10), coverage: coveragePct }
  })

  // MITRE tactic distribution (real, from actual alerts)
  const mitreCounts: Record<string, number> = {}
  for (const a of allAlerts) {
    if (!a.mitreTactic) continue
    mitreCounts[a.mitreTactic] = (mitreCounts[a.mitreTactic] || 0) + 1
  }
  const mitreData = Object.entries(mitreCounts)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8)

  // Alert origins (real)
  const originCounts: Record<string, number> = {}
  for (const a of allAlerts) {
    originCounts[a.source] = (originCounts[a.source] || 0) + 1
  }
  const originData = Object.entries(originCounts).map(([name, value]) => ({ name, value }))

  // Pipeline = real counts
  const pipeline = {
    logs: logCount,
    alerts: totalAlerts,
    escalated: escalatedCount,
    investigations: investigations.length,
    malicious: maliciousCount,
  }

  return NextResponse.json({
    metrics: {
      totalAgents: agents.length,
      agentsOnline: agents.filter((a) => a.status === 'online').length,
      agentsOffline: agents.filter((a) => a.status === 'offline').length,
      agentsDegraded: agents.filter((a) => a.status === 'degraded').length,
      totalAlerts,
      totalInvestigations: investigations.length,
      totalActions: actions.length,
      maliciousInvestigations: maliciousCount,
      totalLogs: logCount,
      totalMonitoredTargets: monitoredTargets,
      totalDomains: domains,
      totalLogSources: logSources,
    },
    pipeline,
    coverage: {
      pct: coveragePct,
      series: coverageSeries,
    },
    trend: {
      alertsTriagedPct,
      alertsClosedPct,
      alertsEscalatedPct,
      maliciousPct,
    },
    mitre: mitreData,
    origins: originData,
    recentActions: actions.slice(0, 8),
    recentAlerts: alerts.slice(0, 6),
  })
}
