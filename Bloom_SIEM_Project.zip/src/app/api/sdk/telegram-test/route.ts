import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}))
  const { message } = body as { message?: string }
  const config = await db.telegramConfig.findFirst()
  if (!config || !config.enabled) return NextResponse.json({ error: 'Telegram not configured' }, { status: 400 })
  const text = message || '🧪 Bloom SIEM test alert — Telegram integration is working.'
  try {
    const res = await fetch(`https://api.telegram.org/bot${config.botToken}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: config.chatId, text, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '✅ Approve', callback_data: 'bloom_approve' }, { text: '❌ Deny', callback_data: 'bloom_deny' }]] } }),
    })
    const data = await res.json()
    if (!data.ok) return NextResponse.json({ error: `Telegram error: ${data.description}` }, { status: 400 })
    return NextResponse.json({ success: true, messageId: data.result?.message_id })
  } catch (err) { return NextResponse.json({ error: err instanceof Error ? err.message : 'Failed' }, { status: 500 }) }
}
