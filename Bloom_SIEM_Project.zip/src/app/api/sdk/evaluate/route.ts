import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { lookupIp } from '@/lib/geo'

export const runtime = 'nodejs'

export async function OPTIONS() {
  return new NextResponse(null, { status: 200, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, X-Bloom-Project, X-Bloom-Key' } })
}

function corsJson(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, X-Bloom-Project, X-Bloom-Key' } })
}

export async function POST(req: NextRequest) {
  const projectId = req.headers.get('x-bloom-project')
  const apiKey = req.headers.get('x-bloom-key')
  if (!projectId || !apiKey) return corsJson({ action: 'ALLOW' })
  const project = await db.project.findFirst({ where: { projectId, apiKey } })
  if (!project) return corsJson({ action: 'ALLOW' })

  const body = await req.json().catch(() => ({}))
  const { ip, path, userAgent, sessionId } = body as { ip?: string; path?: string; userAgent?: string; sessionId?: string }

  let clientIp = ip || ''
  if (!clientIp || clientIp === '0.0.0.0' || clientIp === '127.0.0.1') {
    clientIp = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || ''
  }

  if (sessionId) {
    const revoked = await db.sessionRevocation.findFirst({ where: { projectId: project.id, sessionId: sessionId.slice(0, 64), expiresAt: { gt: new Date() } } })
    if (revoked) return corsJson({ action: 'BLOCK', rule: 'Session Revoked', reason: revoked.reason })
  }

  if (clientIp) {
    const blocked = await db.domain.findUnique({ where: { hostname: clientIp } })
    if (blocked?.status === 'blocked') return corsJson({ action: 'BLOCK', rule: 'IP Blocklist', reason: blocked.reason || 'IP blocked' })
  }

  if (clientIp && clientIp !== '0.0.0.0' && clientIp !== '127.0.0.1' && !clientIp.startsWith('21.')) {
    const geo = await lookupIp(clientIp)
    if (geo) {
      const countryRules = await db.autoActionRule.findMany({ where: { enabled: true, trigger: 'country' } })
      for (const rule of countryRules) {
        try { const cond = JSON.parse(rule.condition) as { countries?: string[] }
          if (cond.countries?.includes(geo.countryCode)) {
            // Only BLOCK if the rule's action is block_ip or block_country
            // If the action is notify, just log it — don't block
            if (rule.action === 'block_ip' || rule.action === 'block_country') {
              return corsJson({ action: 'BLOCK', rule: `Country Block: ${geo.country} (rule: ${rule.name})`, reason: `Traffic from ${geo.country} (${geo.countryCode}) is blocked by rule "${rule.name}"` })
            }
            // For notify/other actions, don't block — just continue
          }
        } catch {}
      }
    }
  }

  const rules = await db.customRule.findMany({ where: { OR: [{ projectId: project.id }, { projectId: null }], enabled: true }, orderBy: { priority: 'asc' } })
  for (const r of rules) {
    try { const cond = JSON.parse(r.condition) as Record<string, unknown>; let matched = true
      if (cond.ip && clientIp !== cond.ip) matched = false
      if (cond.path && path && !path.match(new RegExp(String(cond.path)))) matched = false
      if (cond.ua_contains && userAgent && !userAgent.toLowerCase().includes(String(cond.ua_contains).toLowerCase())) matched = false
      if (matched) { if (r.action === 'deny') return corsJson({ action: 'BLOCK', rule: r.name }); return corsJson({ action: r.action.toUpperCase() as 'ALLOW' | 'BLOCK' | 'CHALLENGE' | 'LOG', rule: r.name }) }
    } catch {}
  }

  return corsJson({ action: 'ALLOW' })
}
