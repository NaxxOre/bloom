import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { lookupIp } from '@/lib/geo'
import { runDetectionPlaybook } from '@/lib/detection-rules'

export const runtime = 'nodejs'

export async function OPTIONS() {
  return new NextResponse(null, { status: 200, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, X-Bloom-Project, X-Bloom-Key' } })
}

function corsResponse(data: unknown, status = 200) {
  return NextResponse.json(data, { status, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, X-Bloom-Project, X-Bloom-Key' } })
}

export async function POST(req: NextRequest) {
  const projectId = req.headers.get('x-bloom-project')
  const apiKey = req.headers.get('x-bloom-key')
  if (!projectId || !apiKey) return corsResponse({ error: 'Missing auth headers' }, 401)
  const project = await db.project.findFirst({ where: { projectId, apiKey } })
  if (!project) return corsResponse({ error: 'Invalid project credentials' }, 401)
  if (!project.firewallEnabled) return corsResponse({ success: true, stored: false })

  let body: Record<string, unknown>
  try { body = await req.json() } catch { return corsResponse({ error: 'Invalid JSON' }, 400) }
  const events = Array.isArray(body.events) ? body.events : [body]
  if (events.length === 0) return corsResponse({ error: 'No events' }, 400)

  const rawForwardedFor = req.headers.get('x-forwarded-for') || ''
  const forwardedIps = rawForwardedFor.split(',').map(s => s.trim()).filter(Boolean)
  const realIp = forwardedIps.find(ip => isPublicIp(ip)) || req.headers.get('x-real-ip') || req.headers.get('cf-connecting-ip') || null

  function isPublicIp(ip: string): boolean {
    if (ip === '::1' || ip === '::') return false
    if (ip.startsWith('10.') || ip.startsWith('192.168.') || ip.startsWith('127.')) return false
    if (ip.startsWith('172.')) { const p = ip.split('.'); const s = parseInt(p[1]||'0'); if (s >= 16 && s <= 31) return false }
    if (ip.startsWith('21.0.') || ip.startsWith('21.1.')) return false
    if (ip === 'unknown' || ip === '') return false
    return true
  }

  const customRules = await db.customRule.findMany({ where: { OR: [{ projectId: project.id }, { projectId: null }], enabled: true }, orderBy: { priority: 'asc' } })
  const toCreate = []
  for (const evt of events.slice(0, 200)) {
    const e = evt as Record<string, unknown>
    let action = 'allowed'; let rule: string | null = null
    let eventIp = String(e.ip || '')
    if (!eventIp || eventIp === '0.0.0.0' || eventIp === '127.0.0.1' || eventIp === 'undefined') eventIp = realIp || '0.0.0.0'

    for (const r of customRules) {
      try { const cond = JSON.parse(r.condition) as Record<string, unknown>; let matched = true
        if (cond.ip && eventIp !== cond.ip) matched = false
        if (cond.path && !String(e.path || '').match(new RegExp(String(cond.path)))) matched = false
        if (cond.ua_contains && !String(e.userAgent || '').toLowerCase().includes(String(cond.ua_contains).toLowerCase())) matched = false
        if (matched) { action = r.action; rule = r.name; await db.customRule.update({ where: { id: r.id }, data: { hits: { increment: 1 } } }); break }
      } catch {}
    }

    if (project.botProtectionEnabled && action === 'allowed') {
      const ua = String(e.userAgent || '').toLowerCase()
      if (/bot|crawler|spider|scraper|curl|python|go-http-client|undici/i.test(ua)) { action = 'challenged'; rule = 'Bot Protection' }
    }

    if (e.inputSnippet && typeof e.inputSnippet === 'string') {
      const lower = e.inputSnippet.toLowerCase()
      if (/union\s+select|<script|javascript:|onerror\s*=|;\s*drop\s+table/i.test(lower)) { action = 'denied'; rule = rule || 'SQLi/XSS Detection' }
    }

    let countryCode: string | null = null; let asn: string | null = null
    if (eventIp && eventIp !== '0.0.0.0' && eventIp !== '127.0.0.1' && !eventIp.startsWith('21.')) {
      const geo = await lookupIp(eventIp)
      if (geo) { countryCode = geo.countryCode; asn = geo.asn }
      if (action === 'allowed') {
        const countryRules = await db.autoActionRule.findMany({ where: { enabled: true, trigger: 'country' } })
        for (const cr of countryRules) { try { const cond = JSON.parse(cr.condition) as { countries?: string[] }; if (cond.countries?.includes(countryCode || '')) { if (cr.action === 'block_ip' || cr.action === 'block_country') { action = 'denied'; rule = `Country Block (rule: ${cr.name})`; break } } } catch {} }
      }
    }
    if (!e.countryCode && countryCode) e.countryCode = countryCode
    if (!e.asn && asn) e.asn = asn

    toCreate.push({ projectId: project.id, method: String(e.method || 'GET'), path: String(e.path || '/'), host: String(e.host || project.domain), ip: eventIp, userAgent: e.userAgent ? String(e.userAgent) : null, ja3: e.ja3 ? String(e.ja3) : null, ja4: e.ja4 ? String(e.ja4) : null, asn: e.asn ? String(e.asn) : null, countryCode: e.countryCode ? String(e.countryCode) : null, action, rule, inputSnippet: e.inputSnippet ? String(e.inputSnippet) : null, fileHash: e.fileHash ? String(e.fileHash) : null, fileName: e.fileName ? String(e.fileName) : null, fileVerdict: e.fileVerdict ? String(e.fileVerdict) : null, sessionId: e.sessionId ? String(e.sessionId) : null, responseTime: e.responseTime ? Number(e.responseTime) : null, statusCode: e.statusCode ? Number(e.statusCode) : null })

    if (e.fileVerdict === 'malicious' && e.sessionId) {
      await db.sessionRevocation.create({ data: { projectId: project.id, sessionId: String(e.sessionId).slice(0, 64), reason: `Malware upload: ${e.fileName || 'unknown file'}`, expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) } })
      await db.alert.create({ data: { title: `Malware Upload Blocked on ${project.domain}`, description: `File ${e.fileName || '(unknown)'} from IP ${eventIp} matched malware signature. Session revoked.`, severity: 'critical', status: 'new', mitreTactic: 'Execution', mitreTechnique: 'T1204', source: 'endpoint', srcIp: eventIp, triggeredBy: 'sdk' } })
    }
  }

  if (toCreate.length > 0) await db.siteEvent.createMany({ data: toCreate })
  await db.project.update({ where: { id: project.id }, data: { lastEventAt: new Date(), status: 'connected' } })

  // Run MITRE ATT&CK detection playbook (rule engine → AI analyst → automated response)
  let detectionResult = null
  try {
    detectionResult = await runDetectionPlaybook(project.id, project.domain)
  } catch { /* detection is best-effort */ }

  return corsResponse({ success: true, stored: toCreate.length, projectId: project.projectId, alertsCreated: detectionResult?.alertsCreated.length || 0 })
}
