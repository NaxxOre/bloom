import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const runtime = 'nodejs'

export async function GET(req: NextRequest) {
  const projectId = req.headers.get('x-bloom-project')
  const apiKey = req.headers.get('x-bloom-key')
  if (!projectId || !apiKey) return NextResponse.json({ sessions: [] })
  const project = await db.project.findFirst({ where: { projectId, apiKey } })
  if (!project) return NextResponse.json({ sessions: [] })
  const revocations = await db.sessionRevocation.findMany({ where: { projectId: project.id, expiresAt: { gt: new Date() } }, select: { sessionId: true } })
  return NextResponse.json({ sessions: revocations.map((r) => r.sessionId) })
}
