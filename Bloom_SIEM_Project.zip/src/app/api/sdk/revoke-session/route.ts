import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const runtime = 'nodejs'

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { projectId, sessionId, reason } = body as { projectId: string; sessionId: string; reason?: string }
  if (!projectId || !sessionId) return NextResponse.json({ error: 'projectId and sessionId required' }, { status: 400 })
  const revocation = await db.sessionRevocation.create({ data: { projectId, sessionId: sessionId.slice(0, 64), reason: reason || 'Manually revoked by SOC', expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) } })
  return NextResponse.json({ success: true, revocation })
}
