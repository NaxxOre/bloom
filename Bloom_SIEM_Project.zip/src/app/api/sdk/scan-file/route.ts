import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const runtime = 'nodejs'

const MALICIOUS_HASHES = new Set(['e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'])

export async function POST(req: NextRequest) {
  const projectId = req.headers.get('x-bloom-project')
  const apiKey = req.headers.get('x-bloom-key')
  if (!projectId || !apiKey) return NextResponse.json({ verdict: 'unknown' })
  const project = await db.project.findFirst({ where: { projectId, apiKey } })
  if (!project) return NextResponse.json({ verdict: 'unknown' })
  const body = await req.json().catch(() => ({}))
  const { hash, name, size, mimeType } = body as { hash?: string; name?: string; size?: number; mimeType?: string }
  if (!hash) return NextResponse.json({ verdict: 'unknown' })

  if (MALICIOUS_HASHES.has(hash.toLowerCase())) return NextResponse.json({ verdict: 'malicious', signature: 'Bloom.Malware.Generic', rule: 'hash-match' })

  const lowerName = (name || '').toLowerCase()
  const isExecutable = ['.php', '.phtml', '.php5', '.php7', '.pht', '.phar', '.exe', '.bat', '.cmd', '.sh', '.js', '.jsp'].some(ext => lowerName.endsWith(ext))
  const isDisguised = /\.[a-z0-9]+\.(php|phtml|exe|sh|bat|cmd|js|jsp|asp|aspx)$/i.test(name || '')

  if (isDisguised) return NextResponse.json({ verdict: 'malicious', signature: 'Bloom.DoubleExtension', rule: 'double-extension-disguise' })
  if (mimeType && isExecutable && mimeType.startsWith('image/')) return NextResponse.json({ verdict: 'suspicious', signature: 'Bloom.MimeTypeMismatch', rule: 'mime-extension-mismatch' })
  if (size && size > 50 * 1024 * 1024) return NextResponse.json({ verdict: 'suspicious', signature: 'Bloom.OversizedUpload', rule: 'oversized-upload' })

  return NextResponse.json({ verdict: 'clean' })
}
