import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const status = searchParams.get('status') || 'all'
  const type = searchParams.get('type') || 'all'

  const where: Record<string, unknown> = {}
  if (status !== 'all') where.status = status
  if (type !== 'all') where.type = type

  const domains = await db.domain.findMany({
    where,
    orderBy: { updatedAt: 'desc' },
  })

  return NextResponse.json({ domains, total: domains.length })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { hostname, type, status, reason, source } = body as {
    hostname: string
    type: string
    status: string
    reason?: string
    source?: string
  }

  const created = await db.domain.upsert({
    where: { hostname },
    update: {
      type: type || 'domain',
      status,
      reason: reason || null,
      source: source || 'manual',
      blockedAt: status === 'blocked' ? new Date() : null,
    },
    create: {
      hostname,
      type: type || 'domain',
      status,
      reason: reason || null,
      source: source || 'manual',
      blockedAt: status === 'blocked' ? new Date() : null,
    },
  })

  return NextResponse.json({ domain: created })
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })

  await db.domain.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
