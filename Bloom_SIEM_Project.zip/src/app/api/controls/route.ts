import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  const controls = await db.complianceControl.findMany({ orderBy: [{ framework: 'asc' }, { controlId: 'asc' }] })
  return NextResponse.json({ controls })
}
