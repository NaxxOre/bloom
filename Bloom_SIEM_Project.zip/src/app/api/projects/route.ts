import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const projects = await db.project.findMany({ orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ projects })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { name, domain } = body as { name: string; domain: string }
  if (!name || !domain) return NextResponse.json({ error: 'name and domain required' }, { status: 400 })
  const projectId = `proj_${Math.random().toString(36).slice(2, 14)}`
  const apiKey = `bloom_${Math.random().toString(36).slice(2, 18)}${Math.random().toString(36).slice(2, 18)}`
  try {
    const created = await db.project.create({ data: { name, domain: domain.toLowerCase(), projectId, apiKey } })
    return NextResponse.json({ project: created })
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Failed'
    if (msg.includes('Unique')) return NextResponse.json({ error: 'Domain already connected' }, { status: 409 })
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const body = await req.json()
  const { id, firewallEnabled, botProtectionEnabled, status } = body as { id: string; firewallEnabled?: boolean; botProtectionEnabled?: boolean; status?: string }
  const updated = await db.project.update({ where: { id }, data: { ...(firewallEnabled !== undefined && { firewallEnabled }), ...(botProtectionEnabled !== undefined && { botProtectionEnabled }), ...(status !== undefined && { status }) } })
  return NextResponse.json({ project: updated })
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
  await db.project.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
