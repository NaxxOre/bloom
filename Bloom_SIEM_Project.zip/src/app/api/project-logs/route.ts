import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const projectId = searchParams.get('projectId')
  const action = searchParams.get('action') || 'all'
  const limit = Number(searchParams.get('limit') || '100')
  if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 })
  const where: Record<string, unknown> = { projectId }
  if (action !== 'all') where.action = action
  const logs = await db.siteEvent.findMany({ where, orderBy: { timestamp: 'desc' }, take: Math.min(limit, 500) })
  return NextResponse.json({ logs, total: logs.length })
}
