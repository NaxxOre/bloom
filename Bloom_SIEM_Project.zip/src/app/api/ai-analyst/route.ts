import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { generateAnalystVerdict } from '@/lib/llm'

export const runtime = 'nodejs'
export const maxDuration = 60

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const alertId = searchParams.get('alertId')
  const investigationId = searchParams.get('investigationId')

  // Check for existing verdict
  const where: Record<string, unknown> = {}
  if (alertId) where.alertId = alertId
  if (investigationId) where.investigationId = investigationId

  const existing = await db.analystVerdict.findFirst({
    where,
    orderBy: { createdAt: 'desc' },
  })

  if (existing) {
    return NextResponse.json({
      verdict: existing,
      cached: true,
    })
  }

  return NextResponse.json({ verdict: null, cached: false })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { alertId, investigationId, force } = body as {
    alertId?: string
    investigationId?: string
    force?: boolean
  }

  if (!alertId && !investigationId) {
    return NextResponse.json({ error: 'alertId or investigationId required' }, { status: 400 })
  }

  // Check for existing verdict unless force=true
  if (!force) {
    const where: Record<string, unknown> = {}
    if (alertId) where.alertId = alertId
    if (investigationId) where.investigationId = investigationId
    const existing = await db.analystVerdict.findFirst({
      where,
      orderBy: { createdAt: 'desc' },
    })
    if (existing) {
      return NextResponse.json({ verdict: existing, cached: true })
    }
  }

  try {
    const result = await generateAnalystVerdict({ alertId, investigationId })

    // Persist the verdict
    const verdict = await db.analystVerdict.create({
      data: {
        alertId: alertId || null,
        investigationId: investigationId || null,
        verdict: result.verdict,
        confidence: result.confidence,
        summary: result.summary,
        rationale: result.rationale,
        recommendedActions: JSON.stringify(result.recommendedActions),
        keyFindings: JSON.stringify(result.keyFindings),
        provider: result.provider,
        model: result.model,
      },
    })

    // Update provider lastUsedAt
    await db.aIProvider.updateMany({
      where: { provider: result.provider },
      data: { lastUsedAt: new Date() },
    })

    return NextResponse.json({ verdict, cached: false })
  } catch (err) {
    console.error('[AI Analyst API] Error:', err)
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Failed to generate verdict' },
      { status: 500 }
    )
  }
}
