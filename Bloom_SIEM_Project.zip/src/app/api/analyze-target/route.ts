import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { analyzeAndPersist, generateTargetRiskAssessment } from '@/lib/target-analyzer'

export const runtime = 'nodejs'
export const maxDuration = 60

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { targetId, hostname, includeAi } = body as {
    targetId?: string
    hostname?: string
    includeAi?: boolean
  }

  let id = targetId
  if (!id && hostname) {
    // Create target on the fly if not exists
    const existing = await db.monitoredTarget.findUnique({ where: { hostname } })
    if (existing) {
      id = existing.id
    } else {
      const created = await db.monitoredTarget.create({
        data: {
          hostname,
          kind: hostname.startsWith('localhost') || hostname.startsWith('127.0.0.1') ? 'localhost' : 'domain',
        }
      })
      id = created.id
    }
  }

  if (!id) {
    return NextResponse.json({ error: 'targetId or hostname required' }, { status: 400 })
  }

  try {
    const analysis = await analyzeAndPersist(id)

    let aiRisk: Awaited<ReturnType<typeof generateTargetRiskAssessment>> | null = null
    if (includeAi !== false) {
      try {
        aiRisk = await generateTargetRiskAssessment(analysis)
      } catch (err) {
        console.error('[analyze-target] AI risk failed:', err)
      }
    }

    return NextResponse.json({ analysis, aiRisk })
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Analysis failed'
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const targetId = searchParams.get('targetId')

  if (!targetId) {
    return NextResponse.json({ error: 'targetId required' }, { status: 400 })
  }

  const target = await db.monitoredTarget.findUnique({ where: { id: targetId } })
  if (!target) {
    return NextResponse.json({ error: 'Target not found' }, { status: 404 })
  }

  return NextResponse.json({
    target: {
      ...target,
      lastResult: target.lastResult ? JSON.parse(target.lastResult) : null,
    },
  })
}
