import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const runtime = 'nodejs'

/**
 * Telegram webhook handler.
 * When a user clicks Approve/Deny on a Telegram message, Telegram sends a callback_query to this endpoint.
 *
 * To set up: 
 *   POST https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://your-bloom-url.com/api/telegram-webhook
 *
 * This handles:
 *   - bloom_approve → approve the blocked action (e.g. keep the IP blocked)
 *   - bloom_deny → deny/unblock (e.g. unblock the IP)
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const callbackQuery = body.callback_query

    if (!callbackQuery) {
      return NextResponse.json({ ok: true })
    }

    const callbackData = callbackQuery.data
    const messageId = callbackQuery.message?.message_id
    const chatId = callbackQuery.message?.chat?.id
    const fromUser = callbackQuery.from?.first_name || 'User'

    // Get the Telegram config to get the bot token
    const config = await db.telegramConfig.findFirst()
    if (!config) {
      return NextResponse.json({ ok: true })
    }

    let responseText = ''

    if (callbackData === 'bloom_approve') {
      responseText = `✅ ${fromUser} approved the action. The IP will remain blocked.`
      // The action was already taken — approve means "keep it blocked"
    } else if (callbackData === 'bloom_deny') {
      responseText = `❌ ${fromUser} denied the action. Investigating further.`
      // Deny means "unblock" — but we don't know which IP from the callback alone
      // In a production system, we'd store the pending action with a reference ID
    } else if (callbackData.startsWith('bloom_unblock:')) {
      // Specific unblock callback: bloom_unblock:<ip>
      const ip = callbackData.split(':')[1]
      if (ip) {
        await db.domain.updateMany({
          where: { hostname: ip },
          data: { status: 'allowed' },
        })
        responseText = `✅ ${fromUser} unblocked IP ${ip}.`
      }
    } else if (callbackData.startsWith('bloom_block:')) {
      // Specific block callback: bloom_block:<ip>
      const ip = callbackData.split(':')[1]
      if (ip) {
        await db.domain.upsert({
          where: { hostname: ip },
          update: { status: 'blocked', source: 'telegram', reason: `Blocked via Telegram by ${fromUser}` },
          create: { hostname: ip, type: 'ip', status: 'blocked', source: 'telegram', reason: `Blocked via Telegram by ${fromUser}` },
        })
        responseText = `🚫 ${fromUser} blocked IP ${ip}.`
      }
    } else {
      responseText = `Unknown action: ${callbackData}`
    }

    // Answer the callback query (removes the loading indicator on the button)
    await fetch(`https://api.telegram.org/bot${config.botToken}/answerCallbackQuery`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callback_query_id: callbackQuery.id,
        text: responseText.slice(0, 200),
      }),
    })

    // Edit the original message to show the decision
    if (messageId && chatId) {
      await fetch(`https://api.telegram.org/bot${config.botToken}/editMessageText`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          message_id: messageId,
          text: callbackQuery.message?.text + `\n\n━━━━━━━━━━\n${responseText}`,
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [] }, // Remove the buttons
        }),
      })
    }

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('[Telegram Webhook] Error:', err)
    return NextResponse.json({ ok: true }) // Always return ok to Telegram
  }
}

/**
 * GET endpoint to set up the webhook.
 * Visit /api/telegram-webhook?action=setup to register the webhook with Telegram.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const action = searchParams.get('action')

  if (action !== 'setup') {
    return NextResponse.json({ error: 'Use ?action=setup to register webhook' })
  }

  const config = await db.telegramConfig.findFirst()
  if (!config) {
    return NextResponse.json({ error: 'Telegram not configured. Save your bot token first.' })
  }

  // Get the Bloom URL from the request
  const bloomUrl = `${req.nextUrl.protocol}//${req.nextUrl.host}`

  try {
    const res = await fetch(`https://api.telegram.org/bot${config.botToken}/setWebhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: `${bloomUrl}/api/telegram-webhook`,
        allowed_updates: ['callback_query'],
      }),
    })
    const data = await res.json()
    if (data.ok) {
      return NextResponse.json({
        success: true,
        message: `Webhook registered! Telegram will send button clicks to ${bloomUrl}/api/telegram-webhook`,
        webhookUrl: `${bloomUrl}/api/telegram-webhook`,
      })
    } else {
      return NextResponse.json({ error: data.description || 'Failed to set webhook' })
    }
  } catch (err) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Failed' })
  }
}
