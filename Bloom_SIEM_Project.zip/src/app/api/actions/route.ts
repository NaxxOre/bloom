import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const status = searchParams.get('status') || 'all'
  const limit = Number(searchParams.get('limit') || '100')

  const where: Record<string, unknown> = {}
  if (status !== 'all') where.status = status

  const actions = await db.autoAction.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: { rule: true, alert: true },
  })
  return NextResponse.json({ actions, total: actions.length })
}

// Manually trigger an action (e.g. block IP from UI)
export async function POST(req: NextRequest) {
  const body = await req.json()
  const { action, target, reason } = body as { action: string; target: string; reason?: string }

  const created = await db.autoAction.create({
    data: {
      action,
      target,
      status: 'success',
      details: `Manual action: ${reason || 'user-initiated'}`,
      initiatedBy: 'user',
    },
  })

  return NextResponse.json({ action: created })
}
