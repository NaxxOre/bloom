import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  const connectors = await db.dataConnector.findMany({ orderBy: { name: 'asc' } })
  return NextResponse.json({ connectors })
}
