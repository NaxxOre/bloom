import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  const targets = await db.monitoredTarget.findMany({ orderBy: { createdAt: 'desc' } })
  const assets = targets.map((t) => {
    let analysis: any = null
    try { analysis = t.lastResult ? JSON.parse(t.lastResult) : null } catch {}
    const openPorts = analysis?.ports?.filter((p: any) => p.open) || []
    return {
      id: t.id,
      hostname: t.hostname,
      kind: t.kind,
      lastStatus: t.lastStatus,
      lastResult: analysis,
      openPorts,
      ssl: analysis?.ssl || null,
      http: analysis?.http || null,
    }
  })
  return NextResponse.json({ assets })
}
