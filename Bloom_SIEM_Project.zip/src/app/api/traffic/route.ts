import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const runtime = 'nodejs'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const projectId = searchParams.get('projectId')
  const windowHours = Number(searchParams.get('window') || '24')
  if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 })
  const project = await db.project.findUnique({ where: { id: projectId } })
  if (!project) return NextResponse.json({ error: 'Project not found' }, { status: 404 })
  const since = new Date(Date.now() - windowHours * 60 * 60 * 1000)
  const where = { projectId, timestamp: { gt: since } }
  const [totalEvents, allowedCount, deniedCount, challengedCount, loggedCount, rateLimitedCount, topIps, topJa4, topAsn, topUa, topPaths, topHosts, customRules, recentEvents] = await Promise.all([
    db.siteEvent.count({ where }),
    db.siteEvent.count({ where: { ...where, action: 'allowed' } }),
    db.siteEvent.count({ where: { ...where, action: 'denied' } }),
    db.siteEvent.count({ where: { ...where, action: 'challenged' } }),
    db.siteEvent.count({ where: { ...where, action: 'logged' } }),
    db.siteEvent.count({ where: { ...where, action: 'rate_limited' } }),
    db.siteEvent.groupBy({ by: ['ip'], where, _count: true, orderBy: { _count: { ip: 'desc' } }, take: 10 }),
    db.siteEvent.groupBy({ by: ['ja4'], where: { ...where, ja4: { not: null } }, _count: true, orderBy: { _count: { ja4: 'desc' } }, take: 10 }),
    db.siteEvent.groupBy({ by: ['asn'], where: { ...where, asn: { not: null } }, _count: true, orderBy: { _count: { asn: 'desc' } }, take: 10 }),
    db.siteEvent.groupBy({ by: ['userAgent'], where: { ...where, userAgent: { not: null } }, _count: true, orderBy: { _count: { userAgent: 'desc' } }, take: 10 }),
    db.siteEvent.groupBy({ by: ['path'], where, _count: true, orderBy: { _count: { path: 'desc' } }, take: 10 }),
    db.siteEvent.groupBy({ by: ['host'], where, _count: true, orderBy: { _count: { host: 'desc' } }, take: 10 }),
    db.customRule.findMany({ where: { OR: [{ projectId }, { projectId: null }], enabled: true }, orderBy: { priority: 'asc' } }),
    db.siteEvent.findMany({ where, orderBy: { timestamp: 'desc' }, take: 20 }),
  ])
  return NextResponse.json({
    project: { id: project.id, name: project.name, domain: project.domain, status: project.status, firewallEnabled: project.firewallEnabled, botProtectionEnabled: project.botProtectionEnabled, lastEventAt: project.lastEventAt },
    window: `${windowHours}h`,
    overview: { firewall: project.firewallEnabled ? 'active' : 'inactive', botProtection: project.botProtectionEnabled ? 'active' : 'inactive', customRules: customRules.length, totalEvents, allowed: allowedCount, denied: deniedCount, challenged: challengedCount, logged: loggedCount, rateLimited: rateLimitedCount },
    topIps: topIps.map((r) => ({ ip: r.ip, count: r._count.ip })),
    topJa4: topJa4.map((r) => ({ ja4: r.ja4, count: r._count.ja4 })),
    topAsn: topAsn.map((r) => ({ asn: r.asn, count: r._count.asn })),
    topUserAgents: topUa.map((r) => ({ ua: r.userAgent, count: r._count.userAgent })),
    topPaths: topPaths.map((r) => ({ path: r.path, count: r._count.path })),
    topHosts: topHosts.map((r) => ({ host: r.host, count: r._count.host })),
    rules: customRules.map((r) => ({ id: r.id, name: r.name, description: r.description, action: r.action, hits: r.hits, enabled: r.enabled })),
    recentEvents: recentEvents.map((e) => ({ id: e.id, method: e.method, path: e.path, ip: e.ip, action: e.action, rule: e.rule, userAgent: e.userAgent, statusCode: e.statusCode, responseTime: e.responseTime, timestamp: e.timestamp })),
  })
}
