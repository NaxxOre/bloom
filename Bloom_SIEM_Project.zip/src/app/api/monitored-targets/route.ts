import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const targets = await db.monitoredTarget.findMany({ orderBy: { createdAt: 'desc' } })
  return NextResponse.json({
    targets: targets.map((t) => ({
      ...t,
      lastResult: t.lastResult ? JSON.parse(t.lastResult) : null,
    })),
  })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { hostname, label, notes, kind } = body as {
    hostname: string
    label?: string
    notes?: string
    kind?: string
  }

  if (!hostname) {
    return NextResponse.json({ error: 'hostname required' }, { status: 400 })
  }

  // Auto-detect kind
  const detectedKind = kind || (
    hostname.startsWith('localhost') || hostname.startsWith('127.0.0.1') ? 'localhost' :
    /^\d{1,3}(\.\d{1,3}){3}/.test(hostname) ? 'ip' : 'domain'
  )

  try {
    const created = await db.monitoredTarget.create({
      data: {
        hostname,
        kind: detectedKind,
        label: label || null,
        notes: notes || null,
      },
    })
    return NextResponse.json({ target: created })
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Failed to create target'
    if (msg.includes('Unique constraint')) {
      return NextResponse.json({ error: 'Target already exists' }, { status: 409 })
    }
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })

  await db.monitoredTarget.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
