import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const [rules, actions] = await Promise.all([
    db.autoActionRule.findMany({ orderBy: { createdAt: 'desc' } }),
    db.autoAction.findMany({
      take: 200,
      orderBy: { createdAt: 'desc' },
      include: { rule: true, alert: true },
    }),
  ])
  return NextResponse.json({ rules, actions })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { name, description, trigger, condition, action, cooldownMin } = body

  const rule = await db.autoActionRule.create({
    data: {
      name,
      description,
      trigger,
      condition: condition || JSON.stringify({ minSeverity: 'high' }),
      action,
      cooldownMin: cooldownMin || 30,
      enabled: true,
    },
  })
  return NextResponse.json({ rule })
}

export async function PATCH(req: NextRequest) {
  const body = await req.json()
  const { ruleId, enabled } = body as { ruleId: string; enabled: boolean }

  const rule = await db.autoActionRule.update({
    where: { id: ruleId },
    data: { enabled },
  })
  return NextResponse.json({ rule })
}
