import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const projectId = searchParams.get('projectId')
  const where = projectId ? { projectId } : {}
  const rules = await db.customRule.findMany({ where, orderBy: { priority: 'asc' } })
  return NextResponse.json({ rules })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { name, description, condition, action, priority, projectId } = body
  if (!name || !condition || !action) return NextResponse.json({ error: 'name, condition, action required' }, { status: 400 })
  const rule = await db.customRule.create({ data: { name, description: description || '', condition, action, priority: priority ?? 100, projectId: projectId || null } })
  return NextResponse.json({ rule })
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
  await db.customRule.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
