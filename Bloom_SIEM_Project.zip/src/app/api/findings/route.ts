import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  const findings = await db.finding.findMany({ orderBy: { detectedAt: 'desc' } })
  return NextResponse.json({ findings })
}
