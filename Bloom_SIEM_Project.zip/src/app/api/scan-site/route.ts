import { NextRequest, NextResponse } from 'next/server'
import { scanAndStoreProject } from '@/lib/site-scanner'

export const runtime = 'nodejs'
export const maxDuration = 60

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { projectId } = body as { projectId?: string }
  if (!projectId) return NextResponse.json({ error: 'projectId required' }, { status: 400 })
  try {
    const result = await scanAndStoreProject(projectId)
    return NextResponse.json({ success: true, scan: { title: result.title, routesFound: result.routes.length, formsFound: result.forms.length, buttonsFound: result.buttons.length, linksFound: result.links.length, scanDuration: result.scanDuration } })
  } catch (err) { return NextResponse.json({ error: err instanceof Error ? err.message : 'Scan failed' }, { status: 500 }) }
}
