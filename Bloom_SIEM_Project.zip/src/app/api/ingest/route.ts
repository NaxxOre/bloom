import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { runDetectionRules, isSourceBlocked } from '@/lib/detection-rules'

export const runtime = 'nodejs'

/**
 * Real log ingestion endpoint.
 * Accepts single log events or batch arrays via POST.
 * Validates against LogSource shared secret if configured.
 * Runs real detection rules against ingested logs to create real alerts.
 *
 * Usage:
 *   POST /api/ingest?source=web-logs-syslog
 *   Body: { events: [{ source, severity, message, srcIp, ... }] }
 *   OR:   { source, severity, message, srcIp, ... }  (single event)
 */
export async function POST(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const sourceName = searchParams.get('source')

  if (!sourceName) {
    return NextResponse.json({ error: 'source query param required' }, { status: 400 })
  }

  // Validate source
  const logSource = await db.logSource.findUnique({ where: { name: sourceName } })
  if (!logSource) {
    return NextResponse.json({ error: `Unknown log source: ${sourceName}` }, { status: 404 })
  }
  if (!logSource.enabled) {
    return NextResponse.json({ error: `Log source ${sourceName} is disabled` }, { status: 403 })
  }

  // Validate shared secret if configured
  if (logSource.sharedSecret) {
    const authHeader = req.headers.get('authorization') || ''
    const providedSecret = authHeader.replace(/^Bearer\s+/, '') || req.headers.get('x-shared-secret') || ''
    if (providedSecret !== logSource.sharedSecret) {
      return NextResponse.json({ error: 'Invalid shared secret' }, { status: 401 })
    }
  }

  let body: { events?: unknown[] } & Record<string, unknown>
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  // Normalize to array of events
  const events = Array.isArray(body.events)
    ? body.events
    : [body]

  if (events.length === 0) {
    return NextResponse.json({ error: 'No events provided' }, { status: 400 })
  }

  // Persist up to 100 events at a time
  const toCreate = events.slice(0, 100).map((evt) => {
    const e = evt as Record<string, unknown>
    return {
      source: String(e.source || logSource.name),
      severity: String(e.severity || 'info'),
      message: String(e.message || 'No message'),
      srcIp: e.srcIp ? String(e.srcIp) : null,
      dstIp: e.dstIp ? String(e.dstIp) : null,
      dstPort: e.dstPort ? Number(e.dstPort) : null,
      protocol: e.protocol ? String(e.protocol) : null,
      raw: e.raw ? JSON.stringify(e.raw) : JSON.stringify(e),
    }
  })

  const created = await db.log.createMany({ data: toCreate })

  // Fetch the created logs (need IDs for detection rules)
  const createdLogs = await db.log.findMany({
    where: {
      source: toCreate[0].source,
      message: { in: toCreate.map((e) => e.message) },
    },
    orderBy: { createdAt: 'desc' },
    take: toCreate.length,
  })

  // Update source stats
  await db.logSource.update({
    where: { id: logSource.id },
    data: {
      eventsIngested: { increment: toCreate.length },
      lastEvent: new Date(),
    },
  })

  // Run real detection rules → create real alerts
  const detectionResult = await runDetectionRules(createdLogs.map((l) => l.id))

  // Check blocked domains/IPs and increment hit counts
  let blockedHits = 0
  for (const evt of toCreate) {
    if (evt.srcIp) {
      const blocked = await isSourceBlocked(evt.srcIp)
      if (blocked) {
        blockedHits++
        await db.domain.updateMany({
          where: { hostname: evt.srcIp },
          data: { hits: { increment: 1 } },
        })
      }
    }
  }

  return NextResponse.json({
    success: true,
    ingested: toCreate.length,
    source: sourceName,
    alertsCreated: detectionResult.created,
    blockedHits,
    alerts: detectionResult.alerts,
  })
}

/**
 * GET /api/ingest?source=X&since=timestamp
 * Returns recently ingested logs from a given source.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const source = searchParams.get('source')
  const since = Number(searchParams.get('since') || '0')
  const limit = Number(searchParams.get('limit') || '100')

  const where: Record<string, unknown> = {}
  if (source) where.source = source
  if (since > 0) where.timestamp = { gt: new Date(since) }

  const logs = await db.log.findMany({
    where,
    orderBy: { timestamp: 'desc' },
    take: Math.min(limit, 500),
    include: { agent: true },
  })

  return NextResponse.json({ logs, total: logs.length })
}
