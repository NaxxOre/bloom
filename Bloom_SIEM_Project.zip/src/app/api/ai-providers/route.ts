import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const providers = await db.aIProvider.findMany({ orderBy: [{ isDefault: 'desc' }, { createdAt: 'asc' }] })
  // Mask API keys in GET response
  const masked = providers.map((p) => ({
    ...p,
    apiKey: p.apiKey ? `${p.apiKey.slice(0, 4)}${'*'.repeat(20)}${p.apiKey.slice(-4)}` : '',
  }))
  return NextResponse.json({ providers: masked })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { provider, label, apiKey, baseUrl, model, isDefault } = body

  // If setting as default, unset others
  if (isDefault) {
    await db.aIProvider.updateMany({ data: { isDefault: false } })
  }

  const created = await db.aIProvider.create({
    data: {
      provider,
      label,
      apiKey: apiKey || '',
      baseUrl: baseUrl || null,
      model,
      isDefault: isDefault || false,
      enabled: true,
    },
  })

  return NextResponse.json({
    provider: { ...created, apiKey: created.apiKey ? `${created.apiKey.slice(0, 4)}${'*'.repeat(20)}${created.apiKey.slice(-4)}` : '' },
  })
}

export async function PATCH(req: NextRequest) {
  const body = await req.json()
  const { id, apiKey, enabled, isDefault, model, label } = body

  if (isDefault) {
    await db.aIProvider.updateMany({ data: { isDefault: false } })
  }

  const updated = await db.aIProvider.update({
    where: { id },
    data: {
      ...(apiKey !== undefined && { apiKey }),
      ...(enabled !== undefined && { enabled }),
      ...(isDefault !== undefined && { isDefault }),
      ...(model !== undefined && { model }),
      ...(label !== undefined && { label }),
    },
  })

  return NextResponse.json({
    provider: { ...updated, apiKey: updated.apiKey ? `${updated.apiKey.slice(0, 4)}${'*'.repeat(20)}${updated.apiKey.slice(-4)}` : '' },
  })
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })

  await db.aIProvider.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
