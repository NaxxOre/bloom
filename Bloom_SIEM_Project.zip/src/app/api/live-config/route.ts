import { NextRequest, NextResponse } from 'next/server'
import { getConfig, updateConfig } from '@/lib/live-events'

export async function GET() {
  return NextResponse.json({ config: getConfig() })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const config = updateConfig(body)
  return NextResponse.json({ config })
}
