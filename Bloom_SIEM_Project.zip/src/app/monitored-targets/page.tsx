import { SiemShell } from '@/components/siem/shell'

export default function Page() {
  return <SiemShell view="monitored_targets" />
}
