import { SiemShell } from '@/components/siem/shell'

export default function Home() {
  return <SiemShell />
}
