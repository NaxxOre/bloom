'use client'

export function SkeletonLoader() {
  return (
    <div className="p-5 space-y-4 animate-pulse">
      {/* Title skeleton */}
      <div className="h-7 w-64 bg-[#2a2d31] rounded-md" />

      {/* Stats row skeleton */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
            <div className="h-4 w-20 bg-[#2a2d31] rounded mb-2" />
            <div className="h-8 w-16 bg-[#2a2d31] rounded" />
          </div>
        ))}
      </div>

      {/* Chart skeleton */}
      <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
        <div className="h-5 w-48 bg-[#2a2d31] rounded mb-4" />
        <div className="h-[200px] bg-[#1a1d21] rounded" />
      </div>

      {/* Table skeleton */}
      <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
        <div className="h-5 w-32 bg-[#2a2d31] rounded mb-3" />
        <div className="space-y-2">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="flex gap-3">
              <div className="h-4 w-12 bg-[#2a2d31] rounded" />
              <div className="h-4 flex-1 bg-[#2a2d31] rounded" />
              <div className="h-4 w-20 bg-[#2a2d31] rounded" />
              <div className="h-4 w-16 bg-[#2a2d31] rounded" />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
