'use client'

import { useRouter, usePathname } from 'next/navigation'
import { Sidebar } from '@/components/siem/sidebar'
import { Header } from '@/components/siem/header'
import { LiveActivityFeed } from '@/components/siem/live-feed'
import { DashboardView } from '@/components/siem/views/dashboard'
import { AlertsView } from '@/components/siem/views/alerts'
import { IntelligenceView } from '@/components/siem/views/intelligence'
import { AutomationView } from '@/components/siem/views/automation'
import { MonitoredTargetsView } from '@/components/siem/views/monitored-targets'
import { ProjectsView } from '@/components/siem/views/projects'
import { TrafficView } from '@/components/siem/views/traffic'
import { LiveLogsView } from '@/components/siem/views/live-logs'
import { ResponseView } from '@/components/siem/views/response'
import { ControlsView } from '@/components/siem/views/controls'
import { ConnectorsView } from '@/components/siem/views/connectors'
import { ReportsView } from '@/components/siem/views/reports'
import { AdminView } from '@/components/siem/views/admin'
import { AIConfigView } from '@/components/siem/views/ai-config'
import { AttackSurfaceView } from '@/components/siem/views/attack-surface'
import { ExposureView } from '@/components/siem/views/exposure'
import { TelegramView } from '@/components/siem/views/telegram'
import { SkeletonLoader } from '@/components/siem/skeleton'
import { Suspense } from 'react'

// Map URL path to view name
const PATH_TO_VIEW: Record<string, string> = {
  '/': 'home',
  '/monitored-targets': 'monitored_targets',
  '/attack-surface': 'attack_surface',
  '/exposure': 'exposure',
  '/projects': 'projects',
  '/traffic': 'traffic',
  '/live-logs': 'live_logs',
  '/reports': 'reports',
  '/response': 'response',
  '/alerts': 'alerts',
  '/intelligence': 'intelligence',
  '/controls': 'controls',
  '/connectors': 'connectors',
  '/automation': 'automation',
  '/ai-providers': 'ai_config',
  '/telegram': 'telegram',
  '/admin': 'admin',
}

export function SiemShell({ view: viewProp }: { view?: string }) {
  const pathname = usePathname()
  const router = useRouter()

  // Use the prop if provided, otherwise derive from the URL
  const activeView = viewProp || PATH_TO_VIEW[pathname] || 'home'

  const showLiveFeed = ['home', 'alerts', 'automation', 'response', 'traffic'].includes(activeView)

  const renderView = () => {
    switch (activeView) {
      case 'home': return <DashboardView />
      case 'monitored_targets': return <MonitoredTargetsView />
      case 'attack_surface': return <AttackSurfaceView />
      case 'exposure': return <ExposureView />
      case 'projects': return <ProjectsView />
      case 'traffic': return <TrafficView />
      case 'live_logs': return <LiveLogsView />
      case 'reports': return <ReportsView />
      case 'response': return <ResponseView />
      case 'alerts': return <AlertsView />
      case 'intelligence': return <IntelligenceView />
      case 'controls': return <ControlsView />
      case 'connectors': return <ConnectorsView />
      case 'automation': return <AutomationView />
      case 'ai_config': return <AIConfigView />
      case 'telegram': return <TelegramView />
      case 'admin': return <AdminView />
      default: return <DashboardView />
    }
  }

  return (
    <div className="flex h-screen w-full bg-[#1a1d21] text-[#e8e9ea] overflow-hidden">
      <Sidebar activeView={activeView} onNavigate={(path) => router.push(path)} />
      <div className="flex-1 flex flex-col min-w-0">
        <Header activeView={activeView} onNavigate={(path) => router.push(path)} />
        <main className="flex-1 overflow-y-auto relative">
          {showLiveFeed ? (
            <div className="grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-0">
              <div className="min-w-0">
                <Suspense fallback={<SkeletonLoader />}>
                  {renderView()}
                </Suspense>
              </div>
              <div className="border-l border-[#2e3236] p-3 hidden xl:block">
                <div className="sticky top-3 max-h-[calc(100vh-100px)]">
                  <LiveActivityFeed />
                </div>
              </div>
            </div>
          ) : (
            <Suspense fallback={<SkeletonLoader />}>
              {renderView()}
            </Suspense>
          )}
        </main>
      </div>
    </div>
  )
}
