'use client'

import { useEffect, useState } from 'react'
import {
  TrendingUp, TrendingDown, ChevronRight, Info,
  Network, ShieldAlert, ShieldX, Siren, Activity,
} from 'lucide-react'
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis,
  Tooltip, RadialBarChart, RadialBar, PolarAngleAxis,
  PieChart, Pie, Cell, Legend,
} from 'recharts'
import { useSiemStore } from '@/lib/siem-store'

interface DashboardData {
  metrics: {
    totalAgents: number
    agentsOnline: number
    agentsOffline: number
    agentsDegraded: number
    totalAlerts: number
    totalInvestigations: number
    totalActions: number
    maliciousInvestigations: number
    totalLogs: number
    totalMonitoredTargets: number
    totalDomains: number
    totalLogSources: number
  }
  pipeline: {
    logs: number
    alerts: number
    escalated: number
    investigations: number
    malicious: number
  }
  coverage: { pct: number; series: { date: string; coverage: number }[] }
  trend: {
    alertsTriagedPct: number
    alertsClosedPct: number
    alertsEscalatedPct: number
    maliciousPct: number
  }
  mitre: { name: string; value: number }[]
  origins: { name: string; value: number }[]
  recentActions: {
    id: string
    action: string
    target: string
    status: string
    createdAt: string
    initiatedBy: string
  }[]
  recentAlerts: {
    id: string
    title: string
    severity: string
    status: string
    srcIp: string | null
    createdAt: string
  }[]
}

const fmt = (n: number) => {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`
  return n.toString()
}

const PIPELINE_COLORS = ['#4a90e2', '#5a9de6', '#6aa8ea', '#7ab3ee', '#e74c3c']

export function DashboardView() {
  const [data, setData] = useState<DashboardData | null>(null)
  const { setActiveView } = useSiemStore()

  useEffect(() => {
    fetch('/api/dashboard?days=21')
      .then((r) => r.json())
      .then(setData)
      .catch(console.error)
  }, [])

  if (!data) {
    return <div className="p-6 text-[#8e9296] text-sm">Loading dashboard...</div>
  }

  const pipeline = [
    { label: 'Logs', value: data.pipeline.logs, color: PIPELINE_COLORS[0] },
    { label: 'Alerts', value: data.pipeline.alerts, color: PIPELINE_COLORS[1] },
    { label: 'Escalated', value: data.pipeline.escalated, color: PIPELINE_COLORS[2] },
    { label: 'Investigations', value: data.pipeline.investigations, color: PIPELINE_COLORS[3] },
    { label: 'Malicious', value: data.pipeline.malicious, color: PIPELINE_COLORS[4] },
  ]

  const trendCards = [
    { label: 'Alerts Triaged', value: data.trend.alertsTriagedPct },
    { label: 'Alerts Closed', value: data.trend.alertsClosedPct },
    { label: 'Alerts Escalated', value: data.trend.alertsEscalatedPct },
    { label: 'Malicious', value: data.trend.maliciousPct },
  ]

  const originColors = ['#e74c3c', '#f39c12', '#4a90e2', '#2ecc71']
  const mitreColors = ['#4a90e2', '#5a9de6', '#6aa8ea', '#7ab3ee', '#8ac0f2', '#9acdf6', '#aadaf9', '#bae7fd']

  const isEmpty = data.metrics.totalAlerts === 0 && data.metrics.totalLogs === 0

  return (
    <div className="p-5 space-y-5 max-w-[1600px] mx-auto">
      {/* Empty state banner */}
      {isEmpty && (
        <div className="bg-[#f39c12]/10 border border-[#f39c12]/30 rounded-md p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-[#f39c12] mt-0.5 shrink-0" />
          <div className="flex-1">
            <div className="text-[13px] font-semibold text-white mb-1">No real data yet — Bloom SIEM is ready for ingest</div>
            <p className="text-[12px] text-[#8e9296] mb-2">
              This dashboard shows real data only (no mock/seeded alerts). Send real logs via the ingestion API
              or add monitored targets to start seeing analysis results here.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setActiveView('monitored_targets')}
                className="text-[11px] bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium px-3 py-1.5 rounded"
              >
                Add Monitored Target
              </button>
              <button
                onClick={() => setActiveView('connectors')}
                className="text-[11px] bg-[#2a2d31] hover:bg-[#3a3e42] text-white px-3 py-1.5 rounded"
              >
                View Ingestion Endpoints
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top row: Coverage + Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Monitored Targets Coverage */}
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-[15px] font-semibold text-white">Monitored Targets Coverage</h3>
                <Info className="w-3.5 h-3.5 text-[#6b7075]" />
              </div>
              <p className="text-[11px] text-[#8e9296] mt-0.5">Real uptime status of domains/localhosts you monitor</p>
            </div>
          </div>
          <div className="flex items-end gap-3 mb-3">
            <span className="text-[36px] font-bold text-white leading-none">{data.coverage.pct}%</span>
            <span className="text-[12px] text-[#8e9296] mb-1">{data.metrics.totalMonitoredTargets} targets</span>
          </div>
          <div className="h-[140px] -ml-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.coverage.series}>
                <defs>
                  <linearGradient id="coverageGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#4a90e2" stopOpacity={0.6} />
                    <stop offset="100%" stopColor="#4a90e2" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" stroke="#6b7075" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis hide domain={[0, 100]} />
                <Tooltip contentStyle={{ background: '#1a1d21', border: '1px solid #2e3236', borderRadius: 6, fontSize: 12 }} labelStyle={{ color: '#8e9296' }} />
                <Area type="monotone" dataKey="coverage" stroke="#4a90e2" strokeWidth={2} fill="url(#coverageGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-[#2e3236]">
            <button
              onClick={() => setActiveView('monitored_targets')}
              className="text-[11px] text-[#f39c12] hover:underline flex items-center gap-1"
            >
              Go to Monitored Targets
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Threat Pipeline (real counts) */}
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-[15px] font-semibold text-white">Threat Pipeline</h3>
                <Info className="w-3.5 h-3.5 text-[#6b7075]" />
              </div>
              <p className="text-[11px] text-[#8e9296] mt-0.5">Real counts — from actually-ingested logs and generated alerts</p>
            </div>
          </div>
          <div className="space-y-1.5">
            {pipeline.map((stage, i) => {
              const maxVal = pipeline[0].value || 1
              const pct = (stage.value / maxVal) * 100
              return (
                <div key={stage.label}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[12px] text-[#e8e9ea] flex items-center gap-1.5">
                      <span className="text-[10px] text-[#6b7075]">{i + 1}.</span>
                      {stage.label}
                    </span>
                    <span className="text-[12px] font-semibold text-white">{fmt(stage.value)}</span>
                  </div>
                  <div className="h-6 bg-[#1a1d21] rounded-sm overflow-hidden">
                    <div
                      className="funnel-segment h-full rounded-sm flex items-center justify-end pr-2"
                      style={{
                        width: `${Math.max(pct, stage.value > 0 ? 5 : 0)}%`,
                        background: `linear-gradient(135deg, ${stage.color}, ${stage.color}cc)`,
                      }}
                    />
                  </div>
                </div>
              )
            })}
            {pipeline.every((s) => s.value === 0) && (
              <div className="text-[11px] text-[#6b7075] text-center py-4">
                No logs ingested yet. Send logs via <code className="text-[#f4b733]">POST /api/ingest</code> to populate.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Trend metric cards (real percentages) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {trendCards.map((c) => (
          <div key={c.label} className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] text-[#8e9296] uppercase tracking-wide">{c.label}</span>
              <Info className="w-3 h-3 text-[#6b7075]" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-[28px] font-bold text-white">{c.value}%</span>
            </div>
          </div>
        ))}
      </div>

      {/* Quick stats — real inventory */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { label: 'Monitored Targets', value: data.metrics.totalMonitoredTargets, icon: Network, color: 'text-[#4a90e2]' },
          { label: 'Blocked Domains/IPs', value: data.metrics.totalDomains, icon: ShieldX, color: 'text-[#e74c3c]' },
          { label: 'Log Sources', value: data.metrics.totalLogSources, icon: Activity, color: 'text-[#2ecc71]' },
          { label: 'Total Logs', value: data.metrics.totalLogs, icon: Siren, color: 'text-[#f39c12]' },
          { label: 'Active Alerts', value: data.metrics.totalAlerts, icon: ShieldAlert, color: 'text-[#e74c3c]' },
        ].map((s) => {
          const Icon = s.icon
          return (
            <div key={s.label} className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
              <Icon className={`w-4 h-4 ${s.color} mb-2`} />
              <div className="text-[20px] font-bold text-white">{s.value}</div>
              <div className="text-[10px] text-[#8e9296] uppercase">{s.label}</div>
            </div>
          )
        })}
      </div>

      {/* MITRE + Origins (only if there are alerts) */}
      {data.metrics.totalAlerts > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {data.mitre.length > 0 && (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Network className="w-4 h-4 text-[#f39c12]" />
                  <h3 className="text-[14px] font-semibold text-white">Alerts by MITRE Tactic</h3>
                </div>
                <Info className="w-3.5 h-3.5 text-[#6b7075]" />
              </div>
              <div className="h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RadialBarChart
                    data={data.mitre.map((m, i) => ({ name: m.name, value: m.value, fill: mitreColors[i % mitreColors.length] }))}
                    innerRadius="20%"
                    outerRadius="100%"
                  >
                    <PolarAngleAxis dataKey="value" type="number" domain={[0, 'dataMax']} tick={false} />
                    <RadialBar dataKey="value" background={{ fill: '#1a1d21' }} cornerRadius={4} />
                    <Legend
                      iconSize={8}
                      iconType="circle"
                      layout="vertical"
                      align="right"
                      verticalAlign="middle"
                      formatter={(_v, _e, idx) => {
                        const m = data.mitre[idx]
                        return <span className="text-[11px] text-[#b0b3b8]">{m?.name} ({m?.value})</span>
                      }}
                    />
                    <Tooltip contentStyle={{ background: '#1a1d21', border: '1px solid #2e3236', borderRadius: 6, fontSize: 12 }} labelStyle={{ color: '#8e9296' }} />
                  </RadialBarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {data.origins.length > 0 && (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Siren className="w-4 h-4 text-[#f39c12]" />
                  <h3 className="text-[14px] font-semibold text-white">Origin of Alerts</h3>
                </div>
                <Info className="w-3.5 h-3.5 text-[#6b7075]" />
              </div>
              <div className="h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={data.origins} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={2}>
                      {data.origins.map((_, i) => (
                        <Cell key={i} fill={originColors[i % originColors.length]} />
                      ))}
                    </Pie>
                    <Legend
                      iconSize={8}
                      iconType="circle"
                      layout="vertical"
                      align="right"
                      verticalAlign="middle"
                      formatter={(_v, _e, idx) => {
                        const o = data.origins[idx]
                        return <span className="text-[11px] text-[#b0b3b8] capitalize">{o?.name} ({o?.value})</span>
                      }}
                    />
                    <Tooltip contentStyle={{ background: '#1a1d21', border: '1px solid #2e3236', borderRadius: 6, fontSize: 12 }} labelStyle={{ color: '#8e9296' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Recent actions + alerts (only if any) */}
      {(data.recentActions.length > 0 || data.recentAlerts.length > 0) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {data.recentActions.length > 0 && (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <ShieldX className="w-4 h-4 text-[#f39c12]" />
                  <h3 className="text-[14px] font-semibold text-white">Recent AI Auto-Actions</h3>
                </div>
                <span className="text-[11px] text-[#2ecc71]">{data.metrics.totalActions} total</span>
              </div>
              <div className="space-y-1.5 max-h-[260px] overflow-y-auto">
                {data.recentActions.map((a) => (
                  <div key={a.id} className="flex items-center gap-3 py-1.5 px-2 hover:bg-[#2a2d31] rounded text-[12px]">
                    <span className={`w-1.5 h-1.5 rounded-full ${a.status === 'success' ? 'bg-[#2ecc71]' : 'bg-[#e74c3c]'}`} />
                    <span className="text-[#f39c12] font-medium uppercase tracking-wide text-[11px] w-32 truncate">{a.action.replace('_', ' ')}</span>
                    <span className="text-[#e8e9ea] flex-1 truncate font-mono">{a.target}</span>
                    <span className="text-[10px] text-[#6b7075]">
                      {new Date(a.createdAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {data.recentAlerts.length > 0 && (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-[#f39c12]" />
                  <h3 className="text-[14px] font-semibold text-white">Recent Alerts</h3>
                </div>
                <span className="text-[11px] text-[#2ecc71]">{data.metrics.totalAlerts} active</span>
              </div>
              <div className="space-y-1.5 max-h-[260px] overflow-y-auto">
                {data.recentAlerts.map((a) => (
                  <div key={a.id} className="flex items-center gap-3 py-1.5 px-2 hover:bg-[#2a2d31] rounded text-[12px]">
                    <span className={`w-1.5 h-1.5 rounded-full ${
                      a.severity === 'critical' ? 'bg-[#e74c3c]' :
                      a.severity === 'high' ? 'bg-[#f39c12]' :
                      a.severity === 'medium' ? 'bg-[#f4b733]' : 'bg-[#8e9296]'
                    }`} />
                    <span className="text-[#e8e9ea] flex-1 truncate">{a.title}</span>
                    <span className="text-[10px] text-[#6b7075] font-mono">{a.srcIp}</span>
                    <span className="text-[10px] text-[#6b7075]">
                      {new Date(a.createdAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
