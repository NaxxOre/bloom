'use client'

import { useEffect, useState } from 'react'
import { Activity, Loader2, Filter, Search } from 'lucide-react'

interface LiveLog {
  id: string; method: string; path: string; host: string; ip: string
  userAgent: string | null; ja4: string | null; action: string; rule: string | null
  inputSnippet: string | null; fileHash: string | null; fileName: string | null
  fileVerdict: string | null; sessionId: string | null; statusCode: number | null
  responseTime: number | null; timestamp: string
}

interface Project { id: string; name: string; domain: string }

const ACTION_COLORS: Record<string, string> = {
  allowed: 'text-[#2ecc71] bg-[#2ecc71]/10',
  denied: 'text-[#e74c3c] bg-[#e74c3c]/10',
  challenged: 'text-[#f4b733] bg-[#f4b733]/10',
  logged: 'text-[#8e9296] bg-[#8e9296]/10',
  rate_limited: 'text-[#f39c12] bg-[#f39c12]/10',
}

export function LiveLogsView() {
  const [projects, setProjects] = useState<Project[]>([])
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [logs, setLogs] = useState<LiveLog[]>([])
  const [filter, setFilter] = useState('')
  const [actionFilter, setActionFilter] = useState('all')
  const [loading, setLoading] = useState(true)

  const loadLogs = () => {
    if (!selectedProject) return
    const params = new URLSearchParams({ projectId: selectedProject, limit: '100' })
    if (actionFilter !== 'all') params.set('action', actionFilter)
    fetch(`/api/project-logs?${params}`).then((r) => r.json()).then((d) => setLogs(d.logs || [])).finally(() => setLoading(false))
  }

  useEffect(() => {
    fetch('/api/projects').then((r) => r.json()).then((d) => {
      setProjects(d.projects || [])
      if (d.projects?.length > 0) setSelectedProject(d.projects[0].id)
    })
  }, [])

  useEffect(() => {
    if (!selectedProject) return
    const interval = setInterval(() => loadLogs(), 3000)
    loadLogs()
    return () => clearInterval(interval)
  }, [selectedProject, actionFilter])

  const filtered = filter
    ? logs.filter((l) => l.path.toLowerCase().includes(filter.toLowerCase()) || l.ip.includes(filter) || (l.userAgent || '').toLowerCase().includes(filter.toLowerCase()))
    : logs

  return (
    <div className="p-5 space-y-4 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#f39c12]" />
            Live Logs
          </h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">Real-time request stream from your connected site. Auto-refreshes every 3s.</p>
        </div>
        <div className="flex items-center gap-2">
          {projects.length > 0 && (
            <select value={selectedProject || ''} onChange={(e) => setSelectedProject(e.target.value)} className="bg-[#2a2d31] border border-[#2e3236] text-[12px] text-white rounded px-3 py-1.5">
              {projects.map((p) => <option key={p.id} value={p.id}>{p.domain}</option>)}
            </select>
          )}
          <select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)} className="bg-[#2a2d31] border border-[#2e3236] text-[12px] text-white rounded px-3 py-1.5">
            <option value="all">All Actions</option><option value="allowed">Allowed</option>
            <option value="denied">Denied</option><option value="challenged">Challenged</option>
            <option value="rate_limited">Rate Limited</option>
          </select>
          <div className="flex items-center gap-1.5 bg-[#2a2d31] border border-[#2e3236] rounded px-2.5 py-1.5">
            <Search className="w-3 h-3 text-[#8e9296]" />
            <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filter path/IP/UA..." className="bg-transparent text-[11px] text-white outline-none w-40" />
          </div>
        </div>
      </div>

      {!selectedProject ? (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-12 text-center text-[#8e9296] text-[13px]">Connect a project first to see live logs.</div>
      ) : loading ? (
        <div className="text-center py-12 text-[#8e9296]"><Loader2 className="w-6 h-6 mx-auto mb-2 animate-spin" />Loading logs…</div>
      ) : filtered.length === 0 ? (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-12 text-center">
          <Activity className="w-10 h-10 mx-auto mb-3 text-[#6b7075]" />
          <div className="text-[14px] text-white font-medium mb-1">No logs yet</div>
          <p className="text-[12px] text-[#8e9296]">Make sure your middleware is deployed and sending events to Bloom. Click "Test" on the Projects page to verify.</p>
        </div>
      ) : (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md overflow-hidden">
          <div className="grid grid-cols-[60px_50px_2fr_1.5fr_1fr_80px_80px_1fr] gap-2 px-3 py-2 text-[9px] uppercase text-[#6b7075] border-b border-[#2e3236] font-medium">
            <span>Action</span><span>Method</span><span>Path</span><span>IP</span><span>User Agent</span><span>Status</span><span>Time</span><span>Details</span>
          </div>
          <div className="max-h-[calc(100vh-280px)] overflow-y-auto">
            {filtered.map((l) => (
              <div key={l.id} className="grid grid-cols-[60px_50px_2fr_1.5fr_1fr_80px_80px_1fr] gap-2 px-3 py-1.5 text-[11px] border-b border-[#2a2d31] hover:bg-[#2a2d31] items-center">
                <span className={`text-[9px] px-1.5 py-0.5 rounded uppercase font-medium text-center ${ACTION_COLORS[l.action] || ACTION_COLORS.logged}`}>{l.action}</span>
                <span className="text-[#4a90e2] font-mono">{l.method}</span>
                <span className="text-white font-mono truncate">{l.path}</span>
                <span className="text-[#b0b3b8] font-mono truncate">{l.ip}</span>
                <span className="text-[#8e9296] truncate text-[10px]">{l.userAgent || '—'}</span>
                <span className={`font-mono ${l.statusCode && l.statusCode >= 400 ? 'text-[#e74c3c]' : 'text-[#2ecc71]'}`}>{l.statusCode || '—'}</span>
                <span className="text-[#6b7075] text-[10px]">{new Date(l.timestamp).toLocaleTimeString()}</span>
                <div className="text-[10px]">
                  {l.rule && <span className="text-[#f39c12]">{l.rule}</span>}
                  {l.inputSnippet && <span className="text-[#8e9296] truncate block" title={l.inputSnippet}>📋 {l.inputSnippet.slice(0, 40)}</span>}
                  {l.fileName && <span className={`block ${l.fileVerdict === 'malicious' ? 'text-[#e74c3c]' : 'text-[#8e9296]'}`}>📎 {l.fileName} ({l.fileVerdict})</span>}
                  {l.sessionId && <span className="text-[#9b59b6]">🔑 {l.sessionId.slice(0, 12)}…</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
