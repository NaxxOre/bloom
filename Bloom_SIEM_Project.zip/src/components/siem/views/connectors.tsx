'use client'

import { useEffect, useState } from 'react'
import { Plug, Ban, Plus, Globe, ShieldCheck, Eye, Trash2, Activity, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'

interface LogSource {
  id: string; name: string; sourceType: string; endpoint: string | null
  sharedSecret: string | null; enabled: boolean; eventsIngested: number; lastEvent: string | null
}

interface Domain {
  id: string; hostname: string; type: string; status: string; source: string
  reason: string | null; hits: number; blockedAt: string | null; updatedAt: string
}

interface Project {
  id: string; name: string; domain: string; status: string
  firewallEnabled: boolean; botProtectionEnabled: boolean
}

const STATUS_COLORS: Record<string, string> = {
  active: 'bg-[#2ecc71] bloom-pulse', paused: 'bg-[#8e9296]', error: 'bg-[#e74c3c]',
}
const DOMAIN_STATUS_COLORS: Record<string, string> = {
  blocked: 'text-[#e74c3c] bg-[#e74c3c]/10',
  allowed: 'text-[#2ecc71] bg-[#2ecc71]/10',
  monitored: 'text-[#f4b733] bg-[#f4b733]/10',
}

export function ConnectorsView() {
  const [logSources, setLogSources] = useState<LogSource[]>([])
  const [domains, setDomains] = useState<Domain[]>([])
  const [projects, setProjects] = useState<Project[]>([])
  const [tab, setTab] = useState<'log_sources' | 'blocklist' | 'projects'>('blocklist')
  const [newDomain, setNewDomain] = useState({ hostname: '', type: 'ip', status: 'blocked', reason: '' })

  const loadDomains = () => {
    fetch('/api/domains')
      .then((r) => r.text())
      .then((text) => { try { return JSON.parse(text) } catch { return { domains: [] } } })
      .then((d) => setDomains(d.domains || []))
      .catch(() => {})
  }

  useEffect(() => {
    fetch('/api/log-sources')
      .then((r) => r.text())
      .then((text) => { try { return JSON.parse(text) } catch { return { sources: [] } } })
      .then((d) => setLogSources(d.sources || []))
      .catch(() => {})
    loadDomains()
    fetch('/api/projects')
      .then((r) => r.text())
      .then((text) => { try { return JSON.parse(text) } catch { return { projects: [] } } })
      .then((d) => setProjects(d.projects || []))
      .catch(() => {})
  }, [])

  const addDomain = async () => {
    if (!newDomain.hostname) { toast.error('Hostname/IP required'); return }
    const res = await fetch('/api/domains', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...newDomain, source: 'manual' }),
    })
    if (res.ok) {
      toast.success(`Added ${newDomain.hostname} as ${newDomain.status}`)
      setNewDomain({ hostname: '', type: 'ip', status: 'blocked', reason: '' })
      loadDomains()
    }
  }

  const updateDomainStatus = async (id: string, status: string) => {
    const domain = domains.find((d) => d.id === id)
    if (!domain) return
    await fetch('/api/domains', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hostname: domain.hostname, status, source: 'manual' }),
    })
    loadDomains()
    toast.success(`Status changed to ${status}`)
  }

  const deleteDomain = async (id: string) => {
    await fetch(`/api/domains?id=${id}`, { method: 'DELETE' })
    loadDomains()
    toast.success('Removed from list')
  }

  const blockedCount = domains.filter((d) => d.status === 'blocked').length
  const blockedHits = domains.reduce((sum, d) => sum + d.hits, 0)

  return (
    <div className="p-5 space-y-4 max-w-[1400px] mx-auto">
      <div>
        <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
          <Plug className="w-5 h-5 text-[#f39c12]" />
          Data Sources & Blocklist
        </h1>
        <p className="text-[12px] text-[#8e9296] mt-0.5">
          Real ingestion endpoints, connected projects, and IP/domain blocklist
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
          <Activity className="w-4 h-4 text-[#4a90e2] mb-2" />
          <div className="text-[18px] font-bold text-white">{logSources.length}</div>
          <div className="text-[11px] text-[#8e9296] uppercase">Log Sources</div>
        </div>
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
          <Plug className="w-4 h-4 text-[#f39c12] mb-2" />
          <div className="text-[18px] font-bold text-white">{projects.length}</div>
          <div className="text-[11px] text-[#8e9296] uppercase">Connected Projects</div>
        </div>
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
          <Ban className="w-4 h-4 text-[#e74c3c] mb-2" />
          <div className="text-[18px] font-bold text-white">{blockedCount}</div>
          <div className="text-[11px] text-[#8e9296] uppercase">Blocked IPs/Domains</div>
        </div>
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
          <Eye className="w-4 h-4 text-[#f4b733] mb-2" />
          <div className="text-[18px] font-bold text-white">{blockedHits.toLocaleString()}</div>
          <div className="text-[11px] text-[#8e9296] uppercase">Blocked Hits</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-[#2e3236]">
        {[
          { id: 'blocklist', label: `Blocklist (${domains.length})` },
          { id: 'projects', label: `Connected Projects (${projects.length})` },
          { id: 'log_sources', label: `Log Sources (${logSources.length})` },
        ].map((t) => (
          <button key={t.id} onClick={() => setTab(t.id as typeof tab)}
            className={`text-[12px] px-3 py-2 -mb-px border-b-2 transition-colors ${tab === t.id ? 'border-[#f39c12] text-white' : 'border-transparent text-[#8e9296] hover:text-white'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Blocklist tab */}
      {tab === 'blocklist' && (
        <div className="space-y-3">
          {/* Add new domain */}
          <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
            <div className="text-[13px] font-semibold text-white mb-3 flex items-center gap-2">
              <Plus className="w-4 h-4 text-[#f39c12]" />
              Add IP / Domain to Blocklist
            </div>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
              <input value={newDomain.hostname} onChange={(e) => setNewDomain({ ...newDomain, hostname: e.target.value })}
                placeholder="hostname or IP" className="md:col-span-2 bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white font-mono outline-none focus:border-[#f39c12]" />
              <select value={newDomain.type} onChange={(e) => setNewDomain({ ...newDomain, type: e.target.value })}
                className="bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white">
                <option value="domain">Domain</option><option value="ip">IP Address</option><option value="url">URL</option>
              </select>
              <select value={newDomain.status} onChange={(e) => setNewDomain({ ...newDomain, status: e.target.value })}
                className="bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white">
                <option value="blocked">Blocked</option><option value="monitored">Monitored</option><option value="allowed">Allowed</option>
              </select>
              <button onClick={addDomain} className="bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[12px] py-2 rounded">Add</button>
            </div>
            <input value={newDomain.reason} onChange={(e) => setNewDomain({ ...newDomain, reason: e.target.value })}
              placeholder="Reason (optional, e.g. 'C2 beacon detected')"
              className="mt-2 w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white outline-none focus:border-[#f39c12]" />
          </div>

          {/* Blocklist table */}
          <div className="bg-[#232629] border border-[#2e3236] rounded-md overflow-hidden">
            <div className="grid grid-cols-[3fr_1fr_1fr_1fr_1fr_auto] gap-3 px-4 py-2 text-[10px] uppercase text-[#6b7075] border-b border-[#2e3236] font-medium">
              <span>Hostname / IP</span><span>Type</span><span>Status</span><span>Source</span><span>Hits</span><span>Actions</span>
            </div>
            <div className="max-h-[500px] overflow-y-auto">
              {domains.length === 0 ? (
                <div className="text-[12px] text-[#6b7075] py-8 text-center">No blocked IPs or domains yet. Add one above or create an automation rule.</div>
              ) : (
                domains.map((d) => {
                  const isGeoBlock = d.hostname.startsWith('country:')
                  return (
                    <div key={d.id} className="grid grid-cols-[3fr_1fr_1fr_1fr_1fr_auto] gap-3 px-4 py-2.5 text-[12px] border-b border-[#2a2d31] hover:bg-[#2a2d31] items-center">
                      <div className="min-w-0">
                        <div className="text-white font-mono truncate flex items-center gap-2">
                          {d.type === 'ip' ? <Globe className="w-3 h-3 text-[#8e9296]" /> : null}
                          {isGeoBlock ? <span className="text-[#9b59b6]">🌍 {d.hostname}</span> : d.hostname}
                        </div>
                        {d.reason && <div className="text-[10px] text-[#6b7075] truncate">{d.reason}</div>}
                      </div>
                      <span className="text-[#b0b3b8] capitalize">{d.type}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-medium w-fit ${DOMAIN_STATUS_COLORS[d.status] || DOMAIN_STATUS_COLORS.monitored}`}>
                        {d.status}
                      </span>
                      <span className="text-[#8e9296] capitalize text-[11px]">{d.source.replace('_', ' ')}</span>
                      <span className="text-[#f39c12] font-mono">{d.hits.toLocaleString()}</span>
                      <div className="flex items-center gap-1">
                        {d.status !== 'blocked' && (
                          <button onClick={() => updateDomainStatus(d.id, 'blocked')} className="text-[10px] px-1.5 py-0.5 rounded bg-[#e74c3c]/20 text-[#e74c3c] hover:bg-[#e74c3c]/30">Block</button>
                        )}
                        {d.status !== 'allowed' && (
                          <button onClick={() => updateDomainStatus(d.id, 'allowed')} className="text-[10px] px-1.5 py-0.5 rounded bg-[#2ecc71]/20 text-[#2ecc71] hover:bg-[#2ecc71]/30">Allow</button>
                        )}
                        <button onClick={() => deleteDomain(d.id)} className="text-[#8e9296] hover:text-[#e74c3c]"><Trash2 className="w-3 h-3" /></button>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </div>

          {/* Info */}
          <div className="bg-[#2a2d31] rounded p-3 text-[11px] text-[#b0b3b8]">
            <AlertCircle className="w-3.5 h-3.5 inline mr-1 text-[#4a90e2]" />
            <strong>How blocking works:</strong> When a request arrives through your middleware (Next.js or Express), Bloom checks this blocklist.
            If the visitor's IP is listed as <span className="text-[#e74c3c]">blocked</span>, the middleware returns 403.
            Geo-blocked entries (🌍 country:MM) are created automatically by country automation rules.
            The HTML script tag cannot block — it only monitors.
          </div>
        </div>
      )}

      {/* Projects tab */}
      {tab === 'projects' && (
        <div className="space-y-2">
          {projects.length === 0 ? (
            <div className="text-[12px] text-[#6b7075] py-8 text-center">No connected projects yet. Go to Projects page to add one.</div>
          ) : (
            projects.map((p) => (
              <div key={p.id} className="bg-[#232629] border border-[#2e3236] rounded p-3 flex items-center gap-3">
                <span className={`w-2 h-2 rounded-full ${p.status === 'connected' ? 'bg-[#2ecc71] bloom-pulse' : 'bg-[#f4b733]'}`} />
                <div className="flex-1 min-w-0">
                  <div className="text-[12px] text-white font-medium">{p.name}</div>
                  <div className="text-[10px] text-[#8e9296] font-mono">{p.domain}</div>
                </div>
                <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase ${p.firewallEnabled ? 'text-[#2ecc71] bg-[#2ecc71]/10' : 'text-[#8e9296] bg-[#2a2d31]'}`}>
                  {p.firewallEnabled ? 'Firewall ON' : 'Firewall OFF'}
                </span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase ${p.botProtectionEnabled ? 'text-[#2ecc71] bg-[#2ecc71]/10' : 'text-[#8e9296] bg-[#2a2d31]'}`}>
                  {p.botProtectionEnabled ? 'Bot ON' : 'Bot OFF'}
                </span>
                <span className="text-[10px] text-[#8e9296] capitalize">{p.status}</span>
              </div>
            ))
          )}
        </div>
      )}

      {/* Log sources tab */}
      {tab === 'log_sources' && (
        <div className="space-y-2">
          {logSources.length === 0 ? (
            <div className="text-[12px] text-[#6b7075] py-8 text-center">No log sources configured.</div>
          ) : (
            logSources.map((s) => (
              <div key={s.id} className="bg-[#232629] border border-[#2e3236] rounded p-3">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="text-[12px] text-white font-medium font-mono">{s.name}</div>
                    <div className="text-[10px] text-[#8e9296]">{s.sourceType}</div>
                  </div>
                  <span className="flex items-center gap-1.5 text-[11px]">
                    <span className={`w-2 h-2 rounded-full ${s.enabled ? STATUS_COLORS.active : STATUS_COLORS.paused}`} />
                    <span className="text-[#b0b3b8] capitalize">{s.enabled ? 'enabled' : 'disabled'}</span>
                  </span>
                </div>
                {s.endpoint && <div className="text-[10px] text-[#6b7075] font-mono">POST {s.endpoint}</div>}
                <div className="text-[10px] text-[#6b7075] mt-1">
                  {s.eventsIngested.toLocaleString()} events ingested
                  {s.lastEvent && ` · last: ${new Date(s.lastEvent).toLocaleString()}`}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}
