'use client'

import { useEffect, useState } from 'react'
import { Globe, Server, ShieldAlert, Cpu } from 'lucide-react'

interface Asset {
  id: string
  hostname: string
  kind: string
  lastStatus: string
  lastResult: {
    ports: { port: number; service: string; open: boolean }[]
    http: { reachable: boolean; statusCode?: number; server?: string }
    ssl: { valid?: boolean; daysUntilExpiry?: number } | null
  } | null
  openPorts: { port: number; service: string; open: boolean }[]
}

export function AttackSurfaceView() {
  const [assets, setAssets] = useState<Asset[]>([])

  useEffect(() => {
    fetch('/api/attack-surface')
      .then((r) => r.text())
      .then((text) => { try { return JSON.parse(text) } catch { return { assets: [] } } })
      .then((d) => setAssets(d.assets || []))
      .catch(() => {})
  }, [])

  const allPorts = assets.flatMap((t) => (t.openPorts || []).map((p) => ({ ...p, hostname: t.hostname })))
  const internetFacing = assets.filter((t) => t.kind === 'domain')
  const highRisk = assets.filter((t) => {
    if (!t.lastResult) return false
    const openCount = (t.lastResult.ports || []).filter((p: any) => p.open).length
    const sslBad = t.lastResult.ssl && !t.lastResult.ssl.valid
    return openCount >= 3 || sslBad
  })

  return (
    <div className="p-5 space-y-4 max-w-[1600px] mx-auto">
      <div>
        <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
          <Globe className="w-5 h-5 text-[#f39c12]" />
          Attack Surface
        </h1>
        <p className="text-[12px] text-[#8e9296] mt-0.5">
          Derived from your monitored targets. Run analysis on the Monitored Targets page to populate this view.
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Tracked Targets', value: assets.length, icon: Globe, color: 'text-[#4a90e2]' },
          { label: 'Internet-Facing', value: internetFacing.length, icon: ShieldAlert, color: 'text-[#e74c3c]' },
          { label: 'High Risk', value: highRisk.length, icon: ShieldAlert, color: 'text-[#f39c12]' },
          { label: 'Open Ports', value: allPorts.length, icon: Cpu, color: 'text-[#9b59b6]' },
        ].map((s) => {
          const Icon = s.icon
          return (
            <div key={s.label} className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
              <Icon className={`w-4 h-4 ${s.color} mb-2`} />
              <div className="text-[24px] font-bold text-white">{s.value}</div>
              <div className="text-[11px] text-[#8e9296] uppercase">{s.label}</div>
            </div>
          )
        })}
      </div>

      {assets.length === 0 ? (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-12 text-center">
          <Globe className="w-10 h-10 mx-auto mb-3 text-[#6b7075]" />
          <div className="text-[14px] text-white font-medium mb-1">No targets yet</div>
          <p className="text-[12px] text-[#8e9296]">
            Add monitored targets and run analysis to see your attack surface here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {assets.map((t) => {
            const openPorts = t.lastResult?.ports?.filter((p) => p.open) || []
            const sslOk = t.lastResult?.ssl?.valid
            return (
              <div key={t.id} className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded bg-[#1a1d21] flex items-center justify-center shrink-0">
                      {t.kind === 'localhost' ? <Server className="w-5 h-5 text-[#f39c12]" /> : <Globe className="w-5 h-5 text-[#4a90e2]" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[13px] font-medium text-white font-mono truncate">{t.hostname}</div>
                      <div className="text-[10px] text-[#6b7075] uppercase">{t.kind}</div>
                    </div>
                  </div>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${
                    t.lastStatus === 'up' ? 'text-[#2ecc71] bg-[#2ecc71]/10' :
                    t.lastStatus === 'down' ? 'text-[#e74c3c] bg-[#e74c3c]/10' :
                    'text-[#8e9296] bg-[#2a2d31]'
                  }`}>{t.lastStatus}</span>
                </div>

                {t.lastResult ? (
                  <>
                    <div className="grid grid-cols-3 gap-2 text-[11px] mb-2">
                      <div className="bg-[#1a1d21] rounded p-1.5">
                        <div className="text-[#6b7075] uppercase text-[9px]">HTTP</div>
                        <div className={t.lastResult.http?.reachable ? 'text-[#2ecc71]' : 'text-[#e74c3c]'}>
                          {t.lastResult.http?.reachable ? `${t.lastResult.http.statusCode || 'OK'}` : 'down'}
                        </div>
                      </div>
                      <div className="bg-[#1a1d21] rounded p-1.5">
                        <div className="text-[#6b7075] uppercase text-[9px]">SSL</div>
                        <div className={sslOk ? 'text-[#2ecc71]' : sslOk === false ? 'text-[#e74c3c]' : 'text-[#8e9296]'}>
                          {sslOk ? 'valid' : sslOk === false ? 'invalid' : 'n/a'}
                        </div>
                      </div>
                      <div className="bg-[#1a1d21] rounded p-1.5">
                        <div className="text-[#6b7075] uppercase text-[9px]">Ports</div>
                        <div className="text-white">{openPorts.length} open</div>
                      </div>
                    </div>
                    {openPorts.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-2 border-t border-[#2a2d31]">
                        {openPorts.map((p, i) => (
                          <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-[#2ecc71]/20 text-[#2ecc71] font-mono">
                            {p.port}/{p.service}
                          </span>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-[11px] text-[#6b7075] text-center py-4">Not analyzed yet</div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
