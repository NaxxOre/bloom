'use client'

import { useEffect, useState } from 'react'
import {
  Network, Search, Globe, Server, Plus, Trash2, Loader2,
  RefreshCw, ShieldCheck, ShieldAlert, ShieldX, Activity,
  Zap, Clock, Wifi, FileText, Brain,
} from 'lucide-react'
import { toast } from 'sonner'

interface MonitoredTarget {
  id: string
  hostname: string
  kind: string
  label: string | null
  notes: string | null
  lastStatus: string
  lastCheckAt: string | null
  lastResult: TargetAnalysis | null
  createdAt: string
}

interface TargetAnalysis {
  hostname: string
  kind: string
  timestamp: string
  dns: { resolved: boolean; addresses: string[]; cname?: string | null; mx?: string[]; txt?: string[]; ns?: string[]; error?: string }
  http: { reachable: boolean; statusCode?: number; statusText?: string; responseTimeMs?: number; server?: string; contentType?: string; finalUrl?: string; bodyPreview?: string; error?: string }
  ssl: { hasCert?: boolean; valid?: boolean; daysUntilExpiry?: number; issuer?: string; validFrom?: string; validTo?: string; subject?: string; error?: string } | null
  ports: { port: number; service: string; open: boolean; responseTimeMs?: number }[]
  status: 'up' | 'down' | 'partial'
  summary: string
}

interface AiRisk {
  riskLevel: string
  riskScore: number
  findings: string[]
  recommendations: string[]
  provider: string
  model: string
}

const KIND_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  domain: Globe,
  localhost: Server,
  ip: Network,
}

const STATUS_META: Record<string, { color: string; bg: string; icon: React.ComponentType<{ className?: string }>; label: string }> = {
  up: { color: 'text-[#2ecc71]', bg: 'bg-[#2ecc71]/10 border-[#2ecc71]/30', icon: ShieldCheck, label: 'Up' },
  down: { color: 'text-[#e74c3c]', bg: 'bg-[#e74c3c]/10 border-[#e74c3c]/30', icon: ShieldX, label: 'Down' },
  partial: { color: 'text-[#f4b733]', bg: 'bg-[#f4b733]/10 border-[#f4b733]/30', icon: ShieldAlert, label: 'Partial' },
  unknown: { color: 'text-[#8e9296]', bg: 'bg-[#2a2d31] border-[#2e3236]', icon: Activity, label: 'Not checked' },
}

export function MonitoredTargetsView() {
  const [targets, setTargets] = useState<MonitoredTarget[]>([])
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [newTarget, setNewTarget] = useState({ hostname: '', label: '', notes: '' })
  const [analyzing, setAnalyzing] = useState<string | null>(null)
  const [aiRisks, setAiRisks] = useState<Record<string, AiRisk>>({})
  const [expanded, setExpanded] = useState<string | null>(null)

  const load = () => {
    fetch('/api/monitored-targets')
      .then((r) => r.json())
      .then((d) => setTargets(d.targets || []))
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    load()
  }, [])

  const addTarget = async () => {
    if (!newTarget.hostname) {
      toast.error('Hostname required')
      return
    }
    const res = await fetch('/api/monitored-targets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTarget),
    })
    if (res.ok) {
      toast.success(`Added ${newTarget.hostname}`)
      setNewTarget({ hostname: '', label: '', notes: '' })
      setShowAdd(false)
      load()
    } else {
      const d = await res.json().catch(() => ({}))
      toast.error(d.error || 'Failed to add target')
    }
  }

  const deleteTarget = async (id: string) => {
    if (!confirm('Remove this monitored target?')) return
    await fetch(`/api/monitored-targets?id=${id}`, { method: 'DELETE' })
    load()
    toast.success('Target removed')
  }

  const analyzeTarget = async (id: string) => {
    setAnalyzing(id)
    try {
      const res = await fetch('/api/analyze-target', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId: id }),
      })
      const d = await res.json()
      if (d.error) {
        toast.error(`Analysis failed: ${d.error}`)
      } else {
        toast.success(`Analysis complete: ${d.analysis.status}`)
        if (d.aiRisk) {
          setAiRisks((prev) => ({ ...prev, [id]: d.aiRisk }))
        }
        load()
      }
    } catch (err) {
      toast.error(`Analysis failed: ${err instanceof Error ? err.message : 'unknown'}`)
    } finally {
      setAnalyzing(null)
    }
  }

  const stats = {
    total: targets.length,
    up: targets.filter((t) => t.lastStatus === 'up').length,
    down: targets.filter((t) => t.lastStatus === 'down').length,
    partial: targets.filter((t) => t.lastStatus === 'partial').length,
    unchecked: targets.filter((t) => t.lastStatus === 'unknown').length,
  }

  return (
    <div className="p-5 space-y-4 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
            <Network className="w-5 h-5 text-[#f39c12]" />
            Monitored Targets
          </h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">
            Add your own domains, localhost URLs, or IPs — get real DNS, SSL, HTTP, and port scan analysis.
          </p>
        </div>
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-2 bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[12px] px-4 py-2 rounded transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Target
        </button>
      </div>

      {/* Real stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { label: 'Total Targets', value: stats.total, color: 'text-[#4a90e2]' },
          { label: 'Up', value: stats.up, color: 'text-[#2ecc71]' },
          { label: 'Partial', value: stats.partial, color: 'text-[#f4b733]' },
          { label: 'Down', value: stats.down, color: 'text-[#e74c3c]' },
          { label: 'Not Checked', value: stats.unchecked, color: 'text-[#8e9296]' },
        ].map((s) => (
          <div key={s.label} className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
            <div className={`text-[24px] font-bold ${s.color}`}>{s.value}</div>
            <div className="text-[11px] text-[#8e9296] uppercase tracking-wide">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Add target form */}
      {showAdd && (
        <div className="bg-[#232629] border border-[#f39c12] rounded-md p-5 space-y-3">
          <div className="text-[14px] font-semibold text-white">Add Monitored Target</div>
          <p className="text-[11px] text-[#8e9296]">
            Add a domain you own (e.g. <code className="text-[#f4b733]">example.com</code>), a localhost URL
            (e.g. <code className="text-[#f4b733]">localhost:3000</code>), or an IP address. Bloom SIEM will run
            real DNS lookups, SSL cert checks, HTTP reachability tests, and TCP port scans.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input
              value={newTarget.hostname}
              onChange={(e) => setNewTarget({ ...newTarget, hostname: e.target.value })}
              placeholder="example.com or localhost:3000"
              className="bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white font-mono outline-none focus:border-[#f39c12]"
            />
            <input
              value={newTarget.label}
              onChange={(e) => setNewTarget({ ...newTarget, label: e.target.value })}
              placeholder="Label (optional)"
              className="bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white outline-none focus:border-[#f39c12]"
            />
            <input
              value={newTarget.notes}
              onChange={(e) => setNewTarget({ ...newTarget, notes: e.target.value })}
              placeholder="Notes (optional)"
              className="bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white outline-none focus:border-[#f39c12]"
            />
          </div>
          <div className="flex gap-2">
            <button onClick={addTarget} className="bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] text-[12px] font-medium px-4 py-1.5 rounded">
              Add Target
            </button>
            <button onClick={() => setShowAdd(false)} className="bg-[#2a2d31] hover:bg-[#3a3e42] text-white text-[12px] px-4 py-1.5 rounded">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Target cards */}
      {loading && (
        <div className="text-center py-12 text-[#8e9296] text-[13px]">
          <Loader2 className="w-6 h-6 mx-auto mb-2 animate-spin" />
          Loading targets…
        </div>
      )}

      {!loading && targets.length === 0 && (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-12 text-center">
          <Network className="w-10 h-10 mx-auto mb-3 text-[#6b7075]" />
          <div className="text-[14px] text-white font-medium mb-1">No monitored targets yet</div>
          <p className="text-[12px] text-[#8e9296] mb-4">
            Add your first domain or localhost URL to start analyzing.
          </p>
          <button
            onClick={() => setShowAdd(true)}
            className="inline-flex items-center gap-2 bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[12px] px-4 py-2 rounded"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Your First Target
          </button>
        </div>
      )}

      <div className="space-y-3">
        {targets.map((t) => {
          const Icon = KIND_ICONS[t.kind] || Globe
          const statusMeta = STATUS_META[t.lastStatus] || STATUS_META.unknown
          const StatusIcon = statusMeta.icon
          const isExpanded = expanded === t.id
          const analysis = t.lastResult
          const aiRisk = aiRisks[t.id]
          const isAnalyzing = analyzing === t.id

          return (
            <div key={t.id} className="bg-[#232629] border border-[#2e3236] rounded-md overflow-hidden">
              {/* Header row */}
              <div className="p-4 flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className={`w-10 h-10 rounded ${statusMeta.bg} border flex items-center justify-center shrink-0`}>
                    <Icon className={`w-5 h-5 ${statusMeta.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <span className="text-[14px] font-semibold text-white font-mono truncate">{t.hostname}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium flex items-center gap-1 ${statusMeta.bg} ${statusMeta.color}`}>
                        <StatusIcon className="w-3 h-3" />
                        {statusMeta.label}
                      </span>
                      <span className="text-[10px] text-[#6b7075] uppercase">{t.kind}</span>
                    </div>
                    {t.label && <div className="text-[12px] text-[#b0b3b8]">{t.label}</div>}
                    {t.notes && <div className="text-[11px] text-[#6b7075] mt-0.5">{t.notes}</div>}
                    {t.lastCheckAt && (
                      <div className="text-[10px] text-[#6b7075] mt-1">
                        Last checked: {new Date(t.lastCheckAt).toLocaleString()}
                      </div>
                    )}
                    {analysis && (
                      <div className="text-[11px] text-[#8e9296] mt-1.5">{analysis.summary}</div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => analyzeTarget(t.id)}
                    disabled={isAnalyzing}
                    className="flex items-center gap-1.5 bg-[#2a2d31] hover:bg-[#3a3e42] text-white text-[11px] px-3 py-1.5 rounded transition-colors disabled:opacity-50"
                  >
                    {isAnalyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                    {isAnalyzing ? 'Analyzing…' : 'Analyze'}
                  </button>
                  {analysis && (
                    <button
                      onClick={() => setExpanded(isExpanded ? null : t.id)}
                      className="text-[11px] text-[#f39c12] hover:underline px-2"
                    >
                      {isExpanded ? 'Hide' : 'Details'}
                    </button>
                  )}
                  <button
                    onClick={() => deleteTarget(t.id)}
                    className="text-[#8e9296] hover:text-[#e74c3c]"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Expanded details */}
              {isExpanded && analysis && (
                <div className="border-t border-[#2e3236] p-4 space-y-3 bg-[#1a1d21]">
                  {/* Quick stats */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    <div className="bg-[#232629] rounded p-2">
                      <div className="flex items-center gap-1 text-[10px] text-[#6b7075] uppercase mb-1">
                        <Wifi className="w-3 h-3" /> DNS
                      </div>
                      <div className={analysis.dns.resolved ? 'text-[#2ecc71] text-[12px]' : 'text-[#e74c3c] text-[12px]'}>
                        {analysis.dns.resolved ? `Resolved (${analysis.dns.addresses.length})` : 'Failed'}
                      </div>
                    </div>
                    <div className="bg-[#232629] rounded p-2">
                      <div className="flex items-center gap-1 text-[10px] text-[#6b7075] uppercase mb-1">
                        <Globe className="w-3 h-3" /> HTTP
                      </div>
                      <div className={analysis.http.reachable ? 'text-[#2ecc71] text-[12px]' : 'text-[#e74c3c] text-[12px]'}>
                        {analysis.http.reachable ? `${analysis.http.statusCode} · ${analysis.http.responseTimeMs}ms` : 'Unreachable'}
                      </div>
                    </div>
                    <div className="bg-[#232629] rounded p-2">
                      <div className="flex items-center gap-1 text-[10px] text-[#6b7075] uppercase mb-1">
                        <ShieldCheck className="w-3 h-3" /> SSL
                      </div>
                      <div className={
                        analysis.ssl?.valid ? 'text-[#2ecc71] text-[12px]' :
                        analysis.ssl?.hasCert ? 'text-[#f4b733] text-[12px]' : 'text-[#8e9296] text-[12px]'
                      }>
                        {analysis.ssl?.valid ? `Valid (${analysis.ssl.daysUntilExpiry}d)` :
                         analysis.ssl?.hasCert ? 'Invalid' : 'None'}
                      </div>
                    </div>
                    <div className="bg-[#232629] rounded p-2">
                      <div className="flex items-center gap-1 text-[10px] text-[#6b7075] uppercase mb-1">
                        <Zap className="w-3 h-3" /> Ports
                      </div>
                      <div className="text-[12px] text-white">
                        {analysis.ports.filter((p) => p.open).length} open / {analysis.ports.length}
                      </div>
                    </div>
                  </div>

                  {/* DNS details */}
                  <div>
                    <div className="text-[10px] uppercase text-[#6b7075] mb-1 font-medium">DNS Resolution</div>
                    <div className="bg-[#232629] rounded p-2 text-[11px] space-y-1">
                      {analysis.dns.error ? (
                        <div className="text-[#e74c3c]">Error: {analysis.dns.error}</div>
                      ) : (
                        <>
                          <div><span className="text-[#8e9296]">A records:</span> <span className="text-white font-mono">{analysis.dns.addresses.join(', ')}</span></div>
                          {analysis.dns.cname && <div><span className="text-[#8e9296]">CNAME:</span> <span className="text-white font-mono">{analysis.dns.cname}</span></div>}
                          {analysis.dns.mx && analysis.dns.mx.length > 0 && <div><span className="text-[#8e9296]">MX:</span> <span className="text-white font-mono">{analysis.dns.mx.join(', ')}</span></div>}
                          {analysis.dns.ns && analysis.dns.ns.length > 0 && <div><span className="text-[#8e9296]">NS:</span> <span className="text-white font-mono">{analysis.dns.ns.join(', ')}</span></div>}
                          {analysis.dns.txt && analysis.dns.txt.length > 0 && (
                            <div><span className="text-[#8e9296]">TXT:</span> <span className="text-white font-mono text-[10px]">{analysis.dns.txt.slice(0, 3).join(' | ')}</span></div>
                          )}
                        </>
                      )}
                    </div>
                  </div>

                  {/* HTTP details */}
                  <div>
                    <div className="text-[10px] uppercase text-[#6b7075] mb-1 font-medium">HTTP Reachability</div>
                    <div className="bg-[#232629] rounded p-2 text-[11px] space-y-1">
                      {analysis.http.error ? (
                        <div className="text-[#e74c3c]">Error: {analysis.http.error}</div>
                      ) : analysis.http.reachable ? (
                        <>
                          <div><span className="text-[#8e9296]">Status:</span> <span className="text-white font-mono">{analysis.http.statusCode} {analysis.http.statusText}</span></div>
                          <div><span className="text-[#8e9296]">Response time:</span> <span className="text-white font-mono">{analysis.http.responseTimeMs}ms</span></div>
                          {analysis.http.server && <div><span className="text-[#8e9296]">Server:</span> <span className="text-white font-mono">{analysis.http.server}</span></div>}
                          {analysis.http.contentType && <div><span className="text-[#8e9296]">Content-Type:</span> <span className="text-white font-mono">{analysis.http.contentType}</span></div>}
                          {analysis.http.finalUrl && analysis.http.finalUrl !== `https://${analysis.hostname}/` && (
                            <div><span className="text-[#8e9296]">Final URL:</span> <span className="text-white font-mono text-[10px]">{analysis.http.finalUrl}</span></div>
                          )}
                        </>
                      ) : (
                        <div className="text-[#e74c3c]">Unreachable: {analysis.http.error}</div>
                      )}
                    </div>
                  </div>

                  {/* SSL details */}
                  {analysis.ssl && (
                    <div>
                      <div className="text-[10px] uppercase text-[#6b7075] mb-1 font-medium">SSL Certificate</div>
                      <div className="bg-[#232629] rounded p-2 text-[11px] space-y-1">
                        {analysis.ssl.error ? (
                          <div className="text-[#e74c3c]">Error: {analysis.ssl.error}</div>
                        ) : analysis.ssl.hasCert ? (
                          <>
                            <div><span className="text-[#8e9296]">Subject:</span> <span className="text-white font-mono">{analysis.ssl.subject}</span></div>
                            <div><span className="text-[#8e9296]">Issuer:</span> <span className="text-white font-mono">{analysis.ssl.issuer}</span></div>
                            <div><span className="text-[#8e9296]">Valid from:</span> <span className="text-white">{analysis.ssl.validFrom}</span></div>
                            <div><span className="text-[#8e9296]">Valid to:</span> <span className="text-white">{analysis.ssl.validTo}</span></div>
                            <div>
                              <span className="text-[#8e9296]">Status:</span>{' '}
                              <span className={analysis.ssl.valid ? 'text-[#2ecc71]' : 'text-[#e74c3c]'}>
                                {analysis.ssl.valid ? `Valid (${analysis.ssl.daysUntilExpiry} days remaining)` : `Invalid/Expired (${analysis.ssl.daysUntilExpiry} days)`}
                              </span>
                            </div>
                          </>
                        ) : (
                          <div className="text-[#8e9296]">No certificate</div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Port scan results */}
                  <div>
                    <div className="text-[10px] uppercase text-[#6b7075] mb-1 font-medium">Port Scan (real TCP connect)</div>
                    <div className="bg-[#232629] rounded p-2 flex flex-wrap gap-1.5">
                      {analysis.ports.map((p) => (
                        <span
                          key={p.port}
                          className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                            p.open ? 'bg-[#2ecc71]/20 text-[#2ecc71]' : 'bg-[#1a1d21] text-[#6b7075]'
                          }`}
                          title={p.open ? `Open · ${p.responseTimeMs}ms` : 'Closed/filtered'}
                        >
                          {p.port}/{p.service} {p.open ? '✓' : '✗'}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* AI Risk Assessment */}
                  {aiRisk && (
                    <div>
                      <div className="text-[10px] uppercase text-[#6b7075] mb-1 font-medium flex items-center gap-1">
                        <Brain className="w-3 h-3" /> AI Risk Assessment
                        <span className="text-[#f39c12]">· {aiRisk.provider}/{aiRisk.model}</span>
                      </div>
                      <div className={`rounded p-3 border ${
                        aiRisk.riskLevel === 'critical' ? 'bg-[#e74c3c]/10 border-[#e74c3c]/30' :
                        aiRisk.riskLevel === 'high' ? 'bg-[#f39c12]/10 border-[#f39c12]/30' :
                        aiRisk.riskLevel === 'medium' ? 'bg-[#f4b733]/10 border-[#f4b733]/30' :
                        'bg-[#2ecc71]/10 border-[#2ecc71]/30'
                      }`}>
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`text-[14px] font-bold uppercase ${
                            aiRisk.riskLevel === 'critical' ? 'text-[#e74c3c]' :
                            aiRisk.riskLevel === 'high' ? 'text-[#f39c12]' :
                            aiRisk.riskLevel === 'medium' ? 'text-[#f4b733]' : 'text-[#2ecc71]'
                          }`}>
                            {aiRisk.riskLevel}
                          </span>
                          <span className="text-[11px] text-[#8e9296]">· risk score {aiRisk.riskScore}/100</span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
                          <div>
                            <div className="text-[#6b7075] uppercase text-[10px] mb-1">Findings</div>
                            <ul className="space-y-0.5">
                              {aiRisk.findings.map((f, i) => (
                                <li key={i} className="text-[#b0b3b8] flex items-start gap-1">
                                  <span className="text-[#f39c12]">•</span> {f}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <div className="text-[#6b7075] uppercase text-[10px] mb-1">Recommendations</div>
                            <ul className="space-y-0.5">
                              {aiRisk.recommendations.map((r, i) => (
                                <li key={i} className="text-[#b0b3b8] flex items-start gap-1">
                                  <span className="text-[#2ecc71]">✓</span> {r}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Body preview */}
                  {analysis.http.bodyPreview && (
                    <div>
                      <div className="text-[10px] uppercase text-[#6b7075] mb-1 font-medium">Body Preview (first 500 chars)</div>
                      <pre className="bg-[#232629] rounded p-2 text-[10px] text-[#b0b3b8] font-mono overflow-x-auto max-h-32">
                        {analysis.http.bodyPreview}
                      </pre>
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
