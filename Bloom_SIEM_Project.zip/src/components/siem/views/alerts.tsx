'use client'

import { useEffect, useState } from 'react'
import { useSiemStore } from '@/lib/siem-store'
import { AlertTriangle, Ban, Eye, Network, ShieldX, UserX } from 'lucide-react'
import { toast } from 'sonner'
import { AnalystVerdictPanel } from '@/components/siem/analyst-verdict'

interface Alert {
  id: string
  title: string
  description: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  status: 'new' | 'triaged' | 'escalated' | 'closed'
  mitreTactic: string | null
  mitreTechnique: string | null
  source: string
  srcIp: string | null
  agentId: string | null
  triggeredBy: string
  createdAt: string
  actions: { id: string; action: string; target: string; status: string }[]
}

const SEV_COLORS: Record<string, { bg: string; text: string; dot: string }> = {
  critical: { bg: 'bg-[#e74c3c]/15', text: 'text-[#e74c3c]', dot: 'bg-[#e74c3c]' },
  high: { bg: 'bg-[#f39c12]/15', text: 'text-[#f39c12]', dot: 'bg-[#f39c12]' },
  medium: { bg: 'bg-[#f4b733]/15', text: 'text-[#f4b733]', dot: 'bg-[#f4b733]' },
  low: { bg: 'bg-[#8e9296]/15', text: 'text-[#8e9296]', dot: 'bg-[#8e9296]' },
}

const STATUS_COLORS: Record<string, string> = {
  new: 'text-[#4a90e2] bg-[#4a90e2]/10',
  triaged: 'text-[#f4b733] bg-[#f4b733]/10',
  escalated: 'text-[#e74c3c] bg-[#e74c3c]/10',
  closed: 'text-[#2ecc71] bg-[#2ecc71]/10',
}

export function AlertsView() {
  const { alertFilter, setAlertFilter, severityFilter, setSeverityFilter } = useSiemStore()
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [selected, setSelected] = useState<Alert | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    const params = new URLSearchParams()
    if (alertFilter !== 'all') params.set('status', alertFilter)
    if (severityFilter !== 'all') params.set('severity', severityFilter)
    fetch(`/api/alerts?${params}`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) {
          setAlerts(d.alerts || [])
          setLoading(false)
        }
      })
      .catch(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [alertFilter, severityFilter])

  const patchAlert = async (alertId: string, action: 'triage' | 'escalate' | 'close' | 'reopen') => {
    const res = await fetch('/api/alerts', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alertId, action }),
    })
    if (res.ok) {
      const d = await res.json()
      setAlerts((prev) => prev.map((a) => (a.id === alertId ? { ...a, status: d.alert.status } : a)))
      setSelected((p) => (p && p.id === alertId ? { ...p, status: d.alert.status } : p))
      toast.success(`Alert ${action}d`)
    }
  }

  const triggerAction = async (alertId: string, actionType: string, target: string) => {
    const res = await fetch('/api/actions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: actionType, target, reason: `Manual response to alert ${alertId}` }),
    })
    if (res.ok) {
      toast.success(`AI action triggered: ${actionType.replace('_', ' ')} → ${target}`)
    }
  }

  const statusTabs = [
    { id: 'all', label: 'All' },
    { id: 'new', label: 'New' },
    { id: 'triaged', label: 'Triaged' },
    { id: 'escalated', label: 'Escalated' },
    { id: 'closed', label: 'Closed' },
  ] as const

  return (
    <div className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-bold text-white">Security Alerts</h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">Real-time threat detection · {alerts.length} active alerts</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value as typeof severityFilter)}
            className="bg-[#2a2d31] border border-[#2e3236] text-[12px] text-white rounded px-3 py-1.5 outline-none focus:border-[#f39c12]"
          >
            <option value="all">All Severities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {/* Status tabs */}
      <div className="flex items-center gap-1 border-b border-[#2e3236]">
        {statusTabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setAlertFilter(t.id as typeof alertFilter)}
            className={`text-[12px] px-3 py-2 -mb-px border-b-2 transition-colors ${
              alertFilter === t.id
                ? 'border-[#f39c12] text-white'
                : 'border-transparent text-[#8e9296] hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Alerts list */}
        <div className="lg:col-span-2 space-y-2 max-h-[calc(100vh-260px)] overflow-y-auto">
          {loading && <div className="text-[#8e9296] text-sm p-4">Loading alerts...</div>}
          {!loading && alerts.length === 0 && (
            <div className="text-[#8e9296] text-sm p-8 text-center">No alerts match the current filter.</div>
          )}
          {alerts.map((a) => {
            const sev = SEV_COLORS[a.severity]
            const isSelected = selected?.id === a.id
            return (
              <button
                key={a.id}
                onClick={() => setSelected(a)}
                className={`w-full text-left bg-[#232629] border rounded-md p-3 transition-all hover:border-[#3a3e42] ${
                  isSelected ? 'border-[#f39c12]' : 'border-[#2e3236]'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${sev.dot} bloom-pulse`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[13px] font-medium text-white truncate">{a.title}</span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${STATUS_COLORS[a.status]}`}>
                        {a.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#8e9296] line-clamp-2 mb-2">{a.description}</p>
                    <div className="flex items-center gap-3 text-[10px] text-[#6b7075]">
                      <span className={`px-1.5 py-0.5 rounded uppercase font-medium ${sev.bg} ${sev.text}`}>
                        {a.severity}
                      </span>
                      <span className="capitalize">{a.source}</span>
                      {a.mitreTactic && <span>· {a.mitreTactic}</span>}
                      <span className="font-mono">src={a.srcIp || '?'}</span>
                      <span>via {a.triggeredBy}</span>
                      <span className="ml-auto">{new Date(a.createdAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                </div>
              </button>
            )
          })}
        </div>

        {/* Detail panel */}
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4 max-h-[calc(100vh-260px)] overflow-y-auto">
          {!selected && (
            <div className="text-center py-12 text-[#8e9296] text-[13px]">
              <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-40" />
              Select an alert to view details and trigger response actions
            </div>
          )}
          {selected && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className={`w-2 h-2 rounded-full bloom-pulse ${SEV_COLORS[selected.severity].dot}`} />
                  <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${SEV_COLORS[selected.severity].bg} ${SEV_COLORS[selected.severity].text}`}>
                    {selected.severity}
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${STATUS_COLORS[selected.status]}`}>
                    {selected.status}
                  </span>
                </div>
                <h3 className="text-[15px] font-semibold text-white">{selected.title}</h3>
              </div>

              <p className="text-[12px] text-[#b0b3b8] leading-relaxed">{selected.description}</p>

              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="bg-[#1a1d21] rounded p-2">
                  <div className="text-[#6b7075] uppercase text-[10px]">Source IP</div>
                  <div className="text-white font-mono">{selected.srcIp || '—'}</div>
                </div>
                <div className="bg-[#1a1d21] rounded p-2">
                  <div className="text-[#6b7075] uppercase text-[10px]">Source</div>
                  <div className="text-white capitalize">{selected.source}</div>
                </div>
                <div className="bg-[#1a1d21] rounded p-2">
                  <div className="text-[#6b7075] uppercase text-[10px]">MITRE Tactic</div>
                  <div className="text-white">{selected.mitreTactic || '—'}</div>
                </div>
                <div className="bg-[#1a1d21] rounded p-2">
                  <div className="text-[#6b7075] uppercase text-[10px]">MITRE Technique</div>
                  <div className="text-white font-mono">{selected.mitreTechnique || '—'}</div>
                </div>
                <div className="bg-[#1a1d21] rounded p-2">
                  <div className="text-[#6b7075] uppercase text-[10px]">Detected By</div>
                  <div className="text-white capitalize">{selected.triggeredBy}</div>
                </div>
                <div className="bg-[#1a1d21] rounded p-2">
                  <div className="text-[#6b7075] uppercase text-[10px]">Detected At</div>
                  <div className="text-white">{new Date(selected.createdAt).toLocaleString()}</div>
                </div>
              </div>

              {/* AI auto-actions */}
              <div>
                <div className="text-[11px] text-[#8e9296] uppercase tracking-wide mb-2">AI Response Actions</div>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => selected.srcIp && triggerAction(selected.id, 'block_ip', selected.srcIp)}
                    disabled={!selected.srcIp}
                    className="flex items-center gap-2 bg-[#2a2d31] hover:bg-[#3a3e42] disabled:opacity-40 disabled:cursor-not-allowed rounded px-3 py-2 text-[11px] text-white transition-colors"
                  >
                    <Ban className="w-3.5 h-3.5 text-[#e74c3c]" /> Block IP
                  </button>
                  <button
                    onClick={() => selected.agentId && triggerAction(selected.id, 'isolate_host', selected.agentId)}
                    className="flex items-center gap-2 bg-[#2a2d31] hover:bg-[#3a3e42] rounded px-3 py-2 text-[11px] text-white transition-colors"
                  >
                    <Network className="w-3.5 h-3.5 text-[#f39c12]" /> Isolate Host
                  </button>
                  <button
                    onClick={() => triggerAction(selected.id, 'disable_user', 'suspected_account')}
                    className="flex items-center gap-2 bg-[#2a2d31] hover:bg-[#3a3e42] rounded px-3 py-2 text-[11px] text-white transition-colors"
                  >
                    <UserX className="w-3.5 h-3.5 text-[#f4b733]" /> Disable User
                  </button>
                  <button
                    onClick={() => triggerAction(selected.id, 'quarantine_file', 'suspicious_hash')}
                    className="flex items-center gap-2 bg-[#2a2d31] hover:bg-[#3a3e42] rounded px-3 py-2 text-[11px] text-white transition-colors"
                  >
                    <ShieldX className="w-3.5 h-3.5 text-[#9b59b6]" /> Quarantine File
                  </button>
                </div>
              </div>

              {/* Workflow actions */}
              <div>
                <div className="text-[11px] text-[#8e9296] uppercase tracking-wide mb-2">Workflow</div>
                <div className="flex gap-1.5 flex-wrap">
                  <button
                    onClick={() => patchAlert(selected.id, 'triage')}
                    className="bg-[#2a2d31] hover:bg-[#3a3e42] rounded px-3 py-1.5 text-[11px] text-white"
                  >
                    <Eye className="w-3 h-3 inline mr-1" /> Triage
                  </button>
                  <button
                    onClick={() => patchAlert(selected.id, 'escalate')}
                    className="bg-[#2a2d31] hover:bg-[#3a3e42] rounded px-3 py-1.5 text-[11px] text-white"
                  >
                    Escalate
                  </button>
                  <button
                    onClick={() => patchAlert(selected.id, 'close')}
                    className="bg-[#2a2d31] hover:bg-[#3a3e42] rounded px-3 py-1.5 text-[11px] text-white"
                  >
                    Close
                  </button>
                  <button
                    onClick={() => patchAlert(selected.id, 'reopen')}
                    className="bg-[#2a2d31] hover:bg-[#3a3e42] rounded px-3 py-1.5 text-[11px] text-white"
                  >
                    Reopen
                  </button>
                </div>
              </div>

              {selected.actions.length > 0 && (
                <div>
                  <div className="text-[11px] text-[#8e9296] uppercase tracking-wide mb-2">Actions Taken</div>
                  <div className="space-y-1">
                    {selected.actions.map((a) => (
                      <div key={a.id} className="text-[11px] bg-[#1a1d21] rounded p-2 flex items-center gap-2">
                        <span className={`w-1.5 h-1.5 rounded-full ${a.status === 'success' ? 'bg-[#2ecc71]' : 'bg-[#e74c3c]'}`} />
                        <span className="text-[#f39c12] uppercase font-medium">{a.action.replace('_', ' ')}</span>
                        <span className="text-white font-mono flex-1 truncate">{a.target}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* AI Analyst Verdict */}
              <AnalystVerdictPanel alertId={selected.id} />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
