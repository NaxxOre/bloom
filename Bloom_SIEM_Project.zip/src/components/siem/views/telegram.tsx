'use client'

import { useEffect, useState } from 'react'
import { Send, Loader2, Check, Eye, EyeOff, Trash2, Bell, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'

interface TelegramConfig {
  id?: string; botToken: string; chatId: string; enabled: boolean
  notifyOnBlock: boolean; notifyOnMalware: boolean; notifyOnHighSeverity: boolean
  requireApprovalForBlock: boolean
}

const DEFAULT: TelegramConfig = {
  botToken: '', chatId: '', enabled: true,
  notifyOnBlock: true, notifyOnMalware: true, notifyOnHighSeverity: true,
  requireApprovalForBlock: false,
}

export function TelegramView() {
  const [config, setConfig] = useState<TelegramConfig>(DEFAULT)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [reveal, setReveal] = useState(false)
  const [saveResult, setSaveResult] = useState<{ success: boolean; message: string } | null>(null)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)

  useEffect(() => {
    fetch('/api/telegram-config').then((r) => r.json()).then((d) => {
      if (d.config) setConfig({ ...DEFAULT, ...d.config })
    }).finally(() => setLoading(false))
  }, [])

  const save = async () => {
    if (!config.botToken || !config.chatId) { toast.error('Bot token and chat ID required'); return }
    setSaving(true)
    setSaveResult(null)
    try {
      const res = await fetch('/api/telegram-config', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      })
      const text = await res.text()
      let d
      try { d = JSON.parse(text) } catch { d = { error: 'Server returned invalid response' } }
      if (res.ok && d.config) {
        setConfig({ ...DEFAULT, ...d.config })
        setSaveResult({ success: true, message: '✓ Telegram bot connected! A test message was sent to your chat. Check your Telegram app.' })
        toast.success('Telegram connected — test message sent!')
      } else {
        setSaveResult({ success: false, message: d.error || 'Failed to connect. Check your bot token and chat ID.' })
        toast.error(d.error || 'Failed to save')
      }
    } catch (err) {
      setSaveResult({ success: false, message: err instanceof Error ? err.message : 'Network error' })
      toast.error('Network error — check your connection')
    } finally { setSaving(false) }
  }

  const sendTest = async () => {
    setTesting(true)
    setTestResult(null)
    try {
      const res = await fetch('/api/sdk/telegram-test', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) })
      const text = await res.text()
      let d
      try { d = JSON.parse(text) } catch { d = { error: 'Server returned invalid response' } }
      if (d.success) {
        setTestResult({ success: true, message: '✓ Test message sent! Check your Telegram — you should see a message with Approve/Deny buttons.' })
        toast.success('Test message sent to Telegram!')
      } else {
        setTestResult({ success: false, message: d.error || 'Failed to send test message' })
        toast.error(d.error || 'Failed to send test')
      }
    } catch (err) {
      setTestResult({ success: false, message: err instanceof Error ? err.message : 'Network error' })
      toast.error('Network error')
    } finally { setTesting(false) }
  }

  const disconnect = async () => {
    if (!confirm('Disconnect Telegram bot?')) return
    await fetch('/api/telegram-config', { method: 'DELETE' })
    setConfig(DEFAULT); toast.success('Telegram disconnected')
  }

  const [settingWebhook, setSettingWebhook] = useState(false)
  const setupWebhook = async () => {
    setSettingWebhook(true)
    try {
      const res = await fetch('/api/telegram-webhook?action=setup')
      const text = await res.text()
      let d
      try { d = JSON.parse(text) } catch { d = { error: 'Failed' } }
      if (d.success) {
        toast.success('Webhook registered! Approve/Deny buttons will now work.')
        setSaveResult({ success: true, message: d.message })
      } else {
        toast.error(d.error || 'Failed to set webhook')
        setSaveResult({ success: false, message: d.error || 'Failed' })
      }
    } finally { setSettingWebhook(false) }
  }

  if (loading) return <div className="p-6 text-[#8e9296]">Loading…</div>

  return (
    <div className="p-5 space-y-4 max-w-[1000px] mx-auto">
      <div>
        <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
          <Send className="w-5 h-5 text-[#f39c12]" />Telegram Bot Integration
        </h1>
        <p className="text-[12px] text-[#8e9296] mt-0.5">Get instant security alerts on Telegram. AI auto-actions can require your approval via inline buttons.</p>
      </div>

      {config.id ? (
        <div className="bg-[#2ecc71]/10 border border-[#2ecc71]/30 rounded-md p-3 flex items-center gap-2">
          <Check className="w-4 h-4 text-[#2ecc71]" />
          <span className="text-[12px] text-white">Telegram bot connected to chat <code className="text-[#4a90e2]">{config.chatId}</code></span>
        </div>
      ) : (
        <div className="bg-[#2a2d31] border border-[#2e3236] rounded-md p-3 text-[12px] text-[#8e9296]">Not connected yet. Follow the steps below.</div>
      )}

      {/* Setup instructions */}
      <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4 space-y-2">
        <div className="text-[13px] font-semibold text-white">How to get your bot token</div>
        <ol className="text-[11px] text-[#b0b3b8] space-y-1 list-decimal list-inside">
          <li>Open Telegram, search for <code className="text-[#4a90e2]">@BotFather</code></li>
          <li>Send <code className="text-[#4a90e2]">/newbot</code> and follow the prompts</li>
          <li>Copy the bot token (looks like <code className="text-[#f4b733]">123456789:ABCdefGHIjklMNOpqrSTUvwxYZ</code>)</li>
          <li>Open your new bot and send <code className="text-[#4a90e2]">/start</code></li>
          <li>Visit <code className="text-[#4a90e2]">https://api.telegram.org/bot{'<TOKEN>'}/getUpdates</code> to find your chat ID</li>
        </ol>
      </div>

      {/* Config form */}
      <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5 space-y-3">
        <div>
          <label className="text-[11px] text-[#8e9296] uppercase">Bot Token</label>
          <div className="flex items-center gap-2 mt-1">
            <input type={reveal ? 'text' : 'password'} value={config.botToken.includes('…') ? '' : config.botToken}
              onChange={(e) => setConfig({ ...config, botToken: e.target.value })}
              placeholder={config.botToken.includes('…') ? `Saved (${config.botToken})` : '123456789:ABCdef…'}
              className="flex-1 bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white font-mono outline-none focus:border-[#f39c12]" />
            <button onClick={() => setReveal(!reveal)} className="text-[#8e9296] hover:text-white p-2">{reveal ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
          </div>
        </div>
        <div>
          <label className="text-[11px] text-[#8e9296] uppercase">Chat ID</label>
          <input value={config.chatId} onChange={(e) => setConfig({ ...config, chatId: e.target.value })} placeholder="123456789"
            className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white font-mono outline-none focus:border-[#f39c12] mt-1" />
        </div>

        <div className="pt-2 border-t border-[#2a2d31] space-y-2">
          <div className="text-[11px] text-[#8e9296] uppercase font-medium">Notify me on…</div>
          {[
            { key: 'notifyOnBlock', label: 'IP blocked by AI' },
            { key: 'notifyOnMalware', label: 'Malware file upload detected' },
            { key: 'notifyOnHighSeverity', label: 'High-severity alert' },
            { key: 'requireApprovalForBlock', label: 'Require Telegram approval before AI blocks IPs' },
          ].map((t) => (
            <label key={t.key} className="flex items-center gap-2 text-[12px] text-white cursor-pointer">
              <input type="checkbox" checked={(config as Record<string, unknown>)[t.key] as boolean} onChange={(e) => setConfig({ ...config, [t.key]: e.target.checked })} className="w-4 h-4 accent-[#f39c12]" />
              {t.label}
            </label>
          ))}
        </div>

        <div className="flex gap-2 pt-2">
          <button onClick={save} disabled={saving} className="bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[12px] px-4 py-2 rounded disabled:opacity-50 flex items-center gap-2">
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}Save & Send Test
          </button>
          {config.id && (
            <>
              <button onClick={sendTest} disabled={testing} className="bg-[#2a2d31] hover:bg-[#3a3e42] text-white text-[12px] px-4 py-2 rounded flex items-center gap-2 disabled:opacity-50">
                {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Bell className="w-3.5 h-3.5" />}Send Test
              </button>
              <button onClick={setupWebhook} disabled={settingWebhook} className="bg-[#4a90e2]/20 hover:bg-[#4a90e2]/30 text-[#4a90e2] text-[12px] px-4 py-2 rounded flex items-center gap-2 disabled:opacity-50">
                {settingWebhook ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Bell className="w-3.5 h-3.5" />}Enable Buttons
              </button>
              <button onClick={disconnect} className="bg-[#e74c3c]/20 hover:bg-[#e74c3c]/30 text-[#e74c3c] text-[12px] px-4 py-2 rounded flex items-center gap-2 ml-auto">
                <Trash2 className="w-3.5 h-3.5" />Disconnect
              </button>
            </>
          )}
        </div>

        {/* Save result feedback */}
        {saveResult && (
          <div className={`rounded p-3 text-[12px] border flex items-start gap-2 ${
            saveResult.success ? 'bg-[#2ecc71]/10 border-[#2ecc71]/30 text-[#2ecc71]' : 'bg-[#e74c3c]/10 border-[#e74c3c]/30 text-[#e74c3c]'
          }`}>
            {saveResult.success ? <Check className="w-4 h-4 mt-0.5 shrink-0" /> : <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />}
            <span>{saveResult.message}</span>
          </div>
        )}

        {/* Test result feedback */}
        {testResult && (
          <div className={`rounded p-3 text-[12px] border flex items-start gap-2 ${
            testResult.success ? 'bg-[#2ecc71]/10 border-[#2ecc71]/30 text-[#2ecc71]' : 'bg-[#e74c3c]/10 border-[#e74c3c]/30 text-[#e74c3c]'
          }`}>
            {testResult.success ? <Check className="w-4 h-4 mt-0.5 shrink-0" /> : <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />}
            <span>{testResult.message}</span>
          </div>
        )}
      </div>

      {/* Example alert */}
      <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
        <div className="text-[13px] font-semibold text-white mb-2">Example Telegram alert</div>
        <pre className="bg-[#1a1d21] rounded p-3 text-[11px] text-[#b0b3b8] font-mono whitespace-pre-wrap">{`🛡️ Bloom SIEM Alert

⚠️  Malware Upload Blocked
Project: techbridgeacademymm.com
File: profile_image.php.exe
Hash: a3f5...e7b9
IP: 54.183.149.156
Verdict: MALICIOUS (double-extension)
Session: revoked
Action: blocked + user logged out

✅ Approve  ❌ Deny`}</pre>
        <p className="text-[10px] text-[#6b7075] mt-3">
          <strong>Enable Buttons</strong> registers a webhook with Telegram so Approve/Deny button clicks are sent back to Bloom.
          After clicking "Enable Buttons", test it by clicking "Send Test" — then click the Approve/Deny buttons in your Telegram chat.
        </p>
      </div>
    </div>
  )
}
