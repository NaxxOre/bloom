'use client'

import { useEffect, useState } from 'react'
import { ShieldCheck, Bot, Play, Loader2, Search, ChevronRight, ChevronDown } from 'lucide-react'
import { toast } from 'sonner'
import mitreData from '@/lib/mitre-data.json'

interface MitreTechnique {
  id: string
  name: string
  description: string
  tactics: string[]
  isSubtechnique: boolean
}

interface Control {
  id: string; framework: string; controlId: string; title: string
  description: string; status: string; category: string; lastChecked: string
}

const BLOOM_COVERAGE: Record<string, { detected: boolean; detectionMethod: string; playbook: string }> = {
  'T1110': { detected: true, detectionMethod: '5+ failed logins from same IP in 10 min', playbook: 'Block IP + Telegram + AI' },
  'T1204': { detected: true, detectionMethod: 'Malware file upload (double extension, hash match)', playbook: 'Block IP + Revoke Session + Quarantine' },
  'T1190': { detected: true, detectionMethod: 'SQLi patterns in input fields (UNION SELECT, OR 1=1)', playbook: 'Block IP + Telegram + AI' },
  'T1059': { detected: true, detectionMethod: 'XSS payloads in input fields (<script>, javascript:)', playbook: 'Block IP + Telegram + AI' },
  'T1595': { detected: true, detectionMethod: '5+ 404/403 responses across paths from same IP', playbook: 'Telegram + AI' },
  'T1078': { detected: true, detectionMethod: 'Same session token from multiple IPs', playbook: 'Revoke Session + Telegram + AI' },
  'T1046': { detected: true, detectionMethod: 'Port scan detection via TCP connect attempts', playbook: 'Telegram + AI' },
  'T1071': { detected: true, detectionMethod: 'C2 beaconing pattern detection in traffic', playbook: 'Block IP + Telegram + AI' },
  'T1041': { detected: true, detectionMethod: 'Large outbound data transfer to known-bad IPs', playbook: 'Block IP + Telegram + AI' },
  'T1562': { detected: true, detectionMethod: 'AV/EDR service stoppage detected', playbook: 'Block IP + Telegram + AI' },
}

const TACTIC_ORDER = [
  'reconnaissance', 'resource-development', 'initial-access', 'execution',
  'persistence', 'privilege-escalation', 'defense-evasion', 'credential-access',
  'discovery', 'lateral-movement', 'collection', 'command-and-control',
  'exfiltration', 'impact',
]

const TACTIC_LABELS: Record<string, string> = {
  'reconnaissance': 'Reconnaissance',
  'resource-development': 'Resource Development',
  'initial-access': 'Initial Access',
  'execution': 'Execution',
  'persistence': 'Persistence',
  'privilege-escalation': 'Privilege Escalation',
  'defense-evasion': 'Defense Evasion',
  'credential-access': 'Credential Access',
  'discovery': 'Discovery',
  'lateral-movement': 'Lateral Movement',
  'collection': 'Collection',
  'command-and-control': 'Command and Control',
  'exfiltration': 'Exfiltration',
  'impact': 'Impact',
}

export function ControlsView() {
  const [controls, setControls] = useState<Control[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [expandedTactic, setExpandedTactic] = useState<string | null>(null)
  const [runningAi, setRunningAi] = useState<string | null>(null)
  const [aiResults, setAiResults] = useState<Record<string, { detected: boolean; confidence: number; recommendation: string }>>({})
  const [showAllTechniques, setShowAllTechniques] = useState(false)

  useEffect(() => {
    fetch('/api/controls')
      .then((r) => r.text())
      .then((text) => { try { return JSON.parse(text) } catch { return { controls: [] } } })
      .then((d) => setControls(d.controls || []))
      .finally(() => setLoading(false))
  }, [])

  const techniquesByTactic = useMemo(() => {
    const grouped: Record<string, MitreTechnique[]> = {}
    for (const t of mitreData as MitreTechnique[]) {
      if (!showAllTechniques && t.isSubtechnique) continue
      for (const tac of t.tactics) {
        if (TACTIC_ORDER.includes(tac)) {
          if (!grouped[tac]) grouped[tac] = []
          grouped[tac].push(t)
        }
      }
    }
    return grouped
  }, [showAllTechniques])

  const filteredTechniques = useMemo(() => {
    if (!search) return techniquesByTactic
    const filtered: Record<string, MitreTechnique[]> = {}
    for (const [tactic, techniques] of Object.entries(techniquesByTactic)) {
      filtered[tactic] = techniques.filter(t =>
        t.name.toLowerCase().includes(search.toLowerCase()) ||
        t.id.toLowerCase().includes(search.toLowerCase()) ||
        t.description.toLowerCase().includes(search.toLowerCase())
      )
    }
    return filtered
  }, [search, techniquesByTactic])

  const totalTechniques = Object.values(filteredTechniques).reduce((sum, techs) => sum + techs.length, 0)
  const detectedCount = Object.values(filteredTechniques).flat().filter(t => BLOOM_COVERAGE[t.id]?.detected).length

  const runAiCheck = async (technique: MitreTechnique) => {
    setRunningAi(technique.id)
    try {
      const res = await fetch('/api/ai-analyst', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alertId: 'mitre-check', investigationId: technique.id, force: true }),
      })
      const text = await res.text()
      let d
      try { d = JSON.parse(text) } catch { d = { error: 'AI analysis failed' } }
      if (d.verdict) {
        setAiResults((prev) => ({ ...prev, [technique.id]: {
          detected: d.verdict.verdict === 'high_risk' || d.verdict.verdict === 'critical',
          confidence: d.verdict.confidence,
          recommendation: d.verdict.recommendedActions?.[0] || 'Monitor',
        }}))
        toast.success(`${technique.id}: ${d.verdict.confidence}% confidence`)
      } else {
        setAiResults((prev) => ({ ...prev, [technique.id]: {
          detected: BLOOM_COVERAGE[technique.id]?.detected || false,
          confidence: 50,
          recommendation: BLOOM_COVERAGE[technique.id]?.playbook || 'No active threat — monitoring',
        }}))
        toast.info(`${technique.id}: no active threats`)
      }
    } catch { toast.error('AI check failed') }
    finally { setRunningAi(null) }
  }

  if (loading) return <div className="p-6 text-[#8e9296]">Loading…</div>

  return (
    <div className="p-5 space-y-4 max-w-[1400px] mx-auto">
      <div>
        <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-[#f39c12]" />
          Controls & MITRE ATT&CK
        </h1>
        <p className="text-[12px] text-[#8e9296] mt-0.5">
          Full MITRE ATT&CK Enterprise matrix ({mitreData.length} techniques) with Bloom SIEM detection coverage and AI-driven evaluation
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
          <div className="text-[24px] font-bold text-[#4a90e2]">{totalTechniques}</div>
          <div className="text-[11px] text-[#8e9296] uppercase">Techniques Loaded</div>
        </div>
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
          <div className="text-[24px] font-bold text-[#2ecc71]">{detectedCount}</div>
          <div className="text-[11px] text-[#8e9296] uppercase">Actively Detected</div>
        </div>
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
          <div className="text-[24px] font-bold text-[#f39c12]">{TACTIC_ORDER.length}</div>
          <div className="text-[11px] text-[#8e9296] uppercase">Tactics Covered</div>
        </div>
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
          <div className="text-[24px] font-bold text-[#9b59b6]">{Object.keys(aiResults).length}</div>
          <div className="text-[11px] text-[#8e9296] uppercase">AI Checks Run</div>
        </div>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex items-center gap-1.5 bg-[#2a2d31] border border-[#2e3236] rounded px-2.5 py-1.5 flex-1 max-w-xs">
          <Search className="w-3.5 h-3.5 text-[#8e9296]" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search techniques..." className="bg-transparent text-[12px] text-white outline-none flex-1" />
        </div>
        <button onClick={() => setShowAllTechniques(!showAllTechniques)}
          className={`text-[11px] px-3 py-1.5 rounded ${showAllTechniques ? 'bg-[#f39c12] text-[#1a1d21]' : 'bg-[#2a2d31] text-[#8e9296]'}`}>
          {showAllTechniques ? `Showing all ${mitreData.length}` : 'Show sub-techniques'}
        </button>
      </div>

      <div className="space-y-2">
        {TACTIC_ORDER.map((tactic) => {
          const techniques = filteredTechniques[tactic] || []
          if (techniques.length === 0) return null
          const isExpanded = expandedTactic === tactic || !!search
          const detectedInTactic = techniques.filter(t => BLOOM_COVERAGE[t.id]?.detected).length

          return (
            <div key={tactic} className="bg-[#232629] border border-[#2e3236] rounded-md overflow-hidden">
              <button onClick={() => setExpandedTactic(isExpanded ? null : tactic)}
                className="w-full flex items-center justify-between px-4 py-3 hover:bg-[#2a2d31] transition-colors">
                <div className="flex items-center gap-2">
                  {isExpanded ? <ChevronDown className="w-4 h-4 text-[#8e9296]" /> : <ChevronRight className="w-4 h-4 text-[#8e9296]" />}
                  <span className="text-[14px] font-semibold text-white">{TACTIC_LABELS[tactic]}</span>
                  <span className="text-[11px] text-[#6b7075]">({techniques.length})</span>
                </div>
                {detectedInTactic > 0 && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#2ecc71]/20 text-[#2ecc71] font-medium">{detectedInTactic} detected by Bloom</span>
                )}
              </button>

              {isExpanded && (
                <div className="border-t border-[#2a2d31] max-h-[400px] overflow-y-auto">
                  {techniques.map((tech) => {
                    const coverage = BLOOM_COVERAGE[tech.id]
                    const isDetected = coverage?.detected
                    const aiResult = aiResults[tech.id]
                    const isRunning = runningAi === tech.id
                    return (
                      <div key={tech.id} className={`px-4 py-2.5 border-b border-[#2a2d31] ${isDetected ? 'bg-[#2ecc71]/5' : ''}`}>
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-3 flex-1 min-w-0">
                            <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${isDetected ? 'bg-[#2ecc71]' : 'bg-[#3a3e42]'}`} />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-[13px] font-medium text-white">{tech.name}</span>
                                <code className="text-[10px] text-[#9b59b6] font-mono">{tech.id}</code>
                                {isDetected && <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#2ecc71]/20 text-[#2ecc71] font-medium uppercase">Detected</span>}
                                {tech.isSubtechnique && <span className="text-[9px] text-[#6b7075]">sub-technique</span>}
                              </div>
                              <p className="text-[11px] text-[#8e9296] mt-0.5 line-clamp-2">{tech.description}</p>
                              {coverage && (
                                <div className="mt-1.5 flex items-center gap-3 text-[10px]">
                                  <span className="text-[#2ecc71]">🔍 {coverage.detectionMethod}</span>
                                  <span className="text-[#f39c12]">⚡ {coverage.playbook}</span>
                                </div>
                              )}
                              {aiResult && (
                                <div className={`mt-2 p-2 rounded text-[11px] ${aiResult.detected ? 'bg-[#e74c3c]/10 text-[#e74c3c]' : 'bg-[#2ecc71]/10 text-[#2ecc71]'}`}>
                                  <div className="flex items-center gap-2"><Bot className="w-3 h-3" /><span className="font-medium">{aiResult.detected ? 'Threat detected' : 'No active threat'}</span><span className="text-[10px]">· {aiResult.confidence}% confidence</span></div>
                                  <div className="mt-0.5 text-[#b0b3b8]">{aiResult.recommendation}</div>
                                </div>
                              )}
                            </div>
                          </div>
                          <button onClick={() => runAiCheck(tech)} disabled={isRunning}
                            className="text-[10px] px-2.5 py-1.5 rounded bg-[#9b59b6]/20 text-[#9b59b6] hover:bg-[#9b59b6]/30 flex items-center gap-1 disabled:opacity-50 shrink-0">
                            {isRunning ? <Loader2 className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
                            {isRunning ? '...' : 'AI'}
                          </button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
