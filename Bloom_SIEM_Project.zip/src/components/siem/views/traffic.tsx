'use client'

import { useEffect, useState } from 'react'
import {
  Activity, Shield, ShieldOff, Bot, Zap, Globe, Server,
  TrendingUp, Clock, ChevronRight, AlertCircle, CheckCircle2,
} from 'lucide-react'

interface TrafficData {
  project: {
    id: string; name: string; domain: string; status: string
    firewallEnabled: boolean; botProtectionEnabled: boolean; lastEventAt: string | null
  }
  window: string
  overview: {
    firewall: string; botProtection: string; customRules: number; totalEvents: number
    allowed: number; denied: number; challenged: number; logged: number; rateLimited: number
  }
  topIps: { ip: string; count: number }[]
  topJa4: { ja4: string; count: number }[]
  topAsn: { asn: string; count: number }[]
  topUserAgents: { ua: string; count: number }[]
  topPaths: { path: string; count: number }[]
  topHosts: { host: string; count: number }[]
  rules: { id: string; name: string; description: string; action: string; hits: number; enabled: boolean }[]
  recentEvents: {
    id: string; method: string; path: string; ip: string; action: string; rule: string | null
    userAgent: string | null; statusCode: number | null; responseTime: number | null; timestamp: string
  }[]
}

const ACTION_COLORS: Record<string, string> = {
  allowed: 'text-[#2ecc71] bg-[#2ecc71]/10',
  denied: 'text-[#e74c3c] bg-[#e74c3c]/10',
  challenged: 'text-[#f4b733] bg-[#f4b733]/10',
  logged: 'text-[#8e9296] bg-[#8e9296]/10',
  rate_limited: 'text-[#f39c12] bg-[#f39c12]/10',
}

export function TrafficView() {
  const [projects, setProjects] = useState<TrafficData['project'][]>([])
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [data, setData] = useState<TrafficData | null>(null)
  const [window, setWindow] = useState('24')

  useEffect(() => {
    fetch('/api/projects').then((r) => r.json()).then((d) => {
      setProjects(d.projects || [])
      if (d.projects?.length > 0 && !selectedProject) {
        setSelectedProject(d.projects[0].id)
      }
    })
  }, [])

  useEffect(() => {
    if (!selectedProject) return
    const interval = setInterval(() => {
      fetch(`/api/traffic?projectId=${selectedProject}&window=${window}`)
        .then((r) => r.json()).then(setData).catch(() => {})
    }, 5000)
    fetch(`/api/traffic?projectId=${selectedProject}&window=${window}`)
      .then((r) => r.json()).then(setData)
    return () => clearInterval(interval)
  }, [selectedProject, window])

  return (
    <div className="p-5 space-y-4 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#f39c12]" />
            Traffic Overview
          </h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">Real-time WAF metrics — Vercel-style. Auto-refreshes every 5s.</p>
        </div>
        <div className="flex items-center gap-2">
          {projects.length > 0 && (
            <select value={selectedProject || ''} onChange={(e) => setSelectedProject(e.target.value)}
              className="bg-[#2a2d31] border border-[#2e3236] text-[12px] text-white rounded px-3 py-1.5 outline-none focus:border-[#f39c12]">
              {projects.map((p) => <option key={p.id} value={p.id}>{p.name} — {p.domain}</option>)}
            </select>
          )}
          <select value={window} onChange={(e) => setWindow(e.target.value)}
            className="bg-[#2a2d31] border border-[#2e3236] text-[12px] text-white rounded px-3 py-1.5">
            <option value="1">Last 1h</option><option value="6">Last 6h</option>
            <option value="24">Last 24h</option><option value="168">Last 7d</option>
          </select>
        </div>
      </div>

      {!data && <div className="text-center py-12 text-[#8e9296]">{projects.length === 0 ? 'No projects connected. Add a project first.' : 'Loading traffic data…'}</div>}

      {data && (
        <>
          <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-[16px] font-semibold text-white">{data.project.domain}</div>
                <div className="text-[11px] text-[#8e9296]">{data.project.name} · {data.window} window</div>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-[#2ecc71]">
                <span className="relative w-2 h-2"><span className="absolute inset-0 rounded-full bg-[#2ecc71] bloom-pulse" /></span>
                Live
              </div>
            </div>

            <div className={`rounded-md p-3 mb-4 border ${data.overview.firewall === 'active' ? 'bg-[#2ecc71]/10 border-[#2ecc71]/30' : 'bg-[#2a2d31] border-[#2e3236]'}`}>
              <div className="flex items-center gap-3">
                {data.overview.firewall === 'active' ? <Shield className="w-5 h-5 text-[#2ecc71]" /> : <ShieldOff className="w-5 h-5 text-[#8e9296]" />}
                <div className="flex-1">
                  <div className="text-[13px] font-semibold text-white">Firewall is {data.overview.firewall}</div>
                  <div className="text-[11px] text-[#8e9296]">{data.overview.firewall === 'active' ? 'All systems normal' : 'No traffic is being filtered'}</div>
                </div>
                <div className="flex items-center gap-1.5 text-[11px]">
                  <Bot className={`w-3.5 h-3.5 ${data.overview.botProtection === 'active' ? 'text-[#2ecc71]' : 'text-[#8e9296]'}`} />
                  <span className={data.overview.botProtection === 'active' ? 'text-[#2ecc71]' : 'text-[#8e9296]'}>Bot Protection {data.overview.botProtection}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
              {[
                { label: 'Custom Rules', value: data.overview.customRules },
                { label: 'Allowed', value: data.overview.allowed, color: 'text-[#2ecc71]' },
                { label: 'Denied', value: data.overview.denied || '—', color: 'text-[#e74c3c]' },
                { label: 'Challenged', value: data.overview.challenged || '—', color: 'text-[#f4b733]' },
                { label: 'Logged', value: data.overview.logged || '—', color: 'text-[#8e9296]' },
                { label: 'Rate Limited', value: data.overview.rateLimited || '—', color: 'text-[#f39c12]' },
              ].map((s) => (
                <div key={s.label} className="bg-[#1a1d21] rounded p-3">
                  <div className="text-[10px] text-[#6b7075] uppercase">{s.label}</div>
                  <div className={`text-[24px] font-bold ${s.color || 'text-white'}`}>{s.value}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <TopList title="Top IPs" icon={Globe} items={data.topIps.map((r) => ({ key: r.ip, count: r.count }))} emptyHint="No traffic yet" />
            <TopList title="Top JA4 Digests" icon={Zap} items={data.topJa4.map((r) => ({ key: r.ja4 || '—', count: r.count }))} emptyHint="No TLS fingerprints yet" mono />
            <TopList title="Top AS Names" icon={Server} items={data.topAsn.map((r) => ({ asn: r.asn || 'Unknown', count: r.count }))} emptyHint="No ASN data yet" />
            <TopList title="Top User Agents" icon={Bot} items={data.topUserAgents.map((r) => ({ key: r.ua || '—', count: r.count }))} emptyHint="No user agents yet" />
            <TopList title="Top Request Paths" icon={TrendingUp} items={data.topPaths.map((r) => ({ key: r.path, count: r.count }))} emptyHint="No requests yet" mono />
            <TopList title="Top Hosts" icon={Globe} items={data.topHosts.map((r) => ({ key: r.host, count: r.count }))} emptyHint="No hosts yet" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
              <h3 className="text-[13px] font-semibold text-white mb-3">Rules</h3>
              {data.rules.length === 0 ? (
                <div className="text-[12px] text-[#6b7075] py-6 text-center">There are no enforced rules</div>
              ) : (
                <div className="space-y-2">
                  {data.rules.map((r) => (
                    <div key={r.id} className="bg-[#1a1d21] rounded p-2.5 flex items-center gap-3">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${ACTION_COLORS[r.action] || ACTION_COLORS.logged}`}>{r.action}</span>
                      <div className="flex-1 min-w-0"><div className="text-[12px] text-white font-medium truncate">{r.name}</div><div className="text-[10px] text-[#6b7075] truncate">{r.description}</div></div>
                      <span className="text-[10px] text-[#8e9296]">{r.hits} hits</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
              <h3 className="text-[13px] font-semibold text-white mb-3">Recent Requests</h3>
              <div className="space-y-1 max-h-[300px] overflow-y-auto">
                {data.recentEvents.length === 0 ? (
                  <div className="text-[12px] text-[#6b7075] py-6 text-center">No requests in this window</div>
                ) : (
                  data.recentEvents.map((e) => (
                    <div key={e.id} className="text-[11px] flex items-center gap-2 py-1 px-1.5 hover:bg-[#2a2d31] rounded">
                      <span className={`text-[9px] px-1 py-0.5 rounded uppercase font-medium ${ACTION_COLORS[e.action] || ACTION_COLORS.logged}`}>{e.action}</span>
                      <span className="text-[#4a90e2] font-mono w-12 shrink-0">{e.method}</span>
                      <span className="text-white font-mono flex-1 truncate">{e.path}</span>
                      <span className="text-[#8e9296] font-mono text-[10px] hidden md:block">{e.ip}</span>
                      <span className="text-[#6b7075] text-[10px]">{new Date(e.timestamp).toLocaleTimeString()}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

function TopList({ title, icon: Icon, items, emptyHint, mono }: {
  title: string; icon: React.ComponentType<{ className?: string }>
  items: { key?: string; asn?: string; count: number }[]; emptyHint: string; mono?: boolean
}) {
  return (
    <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-3.5 h-3.5 text-[#f39c12]" />
        <h3 className="text-[12px] font-semibold text-white">{title}</h3>
      </div>
      {items.length === 0 ? (
        <div className="text-[11px] text-[#6b7075] py-4 text-center">{emptyHint}</div>
      ) : (
        <div className="space-y-1">
          {items.map((item, i) => {
            const displayKey = item.key || item.asn || '—'
            return (
              <div key={i} className="flex items-center justify-between gap-2 text-[11px]">
                <span className={`text-[#b0b3b8] truncate flex-1 ${mono ? 'font-mono' : ''}`}>{displayKey}</span>
                <span className="text-[#f39c12] font-mono shrink-0">{item.count}</span>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
