'use client'

import { useEffect, useState } from 'react'
import { BarChart3, TrendingUp, AlertTriangle, KeyRound, Activity, Loader2, Network, Globe, MousePointer, Search } from 'lucide-react'
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, LineChart, Line } from 'recharts'
import { toast } from 'sonner'

interface Project { id: string; name: string; domain: string }

interface InputAnalysis {
  window: string
  totalInputEvents: number
  topFields: { name: string; count: number; uniqueIps: number; paths: string[] }[]
  topIpsPerField: { ip: string; fields: { field: string; count: number }[]; totalRequests: number }[]
  bruteForceDetected: { ip: string; field: string; count: number; severity: string }[]
  sessionReplication: { sessionId: string; ips: string[] }[]
  spikeData: { time: string; ip: string; field: string; count: number }[]
  siteDiscovery: {
    totalRoutes: number
    totalInputFields: number
    totalButtons: number
    totalInaccessible: number
    allRoutes: { path: string; count: number; methods: string[]; statusCodes: number[]; accessible: boolean }[]
    inaccessibleRoutes: { path: string; count: number; statusCodes: number[] }[]
    allInputFields: { name: string; count: number; paths: string[] }[]
    allButtons: { name: string; count: number }[]
  }
}

export function ReportsView() {
  const [projects, setProjects] = useState<Project[]>([])
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [analysis, setAnalysis] = useState<InputAnalysis | null>(null)
  const [loading, setLoading] = useState(true)
  const [scanning, setScanning] = useState(false)

  useEffect(() => {
    fetch('/api/projects')
      .then((r) => r.text())
      .then((text) => { try { return JSON.parse(text) } catch { return { projects: [] } } })
      .then((d) => {
        setProjects(d.projects || [])
        if (d.projects?.length > 0) setSelectedProject(d.projects[0].id)
      })
  }, [])

  const loadAnalysis = () => {
    if (!selectedProject) return
    fetch(`/api/input-analysis?projectId=${selectedProject}&window=24`)
      .then((r) => r.text())
      .then((text) => { try { return JSON.parse(text) } catch { return null } })
      .then((d) => setAnalysis(d))
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    if (!selectedProject) return
    setLoading(true)
    loadAnalysis()
    const interval = setInterval(loadAnalysis, 10000)
    return () => clearInterval(interval)
  }, [selectedProject])

  const scanSite = async () => {
    if (!selectedProject) return
    setScanning(true)
    try {
      const res = await fetch('/api/scan-site', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId: selectedProject }),
      })
      const text = await res.text()
      let d
      try { d = JSON.parse(text) } catch { d = { error: 'Scan failed' } }
      if (d.success) {
        toast.success(`Scanned: ${d.scan.routesFound} routes, ${d.scan.formsFound} forms, ${d.scan.buttonsFound} buttons`)
        loadAnalysis() // Immediately refresh
      } else {
        toast.error(d.error || 'Scan failed')
      }
    } finally { setScanning(false) }
  }

  const spikeChart = analysis?.spikeData
    ? analysis.spikeData.reduce((acc: Record<string, Record<string, number>>, item) => {
        if (!acc[item.time]) acc[item.time] = {}
        acc[item.time][item.ip] = (acc[item.time][item.ip] || 0) + item.count
        return acc
      }, {})
    : {}
  const spikeChartData = Object.entries(spikeChart).map(([time, ips]) => ({ time, ...ips }))

  // Safe defaults — API may omit fields when there's no data
  const safeAnalysis = {
    totalInputEvents: analysis?.totalInputEvents || 0,
    topFields: analysis?.topFields || [],
    topIpsPerField: analysis?.topIpsPerField || [],
    bruteForceDetected: analysis?.bruteForceDetected || [],
    sessionReplication: analysis?.sessionReplication || [],
    spikeData: analysis?.spikeData || [],
    siteDiscovery: analysis?.siteDiscovery || null,
  }

  return (
    <div className="p-5 space-y-5 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#f39c12]" />
            Reports & Dashboards
          </h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">Input field analysis, brute-force detection, session replication — real data from your connected site</p>
        </div>
        <div className="flex items-center gap-2">
          {projects.length > 0 && (
            <select value={selectedProject || ''} onChange={(e) => setSelectedProject(e.target.value)}
              className="bg-[#2a2d31] border border-[#2e3236] text-[12px] text-white rounded px-3 py-1.5">
              {projects.map((p) => <option key={p.id} value={p.id}>{p.domain}</option>)}
            </select>
          )}
          <button onClick={scanSite} disabled={scanning || !selectedProject}
            className="flex items-center gap-1.5 bg-[#9b59b6] hover:bg-[#8e44ad] text-white text-[11px] px-3 py-1.5 rounded disabled:opacity-50">
            {scanning ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}
            {scanning ? 'Scanning...' : 'Scan Site'}
          </button>
        </div>
      </div>

      {!selectedProject ? (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-12 text-center text-[#8e9296] text-[13px]">
          Connect a project first to see analytics.
        </div>
      ) : loading ? (
        <div className="text-center py-12 text-[#8e9296]">
          <Loader2 className="w-6 h-6 mx-auto mb-2 animate-spin" />
          Analyzing input data…
        </div>
      ) : !analysis || (safeAnalysis.totalInputEvents === 0 && (!safeAnalysis.siteDiscovery || safeAnalysis.siteDiscovery.totalRoutes <= 1)) ? (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-12 text-center">
          <BarChart3 className="w-10 h-10 mx-auto mb-3 text-[#6b7075]" />
          <div className="text-[14px] text-white font-medium mb-1">No data yet</div>
          <p className="text-[12px] text-[#8e9296] mb-4">
            Click "Scan Site" above to discover routes, forms, and buttons on your connected site.
            Once visitors interact with your site, input field analysis and brute-force detection will appear here.
          </p>
          <button onClick={scanSite} disabled={scanning}
            className="inline-flex items-center gap-1.5 bg-[#9b59b6] hover:bg-[#8e44ad] text-white text-[12px] px-4 py-2 rounded disabled:opacity-50">
            {scanning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            Scan {projects.find((p) => p.id === selectedProject)?.domain}
          </button>
        </div>
      ) : (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard label="Total Events" value={safeAnalysis.totalInputEvents} color="text-[#4a90e2]" />
            <StatCard label="Tracked Fields" value={safeAnalysis.topFields.length} color="text-[#9b59b6]" />
            <StatCard label="Brute-Force IPs" value={safeAnalysis.bruteForceDetected.length} color="text-[#e74c3c]" />
            <StatCard label="Session Replication" value={safeAnalysis.sessionReplication.length} color="text-[#f39c12]" />
          </div>

          {/* Brute-force alerts */}
          {safeAnalysis.bruteForceDetected.length > 0 && (
            <div className="bg-[#e74c3c]/10 border border-[#e74c3c]/30 rounded-md p-4">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle className="w-4 h-4 text-[#e74c3c]" />
                <h3 className="text-[14px] font-semibold text-white">Brute-Force Detection</h3>
              </div>
              <div className="space-y-2">
                {safeAnalysis.bruteForceDetected.slice(0, 10).map((bf, i) => (
                  <div key={i} className="bg-[#1a1d21] rounded p-2.5 flex items-center gap-3 text-[12px]">
                    <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${
                      bf.severity === 'critical' ? 'text-[#e74c3c] bg-[#e74c3c]/20' :
                      bf.severity === 'high' ? 'text-[#f39c12] bg-[#f39c12]/20' : 'text-[#f4b733] bg-[#f4b733]/20'
                    }`}>{bf.severity}</span>
                    <span className="text-white font-mono">{bf.ip}</span>
                    <span className="text-[#8e9296]">brute-forcing</span>
                    <span className="text-[#f39c12] font-mono">{bf.field}</span>
                    <span className="text-[#8e9296]">— {bf.count} attempts</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Session replication */}
          {safeAnalysis.sessionReplication.length > 0 && (
            <div className="bg-[#f39c12]/10 border border-[#f39c12]/30 rounded-md p-4">
              <div className="flex items-center gap-2 mb-3">
                <KeyRound className="w-4 h-4 text-[#f39c12]" />
                <h3 className="text-[14px] font-semibold text-white">Session Replication Detected</h3>
              </div>
              <div className="space-y-2">
                {safeAnalysis.sessionReplication.map((s, i) => (
                  <div key={i} className="bg-[#1a1d21] rounded p-2.5 text-[12px]">
                    <div className="text-[#9b59b6] font-mono mb-1">Session: {s.sessionId.slice(0, 20)}…</div>
                    <div className="text-[#8e9296]">Used from {s.ips.length} different IPs:</div>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {s.ips.map((ip, j) => (
                        <span key={j} className="text-[10px] px-1.5 py-0.5 rounded bg-[#e74c3c]/20 text-[#e74c3c] font-mono">{ip}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Top input fields chart */}
          {safeAnalysis.topFields.length > 0 && (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
              <h3 className="text-[14px] font-semibold text-white mb-3 flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#f39c12]" />
                Top Input Fields Targeted
              </h3>
              <div className="h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={safeAnalysis.topFields} layout="vertical">
                    <CartesianGrid stroke="#2e3236" strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" stroke="#6b7075" tick={{ fontSize: 10 }} allowDecimals={false} />
                    <YAxis dataKey="name" type="category" stroke="#6b7075" tick={{ fontSize: 11 }} width={80} />
                    <Tooltip contentStyle={{ background: '#1a1d21', border: '1px solid #2e3236', borderRadius: 6, fontSize: 12 }} />
                    <Bar dataKey="count" fill="#4a90e2" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* IP spike graph */}
          {spikeChartData.length > 0 && (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
              <h3 className="text-[14px] font-semibold text-white mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#f39c12]" />
                IP Activity Spike Graph (requests per hour)
              </h3>
              <div className="h-[260px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={spikeChartData}>
                    <CartesianGrid stroke="#2e3236" strokeDasharray="3 3" />
                    <XAxis dataKey="time" stroke="#6b7075" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#6b7075" tick={{ fontSize: 10 }} allowDecimals={false} />
                    <Tooltip contentStyle={{ background: '#1a1d21', border: '1px solid #2e3236', borderRadius: 6, fontSize: 12 }} />
                    {Object.keys(spikeChart[Object.keys(spikeChart)[0] || '{}'] || {}).slice(0, 5).map((ip, i) => (
                      <Line key={ip} type="monotone" dataKey={ip} stroke={['#4a90e2', '#f39c12', '#2ecc71', '#e74c3c', '#9b59b6'][i]} strokeWidth={2} dot={false} />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Top IPs per field */}
          {safeAnalysis.topIpsPerField.length > 0 && (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
              <h3 className="text-[14px] font-semibold text-white mb-3">Top IPs by Request Volume</h3>
              <div className="space-y-2">
                {safeAnalysis.topIpsPerField.slice(0, 10).map((entry, i) => (
                  <div key={i} className="bg-[#1a1d21] rounded p-2.5 flex items-center gap-3 text-[12px]">
                    <span className="text-[#6b7075] font-mono w-6">{i + 1}.</span>
                    <span className="text-white font-mono flex-1">{entry.ip}</span>
                    <span className="text-[#8e9296]">{entry.totalRequests} requests</span>
                    <div className="flex gap-1 flex-wrap">
                      {entry.fields.slice(0, 3).map((f, j) => (
                        <span key={j} className="text-[10px] px-1.5 py-0.5 rounded bg-[#2a2d31] text-[#f4b733] font-mono">
                          {f.field}: {f.count}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Site Discovery Panel */}
          {safeAnalysis.siteDiscovery && safeAnalysis.siteDiscovery.totalRoutes > 0 && (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
              <h3 className="text-[14px] font-semibold text-white mb-4 flex items-center gap-2">
                <Network className="w-4 h-4 text-[#f39c12]" />
                Site Discovery — {projects.find((p) => p.id === selectedProject)?.domain}
              </h3>

              <div className="grid grid-cols-4 gap-3 mb-4">
                <div className="bg-[#1a1d21] rounded p-3">
                  <div className="text-[20px] font-bold text-[#4a90e2]">{safeAnalysis.siteDiscovery.totalRoutes}</div>
                  <div className="text-[10px] text-[#8e9296] uppercase">Routes Discovered</div>
                </div>
                <div className="bg-[#1a1d21] rounded p-3">
                  <div className="text-[20px] font-bold text-[#9b59b6]">{safeAnalysis.siteDiscovery.totalInputFields}</div>
                  <div className="text-[10px] text-[#8e9296] uppercase">Input Fields</div>
                </div>
                <div className="bg-[#1a1d21] rounded p-3">
                  <div className="text-[20px] font-bold text-[#2ecc71]">{safeAnalysis.siteDiscovery.totalButtons}</div>
                  <div className="text-[10px] text-[#8e9296] uppercase">Buttons Clicked</div>
                </div>
                <div className="bg-[#1a1d21] rounded p-3">
                  <div className="text-[20px] font-bold text-[#e74c3c]">{safeAnalysis.siteDiscovery.totalInaccessible}</div>
                  <div className="text-[10px] text-[#8e9296] uppercase">Inaccessible Routes</div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <div className="text-[12px] font-semibold text-white mb-2 flex items-center gap-1">
                    <Globe className="w-3.5 h-3.5 text-[#4a90e2]" />
                    All Routes ({safeAnalysis.siteDiscovery.allRoutes.length})
                  </div>
                  <div className="space-y-1 max-h-[300px] overflow-y-auto">
                    {safeAnalysis.siteDiscovery.allRoutes.map((r, i) => (
                      <div key={i} className="flex items-center gap-2 text-[11px] bg-[#1a1d21] rounded px-2 py-1.5">
                        <span className={`w-2 h-2 rounded-full shrink-0 ${r.accessible ? 'bg-[#2ecc71]' : 'bg-[#e74c3c]'}`} />
                        <span className="text-white font-mono truncate flex-1">{r.path}</span>
                        <span className="text-[#6b7075] text-[10px]">{r.methods.join(',')}</span>
                        <span className="text-[#f39c12] text-[10px]">{r.count}x</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="text-[12px] font-semibold text-white mb-2 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-[#e74c3c]" />
                    Inaccessible Routes ({safeAnalysis.siteDiscovery.inaccessibleRoutes.length})
                  </div>
                  <div className="space-y-1 max-h-[300px] overflow-y-auto">
                    {safeAnalysis.siteDiscovery.inaccessibleRoutes.length === 0 ? (
                      <div className="text-[11px] text-[#2ecc71] py-4 text-center">All routes accessible ✓</div>
                    ) : (
                      safeAnalysis.siteDiscovery.inaccessibleRoutes.map((r, i) => (
                        <div key={i} className="flex items-center gap-2 text-[11px] bg-[#e74c3c]/10 rounded px-2 py-1.5">
                          <AlertTriangle className="w-3 h-3 text-[#e74c3c] shrink-0" />
                          <span className="text-white font-mono truncate flex-1">{r.path}</span>
                          <span className="text-[#e74c3c] text-[10px]">{r.statusCodes.join(',')}</span>
                          <span className="text-[#6b7075] text-[10px]">{r.count}x</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div>
                  <div className="text-[12px] font-semibold text-white mb-2 flex items-center gap-1">
                    <KeyRound className="w-3.5 h-3.5 text-[#9b59b6]" />
                    Input Fields ({safeAnalysis.siteDiscovery.allInputFields.length})
                  </div>
                  <div className="space-y-1 max-h-[300px] overflow-y-auto">
                    {safeAnalysis.siteDiscovery.allInputFields.length === 0 ? (
                      <div className="text-[11px] text-[#6b7075] py-4 text-center">No input fields captured yet</div>
                    ) : (
                      safeAnalysis.siteDiscovery.allInputFields.map((f, i) => (
                        <div key={i} className="flex items-center gap-2 text-[11px] bg-[#1a1d21] rounded px-2 py-1.5">
                          <KeyRound className="w-3 h-3 text-[#9b59b6] shrink-0" />
                          <span className="text-white font-mono truncate flex-1">{f.name}</span>
                          <span className="text-[#6b7075] text-[10px] truncate max-w-[120px]" title={f.paths.join(', ')}>{f.paths[0]}</span>
                          <span className="text-[#f39c12] text-[10px]">{f.count}x</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div>
                  <div className="text-[12px] font-semibold text-white mb-2 flex items-center gap-1">
                    <MousePointer className="w-3.5 h-3.5 text-[#2ecc71]" />
                    Buttons Clicked ({safeAnalysis.siteDiscovery.allButtons.length})
                  </div>
                  <div className="space-y-1 max-h-[300px] overflow-y-auto">
                    {safeAnalysis.siteDiscovery.allButtons.length === 0 ? (
                      <div className="text-[11px] text-[#6b7075] py-4 text-center">No button clicks tracked yet</div>
                    ) : (
                      safeAnalysis.siteDiscovery.allButtons.map((b, i) => (
                        <div key={i} className="flex items-center gap-2 text-[11px] bg-[#1a1d21] rounded px-2 py-1.5">
                          <MousePointer className="w-3 h-3 text-[#2ecc71] shrink-0" />
                          <span className="text-white truncate flex-1">{b.name}</span>
                          <span className="text-[#f39c12] text-[10px]">{b.count}x</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
      <div className={`text-[24px] font-bold ${color}`}>{value}</div>
      <div className="text-[11px] text-[#8e9296] uppercase">{label}</div>
    </div>
  )
}
