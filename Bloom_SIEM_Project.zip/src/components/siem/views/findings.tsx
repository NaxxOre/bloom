'use client'

import { useEffect, useState } from 'react'
import { Search, ShieldAlert } from 'lucide-react'

interface Finding {
  id: string
  title: string
  description: string
  severity: string
  status: string
  assetName: string | null
  detectedAt: string
}

const SEV_COLORS: Record<string, string> = {
  critical: 'text-[#e74c3c] bg-[#e74c3c]/10',
  high: 'text-[#f39c12] bg-[#f39c12]/10',
  medium: 'text-[#f4b733] bg-[#f4b733]/10',
  low: 'text-[#8e9296] bg-[#8e9296]/10',
}

const STATUS_COLORS: Record<string, string> = {
  open: 'text-[#e74c3c] bg-[#e74c3c]/10',
  remediated: 'text-[#2ecc71] bg-[#2ecc71]/10',
  accepted: 'text-[#f4b733] bg-[#f4b733]/10',
  false_positive: 'text-[#8e9296] bg-[#8e9296]/10',
}

export function FindingsView() {
  const [findings, setFindings] = useState<Finding[]>([])

  useEffect(() => {
    fetch('/api/findings').then((r) => r.json()).then((d) => setFindings(d.findings || []))
  }, [])

  return (
    <div className="p-5 space-y-4 max-w-[1400px] mx-auto">
      <div>
        <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
          <Search className="w-5 h-5 text-[#f39c12]" />
          Findings
        </h1>
        <p className="text-[12px] text-[#8e9296] mt-0.5">
          Continuous vulnerability assessment and security posture findings
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {['critical', 'high', 'medium', 'low'].map((s) => {
          const count = findings.filter((f) => f.severity === s).length
          return (
            <div key={s} className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
              <div className={`text-[10px] uppercase font-medium px-2 py-0.5 rounded inline-block ${SEV_COLORS[s]}`}>{s}</div>
              <div className="text-[28px] font-bold text-white mt-2">{count}</div>
            </div>
          )
        })}
      </div>

      <div className="space-y-2">
        {findings.map((f) => (
          <div key={f.id} className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <ShieldAlert className={`w-4 h-4 mt-0.5 ${SEV_COLORS[f.severity].split(' ')[0]}`} />
                <div className="flex-1 min-w-0">
                  <div className="text-[13px] font-medium text-white">{f.title}</div>
                  <div className="text-[11px] text-[#8e9296] mt-1">{f.description}</div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1.5 shrink-0">
                <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-medium ${SEV_COLORS[f.severity]}`}>
                  {f.severity}
                </span>
                <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-medium ${STATUS_COLORS[f.status]}`}>
                  {f.status.replace('_', ' ')}
                </span>
              </div>
            </div>
            <div className="flex items-center gap-4 text-[10px] text-[#6b7075] pt-2 border-t border-[#2a2d31]">
              {f.assetName && <span>Asset: <span className="text-[#b0b3b8] font-mono">{f.assetName}</span></span>}
              <span>Detected: {new Date(f.detectedAt).toLocaleString()}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
