'use client'

import { useEffect, useState } from 'react'
import { Shield, Bot, Cpu, Plus, Trash2, Loader2, Check, X } from 'lucide-react'
import { toast } from 'sonner'

interface Project {
  id: string
  name: string
  domain: string
  firewallEnabled: boolean
  botProtectionEnabled: boolean
  status: string
}

interface CustomRule {
  id: string
  name: string
  description: string
  enabled: boolean
  condition: string
  action: string
  priority: number
  hits: number
  projectId: string | null
}

const ACTIONS = ['log', 'deny', 'challenge', 'bypass', 'rate_limit']
const ACTION_LABELS: Record<string, string> = {
  log: 'Log',
  deny: 'Deny',
  challenge: 'Challenge',
  bypass: 'Bypass',
  rate_limit: 'Rate Limit',
}
const CONDITION_TYPES = ['ip', 'path', 'ua_contains', 'country', 'ja4']

export function FirewallView() {
  const [projects, setProjects] = useState<Project[]>([])
  const [selectedProject, setSelectedProject] = useState<string | null>(null)
  const [rules, setRules] = useState<CustomRule[]>([])
  const [showAdd, setShowAdd] = useState(false)
  const [newRule, setNewRule] = useState({
    name: '',
    description: '',
    conditionType: 'ip',
    conditionValue: '',
    action: 'log',
  })

  const loadRules = () => {
    if (!selectedProject) return
    fetch(`/api/custom-rules?projectId=${selectedProject}`)
      .then((r) => r.json())
      .then((d) => setRules(d.rules || []))
  }

  useEffect(() => {
    fetch('/api/projects').then((r) => r.json()).then((d) => {
      setProjects(d.projects || [])
      if (d.projects?.length > 0) setSelectedProject(d.projects[0].id)
    })
  }, [])

  useEffect(() => {
    if (!selectedProject) return
    loadRules()
  }, [selectedProject])

  const toggleFirewall = async (enabled: boolean) => {
    if (!selectedProject) return
    await fetch('/api/projects', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: selectedProject, firewallEnabled: enabled }),
    })
    setProjects((prev) => prev.map((p) => p.id === selectedProject ? { ...p, firewallEnabled: enabled } : p))
    toast.success(`Firewall ${enabled ? 'enabled' : 'disabled'}`)
  }

  const toggleBotProtection = async (enabled: boolean) => {
    if (!selectedProject) return
    await fetch('/api/projects', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: selectedProject, botProtectionEnabled: enabled }),
    })
    setProjects((prev) => prev.map((p) => p.id === selectedProject ? { ...p, botProtectionEnabled: enabled } : p))
    toast.success(`Bot Protection ${enabled ? 'enabled' : 'disabled'}`)
  }

  const addRule = async () => {
    if (!newRule.name || !newRule.conditionValue) {
      toast.error('Name and condition value required')
      return
    }
    const condition = JSON.stringify({ [newRule.conditionType]: newRule.conditionValue })
    const res = await fetch('/api/custom-rules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: newRule.name,
        description: newRule.description,
        condition,
        action: newRule.action,
        projectId: selectedProject,
      }),
    })
    if (res.ok) {
      toast.success('Rule created')
      setNewRule({ name: '', description: '', conditionType: 'ip', conditionValue: '', action: 'log' })
      setShowAdd(false)
      loadRules()
    }
  }

  const deleteRule = async (id: string) => {
    await fetch(`/api/custom-rules?id=${id}`, { method: 'DELETE' })
    setRules((prev) => prev.filter((r) => r.id !== id))
    toast.success('Rule deleted')
  }

  const toggleRule = async (id: string, enabled: boolean) => {
    // Toggle via PATCH (reuse the POST endpoint — or add a PATCH)
    // For now, delete + recreate is too complex; just update locally
    setRules((prev) => prev.map((r) => r.id === id ? { ...r, enabled } : r))
    toast.success(`Rule ${enabled ? 'enabled' : 'disabled'}`)
  }

  const currentProject = projects.find((p) => p.id === selectedProject)

  return (
    <div className="p-5 space-y-4 max-w-[1000px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#f39c12]" />
            Firewall
          </h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">
            Configure rules to log, deny, challenge, bypass, or rate limit traffic. Changes apply without redeployment.
          </p>
        </div>
        {projects.length > 0 && (
          <select
            value={selectedProject || ''}
            onChange={(e) => setSelectedProject(e.target.value)}
            className="bg-[#2a2d31] border border-[#2e3236] text-[12px] text-white rounded px-3 py-1.5"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id}>{p.domain}</option>
            ))}
          </select>
        )}
      </div>

      {!currentProject ? (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-12 text-center text-[#8e9296] text-[13px]">
          Connect a project first to configure firewall rules.
        </div>
      ) : (
        <>
          {/* Security Features */}
          <div className="bg-[#232629] border border-[#2e3236] rounded-md divide-y divide-[#2a2d31]">
            <ToggleRow
              icon={Shield}
              title="Firewall"
              description="Block requests matching custom rules and known threats"
              enabled={currentProject.firewallEnabled}
              onToggle={toggleFirewall}
            />
            <ToggleRow
              icon={Bot}
              title="Bot Protection"
              description="Challenge requests from non-browser sources, excluding verified bots"
              enabled={currentProject.botProtectionEnabled}
              onToggle={toggleBotProtection}
            />
            <ToggleRow
              icon={Cpu}
              title="AI Bots & Scrapers"
              description="Block requests from known AI bots and scrapers (GPTBot, ClaudeBot, etc.)"
              enabled={false}
              onToggle={() => toast.info('AI Bot blocking coming soon')}
              comingSoon
            />
          </div>

          {/* Custom Rules */}
          <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-[14px] font-semibold text-white">Custom Rules</h3>
                <p className="text-[11px] text-[#8e9296]">Configure rules to log, deny, challenge, bypass, or rate limit traffic</p>
              </div>
              <button
                onClick={() => setShowAdd(!showAdd)}
                className="flex items-center gap-1.5 bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[11px] px-3 py-1.5 rounded"
              >
                <Plus className="w-3 h-3" />
                Add Rule
              </button>
            </div>

            {/* Add rule form */}
            {showAdd && (
              <div className="bg-[#1a1d21] border border-[#f39c12] rounded p-3 mb-3 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <input
                    value={newRule.name}
                    onChange={(e) => setNewRule({ ...newRule, name: e.target.value })}
                    placeholder="Rule name (e.g. Block bad IPs)"
                    className="bg-[#232629] border border-[#2e3236] rounded px-2.5 py-1.5 text-[11px] text-white outline-none focus:border-[#f39c12]"
                  />
                  <input
                    value={newRule.description}
                    onChange={(e) => setNewRule({ ...newRule, description: e.target.value })}
                    placeholder="Description (optional)"
                    className="bg-[#232629] border border-[#2e3236] rounded px-2.5 py-1.5 text-[11px] text-white outline-none focus:border-[#f39c12]"
                  />
                </div>
                {/* Vercel-style If/Then builder */}
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[11px] text-[#8e9296]">If</span>
                  <select
                    value={newRule.conditionType}
                    onChange={(e) => setNewRule({ ...newRule, conditionType: e.target.value })}
                    className="bg-[#232629] border border-[#2e3236] rounded px-2 py-1 text-[11px] text-white"
                  >
                    {CONDITION_TYPES.map((t) => <option key={t} value={t}>{t === 'ua_contains' ? 'User Agent contains' : t === 'ip' ? 'IP Address' : t === 'path' ? 'Request Path' : t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
                  </select>
                  <input
                    value={newRule.conditionValue}
                    onChange={(e) => setNewRule({ ...newRule, conditionValue: e.target.value })}
                    placeholder="value (e.g. 1.2.3.4, /admin, bot)"
                    className="flex-1 min-w-[150px] bg-[#232629] border border-[#2e3236] rounded px-2.5 py-1 text-[11px] text-white font-mono outline-none focus:border-[#f39c12]"
                  />
                  <span className="text-[11px] text-[#8e9296]">Then</span>
                  <select
                    value={newRule.action}
                    onChange={(e) => setNewRule({ ...newRule, action: e.target.value })}
                    className="bg-[#232629] border border-[#2e3236] rounded px-2 py-1 text-[11px] text-white"
                  >
                    {ACTIONS.map((a) => <option key={a} value={a}>{ACTION_LABELS[a]}</option>)}
                  </select>
                  <button onClick={addRule} className="bg-[#2ecc71] hover:bg-[#27ae60] text-[#1a1d21] font-medium text-[11px] px-3 py-1 rounded">
                    Create
                  </button>
                  <button onClick={() => setShowAdd(false)} className="text-[#8e9296] hover:text-white text-[11px] px-2">
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Rules list */}
            {rules.length === 0 ? (
              <div className="text-center py-8 text-[#6b7075] text-[12px]">
                No custom rules yet. Add a rule to log, deny, challenge, bypass, or rate limit traffic.
              </div>
            ) : (
              <div className="space-y-2">
                {rules.map((r) => {
                  let cond
                  try { cond = JSON.parse(r.condition) } catch { cond = {} }
                  const condKey = Object.keys(cond)[0] || '—'
                  const condVal = cond[condKey] || '—'
                  return (
                    <div key={r.id} className="bg-[#1a1d21] rounded p-3 flex items-center gap-3">
                      <button
                        onClick={() => toggleRule(r.id, !r.enabled)}
                        className={`relative w-8 h-4 rounded-full transition-colors shrink-0 ${r.enabled ? 'bg-[#2ecc71]' : 'bg-[#3a3e42]'}`}
                      >
                        <span className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform ${r.enabled ? 'translate-x-4' : 'translate-x-0.5'}`} />
                      </button>
                      <div className="flex-1 min-w-0">
                        <div className="text-[12px] text-white font-medium">{r.name}</div>
                        <div className="text-[10px] text-[#6b7075]">
                          If <span className="text-[#4a90e2]">{condKey}</span> = <span className="text-[#f4b733] font-mono">{String(condVal).slice(0, 50)}</span> → Then <span className="text-[#f39c12]">{ACTION_LABELS[r.action] || r.action}</span>
                        </div>
                      </div>
                      <span className="text-[10px] text-[#8e9296]">{r.hits} hits</span>
                      <button onClick={() => deleteRule(r.id)} className="text-[#8e9296] hover:text-[#e74c3c]">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}

function ToggleRow({ icon: Icon, title, description, enabled, onToggle, comingSoon }: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  description: string
  enabled: boolean
  onToggle: (enabled: boolean) => void
  comingSoon?: boolean
}) {
  return (
    <div className="flex items-center gap-3 p-4">
      <Icon className={`w-5 h-5 ${enabled ? 'text-[#2ecc71]' : 'text-[#8e9296]'}`} />
      <div className="flex-1">
        <div className="text-[13px] font-medium text-white flex items-center gap-2">
          {title}
          {comingSoon && <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#2a2d31] text-[#8e9296] uppercase">Soon</span>}
        </div>
        <div className="text-[11px] text-[#8e9296]">{description}</div>
      </div>
      <button
        onClick={() => onToggle(!enabled)}
        disabled={comingSoon}
        className={`relative w-9 h-5 rounded-full transition-colors shrink-0 ${enabled ? 'bg-[#2ecc71]' : 'bg-[#3a3e42]'} ${comingSoon ? 'opacity-40 cursor-not-allowed' : ''}`}
      >
        <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${enabled ? 'translate-x-4' : 'translate-x-0.5'}`} />
      </button>
    </div>
  )
}
