'use client'

import { useEffect, useState } from 'react'
import { Network, Search, Shield, Server, Cloud, Container } from 'lucide-react'

interface Asset {
  id: string
  name: string
  type: string
  ipAddress: string | null
  os: string | null
  location: string | null
  criticality: string
  owner: string | null
  lastSeen: string
}

const TYPE_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  server: Server,
  endpoint: Shield,
  container: Container,
  cloud: Cloud,
  network_device: Network,
}

const CRIT_COLORS: Record<string, string> = {
  critical: 'text-[#e74c3c] bg-[#e74c3c]/10',
  high: 'text-[#f39c12] bg-[#f39c12]/10',
  medium: 'text-[#f4b733] bg-[#f4b733]/10',
  low: 'text-[#8e9296] bg-[#8e9296]/10',
}

export function AssetsView() {
  const [assets, setAssets] = useState<Asset[]>([])
  const [q, setQ] = useState('')

  useEffect(() => {
    fetch('/api/assets').then((r) => r.json()).then((d) => setAssets(d.assets || []))
  }, [])

  const filtered = assets.filter((a) =>
    a.name.toLowerCase().includes(q.toLowerCase()) ||
    a.ipAddress?.includes(q) ||
    a.owner?.toLowerCase().includes(q.toLowerCase())
  )

  return (
    <div className="p-5 space-y-4 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
            <Network className="w-5 h-5 text-[#f39c12]" />
            Assets & Identities
          </h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">{assets.length} assets under management</p>
        </div>
        <div className="flex items-center gap-2 bg-[#2a2d31] rounded px-3 py-1.5 w-72">
          <Search className="w-3.5 h-3.5 text-[#8e9296]" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Filter by name, IP, owner..."
            className="bg-transparent text-[12px] text-white outline-none flex-1 placeholder:text-[#6b7075]"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {['server', 'endpoint', 'container', 'cloud', 'network_device'].map((t) => {
          const count = assets.filter((a) => a.type === t).length
          const Icon = TYPE_ICONS[t] || Server
          return (
            <div key={t} className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
              <div className="flex items-center gap-2 mb-1">
                <Icon className="w-3.5 h-3.5 text-[#f39c12]" />
                <span className="text-[11px] text-[#8e9296] uppercase capitalize">{t.replace('_', ' ')}</span>
              </div>
              <div className="text-[24px] font-bold text-white">{count}</div>
            </div>
          )
        })}
      </div>

      <div className="bg-[#232629] border border-[#2e3236] rounded-md overflow-hidden">
        <div className="grid grid-cols-[2fr_1.2fr_1fr_1.5fr_1fr_1fr] gap-3 px-4 py-2 text-[10px] uppercase text-[#6b7075] border-b border-[#2e3236] font-medium">
          <span>Hostname</span>
          <span>Type</span>
          <span>IP Address</span>
          <span>OS</span>
          <span>Criticality</span>
          <span>Last Seen</span>
        </div>
        <div className="max-h-[600px] overflow-y-auto">
          {filtered.map((a) => {
            const Icon = TYPE_ICONS[a.type] || Server
            return (
              <div
                key={a.id}
                className="grid grid-cols-[2fr_1.2fr_1fr_1.5fr_1fr_1fr] gap-3 px-4 py-2.5 text-[12px] border-b border-[#2a2d31] hover:bg-[#2a2d31] items-center"
              >
                <span className="flex items-center gap-2 text-white">
                  <Icon className="w-3.5 h-3.5 text-[#8e9296]" />
                  {a.name}
                </span>
                <span className="text-[#b0b3b8] capitalize">{a.type.replace('_', ' ')}</span>
                <span className="text-[#b0b3b8] font-mono">{a.ipAddress || '—'}</span>
                <span className="text-[#b0b3b8] truncate">{a.os || '—'}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-medium inline-block w-fit ${CRIT_COLORS[a.criticality]}`}>
                  {a.criticality}
                </span>
                <span className="text-[#6b7075]">
                  {new Date(a.lastSeen).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
