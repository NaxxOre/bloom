'use client'

import { useEffect, useState } from 'react'
import { Crosshair, Bug, ShieldOff, KeyRound, Wrench, AlertTriangle } from 'lucide-react'

interface Exposure {
  id: string
  title: string
  description: string
  severity: string
  category: string
  assetName: string | null
  cveId: string | null
  cvssScore: number | null
  status: string
  discoveredAt: string
}

const CATEGORY_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  cve: Bug,
  misconfiguration: ShieldOff,
  open_port: Crosshair,
  weak_credential: KeyRound,
  missing_patch: Wrench,
}

const SEV_COLORS: Record<string, string> = {
  critical: 'text-[#e74c3c] bg-[#e74c3c]/10',
  high: 'text-[#f39c12] bg-[#f39c12]/10',
  medium: 'text-[#f4b733] bg-[#f4b733]/10',
  low: 'text-[#8e9296] bg-[#8e9296]/10',
}

const STATUS_COLORS: Record<string, string> = {
  open: 'text-[#e74c3c] bg-[#e74c3c]/10',
  mitigated: 'text-[#2ecc71] bg-[#2ecc71]/10',
  accepted: 'text-[#f4b733] bg-[#f4b733]/10',
  false_positive: 'text-[#8e9296] bg-[#8e9296]/10',
}

export function ExposureView() {
  const [exposures, setExposures] = useState<Exposure[]>([])
  const [categoryFilter, setCategoryFilter] = useState<'all' | string>('all')

  useEffect(() => {
    fetch('/api/exposures')
      .then((r) => r.text())
      .then((text) => { try { return JSON.parse(text) } catch { return { exposures: [] } } })
      .then((d) => setExposures(d.exposures || []))
      .catch(() => {})
  }, [])

  const categories = Array.from(new Set(exposures.map((e) => e.category)))
  const filtered = categoryFilter === 'all' ? exposures : exposures.filter((e) => e.category === categoryFilter)

  const stats = {
    total: exposures.length,
    critical: exposures.filter((e) => e.severity === 'critical').length,
    open: exposures.filter((e) => e.status === 'open').length,
    mitigated: exposures.filter((e) => e.status === 'mitigated').length,
    avgCvss: exposures.length
      ? (exposures.reduce((sum, e) => sum + (e.cvssScore || 0), 0) / exposures.length).toFixed(1)
      : '0.0',
  }

  return (
    <div className="p-5 space-y-4 max-w-[1600px] mx-auto">
      <div>
        <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
          <Crosshair className="w-5 h-5 text-[#f39c12]" />
          Exposure Management
        </h1>
        <p className="text-[12px] text-[#8e9296] mt-0.5">
          CVEs, misconfigurations, and security exposures across your attack surface
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { label: 'Total Exposures', value: stats.total, color: 'text-[#4a90e2]' },
          { label: 'Critical', value: stats.critical, color: 'text-[#e74c3c]' },
          { label: 'Open', value: stats.open, color: 'text-[#f39c12]' },
          { label: 'Mitigated', value: stats.mitigated, color: 'text-[#2ecc71]' },
          { label: 'Avg CVSS', value: stats.avgCvss, color: 'text-[#9b59b6]' },
        ].map((s) => (
          <div key={s.label} className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
            <div className={`text-[24px] font-bold ${s.color}`}>{s.value}</div>
            <div className="text-[11px] text-[#8e9296] uppercase tracking-wide">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => setCategoryFilter('all')}
          className={`text-[12px] px-3 py-1.5 rounded ${categoryFilter === 'all' ? 'bg-[#f39c12] text-[#1a1d21] font-medium' : 'bg-[#2a2d31] text-[#8e9296] hover:text-white'}`}
        >
          All Categories
        </button>
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setCategoryFilter(c)}
            className={`text-[12px] px-3 py-1.5 rounded capitalize ${categoryFilter === c ? 'bg-[#f39c12] text-[#1a1d21] font-medium' : 'bg-[#2a2d31] text-[#8e9296] hover:text-white'}`}
          >
            {c.replace('_', ' ')}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        {filtered.map((e) => {
          const Icon = CATEGORY_ICONS[e.category] || AlertTriangle
          return (
            <div key={e.id} className="bg-[#232629] border border-[#2e3236] rounded-md p-4">
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <Icon className="w-4 h-4 mt-0.5 text-[#f39c12] shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="text-[13px] font-medium text-white">{e.title}</span>
                      {e.cveId && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#2a2d31] text-[#4a90e2] font-mono">{e.cveId}</span>
                      )}
                      {e.cvssScore !== null && (
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                          e.cvssScore >= 9 ? 'text-[#e74c3c] bg-[#e74c3c]/10' :
                          e.cvssScore >= 7 ? 'text-[#f39c12] bg-[#f39c12]/10' :
                          e.cvssScore >= 4 ? 'text-[#f4b733] bg-[#f4b733]/10' : 'text-[#8e9296] bg-[#8e9296]/10'
                        }`}>
                          CVSS {e.cvssScore}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-[#8e9296]">{e.description}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-medium ${SEV_COLORS[e.severity]}`}>
                    {e.severity}
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-medium ${STATUS_COLORS[e.status]}`}>
                    {e.status.replace('_', ' ')}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-3 text-[10px] text-[#6b7075] pt-2 border-t border-[#2a2d31]">
                <span className="capitalize">{e.category.replace('_', ' ')}</span>
                {e.assetName && (
                  <>
                    <span>·</span>
                    <span className="font-mono">{e.assetName}</span>
                  </>
                )}
                <span className="ml-auto">
                  Discovered {new Date(e.discoveredAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
