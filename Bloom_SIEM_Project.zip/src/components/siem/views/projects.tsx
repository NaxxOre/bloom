'use client'

import { useEffect, useState } from 'react'
import {
  LayoutDashboard, Plus, Trash2, Loader2, Copy, Check,
  ShieldCheck, ShieldOff, Bot, FileCode2,
  Wifi, AlertCircle, CheckCircle2, Search,
} from 'lucide-react'
import { toast } from 'sonner'

interface Project {
  id: string; name: string; domain: string; apiKey: string; projectId: string
  status: string; firewallEnabled: boolean; botProtectionEnabled: boolean
  lastEventAt: string | null; createdAt: string
}

type Platform = 'nextjs' | 'html' | 'php' | 'express'

const PLATFORMS: { id: Platform; label: string; desc: string }[] = [
  { id: 'nextjs', label: 'Next.js', desc: 'Vercel / Next.js middleware' },
  { id: 'html', label: 'HTML / JS', desc: 'Any website with a script tag' },
  { id: 'php', label: 'PHP', desc: 'WordPress / Laravel / raw PHP' },
  { id: 'express', label: 'Express', desc: 'Node.js / Express server' },
]

export function ProjectsView() {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [newProject, setNewProject] = useState({ name: '', domain: '' })
  const [copied, setCopied] = useState<string | null>(null)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [scanning, setScanning] = useState<string | null>(null)
  const [testing, setTesting] = useState<string | null>(null)
  const [testResult, setTestResult] = useState<Record<string, { success: boolean; message: string }>>({})
  const [platform, setPlatform] = useState<Platform>('nextjs')

  useEffect(() => {
    let cancelled = false
    fetch('/api/projects').then((r) => r.json()).then((d) => {
      if (cancelled) return
      const list = d.projects || []
      setProjects(list)
      if (list.length > 0 && !expanded) setExpanded(list[0].id)
    }).finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [])

  const addProject = async () => {
    if (!newProject.name || !newProject.domain) { toast.error('Name and domain required'); return }
    const res = await fetch('/api/projects', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newProject),
    })
    if (res.ok) {
      const d = await res.json()
      toast.success(`Project created for ${newProject.domain}`)
      setNewProject({ name: '', domain: '' }); setShowAdd(false); setExpanded(d.project.id)
      fetch('/api/projects').then((r) => r.json()).then((d) => setProjects(d.projects || []))
    } else {
      const d = await res.json().catch(() => ({})); toast.error(d.error || 'Failed')
    }
  }

  const toggleFirewall = async (id: string, enabled: boolean) => {
    await fetch('/api/projects', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, firewallEnabled: enabled }) })
    setProjects((prev) => prev.map((p) => p.id === id ? { ...p, firewallEnabled: enabled } : p))
  }

  const toggleBotProtection = async (id: string, enabled: boolean) => {
    await fetch('/api/projects', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, botProtectionEnabled: enabled }) })
    setProjects((prev) => prev.map((p) => p.id === id ? { ...p, botProtectionEnabled: enabled } : p))
  }

  const deleteProject = async (id: string) => {
    if (!confirm('Delete this project? All traffic logs will be lost.')) return
    await fetch(`/api/projects?id=${id}`, { method: 'DELETE' })
    setProjects((prev) => prev.filter((p) => p.id !== id)); toast.success('Project deleted')
  }

  const copy = (text: string, id: string) => { navigator.clipboard.writeText(text); setCopied(id); setTimeout(() => setCopied(null), 1500); toast.success('Copied') }

  const scanSite = async (p: Project) => {
    setScanning(p.id)
    try {
      const res = await fetch('/api/scan-site', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ projectId: p.id }) })
      const d = await res.json()
      if (d.success) toast.success(`Site scanned: ${d.scan.routesFound} routes, ${d.scan.formsFound} forms, ${d.scan.buttonsFound} buttons`)
      else toast.error('Scan failed')
    } catch { toast.error('Scan failed') } finally { setScanning(null) }
  }

  const testConnection = async (p: Project) => {
    setTesting(p.id)
    setTestResult((prev) => { const n = { ...prev }; delete n[p.id]; return n })
    try {
      const res = await fetch('/api/sdk/ingest', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Bloom-Project': p.projectId, 'X-Bloom-Key': p.apiKey },
        body: JSON.stringify({ method: 'GET', path: '/bloom-test-connection', host: p.domain, ip: '127.0.0.1', userAgent: 'Bloom-Test/1.0', statusCode: 200, responseTime: 0 }),
      })
      const d = await res.json()
      if (d.success) { setTestResult((prev) => ({ ...prev, [p.id]: { success: true, message: `Connected! Test event stored. ${d.stored} event(s) ingested.` } })); toast.success('Connection test passed') }
      else { setTestResult((prev) => ({ ...prev, [p.id]: { success: false, message: d.error || 'Unknown error' } })); toast.error('Connection test failed') }
    } catch (err) { setTestResult((prev) => ({ ...prev, [p.id]: { success: false, message: err instanceof Error ? err.message : 'Network error' } })) } finally { setTesting(null) }
  }

  const getSnippets = (p: Project) => {
    const bloomUrl = typeof window !== 'undefined' ? window.location.origin : 'https://your-bloom-instance.com'
    const envContent = `BLOOM_PROJECT_ID=${p.projectId}\nBLOOM_API_KEY=${p.apiKey}\nBLOOM_INGEST_URL=${bloomUrl}`

    const nextjsCode = `// middleware.ts — Zero-dependency, Vercel Edge compatible
export default async function middleware(req: Request) {
  const url = new URL(req.url);
  const ingestUrl = process.env.BLOOM_INGEST_URL || '${bloomUrl}';
  const projectId = process.env.BLOOM_PROJECT_ID || '';
  const apiKey = process.env.BLOOM_API_KEY || '';
  const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || '';
  const userAgent = req.headers.get('user-agent') || '';

  // STEP 1: Check if Bloom should block this request
  try {
    const evalRes = await fetch(ingestUrl + '/api/sdk/evaluate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bloom-Project': projectId, 'X-Bloom-Key': apiKey },
      body: JSON.stringify({ ip: clientIp, path: url.pathname, userAgent }),
      signal: AbortSignal.timeout(800),
    });
    const decision = await evalRes.json();
    if (decision.action === 'BLOCK') {
      return new Response(JSON.stringify({ error: 'Access Denied by Bloom', rule: decision.rule }), { status: 403, headers: { 'Content-Type': 'application/json' } });
    }
  } catch {}

  // STEP 2: Log the request
  try {
    fetch(ingestUrl + '/api/sdk/ingest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bloom-Project': projectId, 'X-Bloom-Key': apiKey },
      body: JSON.stringify({ method: req.method, path: url.pathname, host: url.host, ip: clientIp, userAgent, statusCode: 200, responseTime: 0 }),
    }).catch(() => {});
  } catch {}

  return new Response(null, { headers: { 'x-middleware-next': '1' } });
}
export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico|assets).*)'] };`

    const htmlCode = `<!-- Add this before </body> on every page -->
<script>
(function() {
  var BLOOM_URL = '${bloomUrl}/api/sdk/ingest';
  var BLOOM_PROJECT = '${p.projectId}';
  var BLOOM_KEY = '${p.apiKey}';
  function track(payload) {
    payload.path = window.location.pathname;
    payload.host = window.location.hostname;
    payload.method = 'GET';
    payload.userAgent = navigator.userAgent;
    try { fetch(BLOOM_URL, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Bloom-Project': BLOOM_PROJECT, 'X-Bloom-Key': BLOOM_KEY }, body: JSON.stringify(payload) }).catch(function(){}); } catch(e) {}
  }
  track({ statusCode: 200, responseTime: 0 });
  document.addEventListener('submit', function(e) {
    var form = e.target; var inputs = form.querySelectorAll('input, textarea, select');
    var values = {};
    inputs.forEach(function(inp) { if (inp.name && inp.type !== 'password') values[inp.name] = inp.value.slice(0, 200); });
    track({ method: 'POST', path: form.action || window.location.pathname, statusCode: 200, responseTime: 0, inputSnippet: JSON.stringify(values) });
  }, true);
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('button, a');
    if (btn && btn.textContent) track({ method: 'CLICK', path: window.location.pathname, statusCode: 200, responseTime: 0, inputSnippet: 'click:' + btn.textContent.trim().slice(0, 50) });
  }, true);
})();
</script>`

    const phpCode = `<?php
$BLOOM_URL = '${bloomUrl}/api/sdk/ingest';
$BLOOM_PROJECT = '${p.projectId}';
$BLOOM_KEY = '${p.apiKey}';
$payload = array('method' => $_SERVER['REQUEST_METHOD'], 'path' => parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), 'host' => $_SERVER['HTTP_HOST'] ?? '', 'ip' => $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '', 'userAgent' => $_SERVER['HTTP_USER_AGENT'] ?? '', 'statusCode' => 200);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST)) $payload['inputSnippet'] = json_encode($_POST);
$ch = curl_init($BLOOM_URL);
curl_setopt_array($ch, array(CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($payload), CURLOPT_HTTPHEADER => array('Content-Type: application/json', 'X-Bloom-Project: ' . $BLOOM_PROJECT, 'X-Bloom-Key: ' . $BLOOM_KEY), CURLOPT_TIMEOUT_MS => 2000, CURLOPT_NOSIGNAL => 1, CURLOPT_RETURNTRANSFER => true));
curl_exec($ch); curl_close($ch);
?>`

    const expressCode = `// Express middleware — real-time blocking
const express = require('express');
const app = express();
app.use(express.json());
app.use(async (req, res, next) => {
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || '';
  try {
    const evalRes = await fetch(process.env.BLOOM_INGEST_URL + '/api/sdk/evaluate', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Bloom-Project': process.env.BLOOM_PROJECT_ID, 'X-Bloom-Key': process.env.BLOOM_API_KEY },
      body: JSON.stringify({ ip: clientIp, path: req.path, userAgent: req.headers['user-agent'] || '' }),
      signal: AbortSignal.timeout(800),
    });
    const decision = await evalRes.json();
    if (decision.action === 'BLOCK') return res.status(403).json({ error: 'Access Denied by Bloom', rule: decision.rule });
  } catch {}
  try { fetch(process.env.BLOOM_INGEST_URL + '/api/sdk/ingest', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Bloom-Project': process.env.BLOOM_PROJECT_ID, 'X-Bloom-Key': process.env.BLOOM_API_KEY }, body: JSON.stringify({ method: req.method, path: req.path, host: req.hostname, ip: clientIp, userAgent: req.headers['user-agent'] || '', statusCode: 200, responseTime: 0 }) }).catch(() => {}); } catch {}
  next();
});
app.listen(3000);`

    return { envContent, nextjsCode, htmlCode, phpCode, expressCode }
  }

  const currentSnippet = (p: Project) => {
    const s = getSnippets(p)
    switch (platform) { case 'html': return s.htmlCode; case 'php': return s.phpCode; case 'express': return s.expressCode; default: return s.nextjsCode }
  }

  return (
    <div className="p-5 space-y-4 max-w-[900px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2"><LayoutDashboard className="w-5 h-5 text-[#f39c12]" />Projects</h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">Connect any website to Bloom — Next.js, HTML, PHP, Express.</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[12px] px-4 py-2 rounded"><Plus className="w-3.5 h-3.5" />Add Project</button>
      </div>

      {showAdd && (
        <div className="bg-[#232629] border border-[#f39c12] rounded-md p-5 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input value={newProject.name} onChange={(e) => setNewProject({ ...newProject, name: e.target.value })} placeholder="Project name" className="bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white outline-none focus:border-[#f39c12]" />
            <input value={newProject.domain} onChange={(e) => setNewProject({ ...newProject, domain: e.target.value })} placeholder="example.com" className="bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white font-mono outline-none focus:border-[#f39c12]" />
          </div>
          <div className="flex gap-2">
            <button onClick={addProject} className="bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] text-[12px] font-medium px-4 py-1.5 rounded">Generate Keys</button>
            <button onClick={() => setShowAdd(false)} className="bg-[#2a2d31] hover:bg-[#3a3e42] text-white text-[12px] px-4 py-1.5 rounded">Cancel</button>
          </div>
        </div>
      )}

      {loading && <div className="text-center py-12 text-[#8e9296]"><Loader2 className="w-6 h-6 mx-auto mb-2 animate-spin" /></div>}

      {!loading && projects.length === 0 && (
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-12 text-center">
          <LayoutDashboard className="w-10 h-10 mx-auto mb-3 text-[#6b7075]" />
          <div className="text-[14px] text-white font-medium mb-1">No projects yet</div>
          <p className="text-[12px] text-[#8e9296]">Click "Add Project" to connect your first site.</p>
        </div>
      )}

      {projects.map((p) => {
        const isExpanded = expanded === p.id
        const snippets = getSnippets(p)
        const result = testResult[p.id]
        return (
          <div key={p.id} className="bg-[#232629] border border-[#2e3236] rounded-md overflow-hidden">
            <div className="p-4 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className={`w-10 h-10 rounded flex items-center justify-center shrink-0 ${p.status === 'connected' ? 'bg-[#2ecc71]/10' : 'bg-[#f4b733]/10'}`}>
                  {p.firewallEnabled ? <ShieldCheck className="w-5 h-5 text-[#2ecc71]" /> : <ShieldOff className="w-5 h-5 text-[#8e9296]" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="text-[14px] font-semibold text-white">{p.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${p.status === 'connected' ? 'bg-[#2ecc71]/20 text-[#2ecc71]' : p.status === 'pending' ? 'bg-[#f4b733]/20 text-[#f4b733]' : 'bg-[#2a2d31] text-[#8e9296]'}`}>{p.status}</span>
                  </div>
                  <div className="text-[12px] text-[#8e9296] font-mono">{p.domain}</div>
                  {p.lastEventAt && <div className="text-[10px] text-[#6b7075] mt-1">Last event: {new Date(p.lastEventAt).toLocaleString()}</div>}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button onClick={() => scanSite(p)} disabled={scanning === p.id} className="text-[11px] text-[#9b59b6] hover:underline flex items-center gap-1 px-2 disabled:opacity-50">
                  {scanning === p.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}Scan
                </button>
                <button onClick={() => testConnection(p)} disabled={testing === p.id} className="text-[11px] text-[#4a90e2] hover:underline flex items-center gap-1 px-2 disabled:opacity-50">
                  {testing === p.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Wifi className="w-3 h-3" />}Test
                </button>
                <button onClick={() => setExpanded(isExpanded ? null : p.id)} className="text-[11px] text-[#f39c12] hover:underline px-2">{isExpanded ? 'Hide setup' : 'Show setup'}</button>
                <button onClick={() => deleteProject(p.id)} className="text-[#8e9296] hover:text-[#e74c3c]"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>

            {result && (
              <div className={`mx-4 mb-3 rounded p-2.5 text-[11px] border flex items-start gap-2 ${result.success ? 'bg-[#2ecc71]/10 border-[#2ecc71]/30 text-[#2ecc71]' : 'bg-[#e74c3c]/10 border-[#e74c3c]/30 text-[#e74c3c]'}`}>
                {result.success ? <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />}
                <span>{result.message}</span>
              </div>
            )}

            <div className="flex items-center gap-4 px-4 py-2 border-t border-[#2a2d31] text-[11px]">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={p.firewallEnabled} onChange={(e) => toggleFirewall(p.id, e.target.checked)} className="w-3.5 h-3.5 accent-[#f39c12]" />
                <span className={p.firewallEnabled ? 'text-[#2ecc71]' : 'text-[#8e9296]'}>Firewall {p.firewallEnabled ? 'active' : 'inactive'}</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={p.botProtectionEnabled} onChange={(e) => toggleBotProtection(p.id, e.target.checked)} className="w-3.5 h-3.5 accent-[#f39c12]" />
                <span className={p.botProtectionEnabled ? 'text-[#2ecc71]' : 'text-[#8e9296]'}><Bot className="w-3 h-3 inline mr-1" />Bot Protection {p.botProtectionEnabled ? 'active' : 'inactive'}</span>
              </label>
            </div>

            {isExpanded && (
              <div className="border-t border-[#2e3236] p-4 space-y-4 bg-[#1a1d21]">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[11px] text-[#8e9296] uppercase font-medium flex items-center gap-1"><span className="text-[#f39c12]">1.</span> Environment Variables</div>
                  <button onClick={() => copy(snippets.envContent, 'env')} className="text-[10px] text-[#f39c12] hover:underline flex items-center gap-1">
                    {copied === 'env' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}{copied === 'env' ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre className="bg-[#232629] border border-[#2e3236] rounded p-2.5 text-[11px] font-mono overflow-x-auto">BLOOM_PROJECT_ID=<span className="text-[#4a90e2]">{p.projectId}</span>\nBLOOM_API_KEY=<span className="text-[#f39c12]">{p.apiKey}</span>\nBLOOM_INGEST_URL=<span className="text-[#2ecc71]">{typeof window !== 'undefined' ? window.location.origin : 'https://your-bloom-instance.com'}</span></pre>

                <div className="flex gap-1 mb-2 flex-wrap">
                  {PLATFORMS.map((plt) => (
                    <button key={plt.id} onClick={() => setPlatform(plt.id)} className={`text-[11px] px-3 py-1.5 rounded transition-colors ${platform === plt.id ? 'bg-[#f39c12] text-[#1a1d21] font-medium' : 'bg-[#2a2d31] text-[#8e9296] hover:text-white'}`}>{plt.label}</button>
                  ))}
                </div>
                <div className="relative">
                  <button onClick={() => copy(currentSnippet(p), `code-${platform}`)} className="absolute top-2 right-2 text-[10px] text-[#f39c12] hover:underline flex items-center gap-1 bg-[#1a1d21] px-2 py-1 rounded z-10">
                    {copied === `code-${platform}` ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}{copied === `code-${platform}` ? 'Copied' : 'Copy'}
                  </button>
                  <pre className="bg-[#232629] border border-[#2e3236] rounded p-2.5 text-[11px] font-mono text-[#b0b3b8] overflow-x-auto leading-relaxed max-h-[300px] overflow-y-auto">{currentSnippet(p)}</pre>
                </div>

                <div className="bg-[#2ecc71]/10 border border-[#2ecc71]/30 rounded p-2.5 text-[11px] text-[#2ecc71] flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 shrink-0" />Deploy your site — traffic will appear in the Traffic Overview within seconds.
                </div>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
