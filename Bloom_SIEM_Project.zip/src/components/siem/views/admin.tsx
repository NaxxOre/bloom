'use client'

import { useEffect, useState } from 'react'
import {
  Settings, Database, Cpu, HardDrive, Activity, Server,
  Clock, Globe, Brain, Ban, Plug, ShieldAlert, FileText, Box,
} from 'lucide-react'

interface SystemStats {
  database: {
    engine: string
    filePath: string
    fileSizeBytes: number
    fileSizeHuman: string
    totalRecords: number
    tables: { name: string; count: number; model: string }[]
  }
  process: {
    pid: number
    platform: string
    nodeVersion: string
    uptimeSec: number
    uptimeHuman: string
    startedAt: string
    memory: {
      rssHuman: string
      heapUsedHuman: string
      heapTotalHuman: string
      externalHuman: string
    }
    cpu: {
      userMs: string
      systemMs: string
    }
  }
  system: {
    hostname: string
    osType: string
    osRelease: string
    arch: string
    cpuCount: number
    cpuModel: string
    cpuSpeedMhz: number
    loadAvg1: string
    loadAvg5: string
    loadAvg15: string
    memory: {
      totalHuman: string
      freeHuman: string
      usedHuman: string
      usedPct: string
    }
  }
  bloom: {
    version: string
    build: string
    license: string
    repository: string
  }
}

const TABLE_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Agent: Server,
  Log: FileText,
  Alert: ShieldAlert,
  Investigation: Activity,
  AutoAction: Ban,
  AutoActionRule: Settings,
  AIProvider: Brain,
  Domain: Globe,
  LogSource: Plug,
  MonitoredTarget: Globe,
  AnalystVerdict: Brain,
  ComplianceControl: ShieldAlert,
  IntelligenceConfig: Settings,
}

export function AdminView() {
  const [stats, setStats] = useState<SystemStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let interval: NodeJS.Timeout
    const load = () => {
      fetch('/api/system-stats')
        .then((r) => r.json())
        .then(setStats)
        .finally(() => setLoading(false))
    }
    load()
    // Refresh every 10 seconds for live stats
    interval = setInterval(load, 10000)
    return () => clearInterval(interval)
  }, [])

  if (loading || !stats) {
    return (
      <div className="p-5 text-[#8e9296] text-sm flex items-center gap-2">
        <Activity className="w-4 h-4 animate-pulse" />
        Loading real system stats…
      </div>
    )
  }

  return (
    <div className="p-5 space-y-4 max-w-[1400px] mx-auto">
      <div>
        <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#f39c12]" />
          Administration
        </h1>
        <p className="text-[12px] text-[#8e9296] mt-0.5">
          Real system stats — live from this server. No mock data.
        </p>
      </div>

      {/* Live indicator */}
      <div className="flex items-center gap-2 text-[11px] text-[#2ecc71]">
        <span className="relative w-2 h-2">
          <span className="absolute inset-0 rounded-full bg-[#2ecc71] bloom-pulse" />
        </span>
        <span>Auto-refreshing every 10s · uptime {stats.process.uptimeHuman}</span>
      </div>

      {/* Process + System Health (REAL data) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Process stats */}
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-[#f39c12]" />
            <h3 className="text-[14px] font-semibold text-white">Bloom SIEM Process</h3>
            <span className="text-[10px] text-[#6b7075] ml-auto">PID {stats.process.pid}</span>
          </div>
          <div className="space-y-2">
            <Row label="Node.js Version" value={stats.process.nodeVersion} />
            <Row label="Platform" value={`${stats.process.platform} (${stats.system.arch})`} />
            <Row label="Uptime" value={stats.process.uptimeHuman} highlight />
            <Row label="Started At" value={new Date(stats.process.startedAt).toLocaleString()} />
            <Row label="Memory (RSS)" value={stats.process.memory.rssHuman} />
            <Row label="Heap Used" value={`${stats.process.memory.heapUsedHuman} / ${stats.process.memory.heapTotalHuman}`} />
            <Row label="External Memory" value={stats.process.memory.externalHuman} />
            <Row label="CPU (user)" value={stats.process.cpu.userMs} />
            <Row label="CPU (system)" value={stats.process.cpu.systemMs} />
          </div>
        </div>

        {/* System stats */}
        <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
          <div className="flex items-center gap-2 mb-4">
            <Server className="w-4 h-4 text-[#f39c12]" />
            <h3 className="text-[14px] font-semibold text-white">Host System</h3>
            <span className="text-[10px] text-[#6b7075] ml-auto">{stats.system.hostname}</span>
          </div>
          <div className="space-y-2">
            <Row label="OS" value={`${stats.system.osType} ${stats.system.osRelease}`} />
            <Row label="CPU Model" value={stats.system.cpuModel} />
            <Row label="CPU Cores" value={`${stats.system.cpuCount} @ ${stats.system.cpuSpeedMhz} MHz`} />
            <Row label="Load (1/5/15 min)" value={`${stats.system.loadAvg1} / ${stats.system.loadAvg5} / ${stats.system.loadAvg15}`} />
            <Row label="Total Memory" value={stats.system.memory.totalHuman} />
            <Row label="Used Memory" value={`${stats.system.memory.usedHuman} (${stats.system.memory.usedPct})`} highlight />
            <Row label="Free Memory" value={stats.system.memory.freeHuman} />
          </div>
        </div>
      </div>

      {/* Database stats (REAL) */}
      <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
        <div className="flex items-center gap-2 mb-4">
          <Database className="w-4 h-4 text-[#f39c12]" />
          <h3 className="text-[14px] font-semibold text-white">Database (Real)</h3>
          <span className="text-[10px] text-[#6b7075] ml-auto">{stats.database.engine}</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
          <div className="bg-[#1a1d21] rounded p-3">
            <div className="text-[10px] text-[#6b7075] uppercase mb-1">File Size</div>
            <div className="text-[20px] font-bold text-white">{stats.database.fileSizeHuman}</div>
          </div>
          <div className="bg-[#1a1d21] rounded p-3">
            <div className="text-[10px] text-[#6b7075] uppercase mb-1">Total Records</div>
            <div className="text-[20px] font-bold text-white">{stats.database.totalRecords.toLocaleString()}</div>
          </div>
          <div className="bg-[#1a1d21] rounded p-3">
            <div className="text-[10px] text-[#6b7075] uppercase mb-1">Tables</div>
            <div className="text-[20px] font-bold text-white">{stats.database.tables.length}</div>
          </div>
        </div>
        <div className="text-[10px] text-[#6b7075] font-mono mb-3 truncate">{stats.database.filePath}</div>

        {/* Table-by-table counts */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
          {stats.database.tables.map((t) => {
            const Icon = TABLE_ICONS[t.model] || Box
            return (
              <div key={t.name} className="bg-[#1a1d21] rounded p-2.5 flex items-center gap-2">
                <Icon className="w-3.5 h-3.5 text-[#8e9296] shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] text-white font-medium truncate">{t.name}</div>
                  <div className="text-[10px] text-[#6b7075]">{t.count.toLocaleString()} records</div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Platform info */}
      <div className="bg-[#232629] border border-[#2e3236] rounded-md p-5">
        <div className="flex items-center gap-2 mb-3">
          <Box className="w-4 h-4 text-[#f39c12]" />
          <h3 className="text-[14px] font-semibold text-white">Platform</h3>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-[12px]">
          <div>
            <div className="text-[#6b7075] uppercase text-[10px]">Version</div>
            <div className="text-white font-mono">{stats.bloom.version}</div>
          </div>
          <div>
            <div className="text-[#6b7075] uppercase text-[10px]">Build</div>
            <div className="text-white font-mono">{stats.bloom.build}</div>
          </div>
          <div>
            <div className="text-[#6b7075] uppercase text-[10px]">License</div>
            <div className="text-white">{stats.bloom.license}</div>
          </div>
          <div>
            <div className="text-[#6b7075] uppercase text-[10px]">Repository</div>
            <div className="text-[#4a90e2] font-mono text-[11px]">{stats.bloom.repository}</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-[#2a2d31] last:border-0">
      <span className="text-[11px] text-[#8e9296]">{label}</span>
      <span className={`text-[12px] font-mono ${highlight ? 'text-[#f39c12] font-medium' : 'text-white'}`}>{value}</span>
    </div>
  )
}
