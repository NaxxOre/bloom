'use client'

import { useEffect, useState } from 'react'
import { Activity, CheckCircle2, Clock, AlertCircle, ChevronRight } from 'lucide-react'
import { AnalystVerdictPanel } from '@/components/siem/analyst-verdict'

interface Investigation {
  id: string
  alertId: string
  title: string
  status: string
  severity: string
  assignee: string | null
  summary: string | null
  malicious: boolean
  createdAt: string
}

const STATUS_COLORS: Record<string, string> = {
  open: 'text-[#4a90e2] bg-[#4a90e2]/10',
  in_progress: 'text-[#f4b733] bg-[#f4b733]/10',
  contained: 'text-[#f39c12] bg-[#f39c12]/10',
  closed: 'text-[#2ecc71] bg-[#2ecc71]/10',
}

export function ResponseView() {
  const [inv, setInv] = useState<Investigation[]>([])
  const [selected, setSelected] = useState<Investigation | null>(null)

  useEffect(() => {
    fetch('/api/investigations').then((r) => r.json()).then((d) => {
      setInv(d.investigations || [])
      if (d.investigations?.length > 0) setSelected(d.investigations[0])
    })
  }, [])

  const stats = {
    open: inv.filter((i) => i.status === 'open').length,
    inProgress: inv.filter((i) => i.status === 'in_progress').length,
    contained: inv.filter((i) => i.status === 'contained').length,
    closed: inv.filter((i) => i.status === 'closed').length,
    malicious: inv.filter((i) => i.malicious).length,
  }

  return (
    <div className="p-5 space-y-4 max-w-[1600px] mx-auto">
      <div>
        <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#f39c12]" />
          Response & Remediation
        </h1>
        <p className="text-[12px] text-[#8e9296] mt-0.5">
          Incident investigations with AI-powered analyst verdicts
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { label: 'Open', value: stats.open, icon: AlertCircle, color: 'text-[#4a90e2]' },
          { label: 'In Progress', value: stats.inProgress, icon: Clock, color: 'text-[#f4b733]' },
          { label: 'Contained', value: stats.contained, icon: Activity, color: 'text-[#f39c12]' },
          { label: 'Closed', value: stats.closed, icon: CheckCircle2, color: 'text-[#2ecc71]' },
          { label: 'Malicious', value: stats.malicious, icon: AlertCircle, color: 'text-[#e74c3c]' },
        ].map((s) => {
          const Icon = s.icon
          return (
            <div key={s.label} className="bg-[#232629] border border-[#2e3236] rounded-md p-3">
              <Icon className={`w-4 h-4 ${s.color} mb-2`} />
              <div className="text-[24px] font-bold text-white">{s.value}</div>
              <div className="text-[11px] text-[#8e9296] uppercase tracking-wide">{s.label}</div>
            </div>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1.4fr_1fr] gap-4">
        {/* Left: Investigations list */}
        <div className="space-y-2">
          <div className="text-[13px] font-semibold text-white flex items-center gap-2 mb-1">
            <Clock className="w-4 h-4 text-[#f39c12]" />
            Active Investigations ({inv.length})
          </div>
          <div className="space-y-2 max-h-[calc(100vh-340px)] overflow-y-auto pr-1">
            {inv.map((i) => {
              const isSelected = selected?.id === i.id
              return (
                <button
                  key={i.id}
                  onClick={() => setSelected(i)}
                  className={`w-full text-left bg-[#232629] border rounded-md p-3 transition-all hover:border-[#3a3e42] ${
                    isSelected ? 'border-[#f39c12]' : 'border-[#2e3236]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div className="flex items-start gap-2 flex-1 min-w-0">
                      {i.malicious && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[#e74c3c] mt-1.5 shrink-0 bloom-pulse" />
                      )}
                      <span className="text-[13px] font-medium text-white truncate">{i.title}</span>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${
                        i.severity === 'critical' ? 'text-[#e74c3c] bg-[#e74c3c]/10' :
                        i.severity === 'high' ? 'text-[#f39c12] bg-[#f39c12]/10' :
                        i.severity === 'medium' ? 'text-[#f4b733] bg-[#f4b733]/10' : 'text-[#8e9296] bg-[#8e9296]/10'
                      }`}>
                        {i.severity}
                      </span>
                      <span className={`text-[10px] px-1.5 py-0.5 rounded uppercase font-medium ${STATUS_COLORS[i.status]}`}>
                        {i.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                  {i.summary && (
                    <p className="text-[11px] text-[#8e9296] line-clamp-2">{i.summary}</p>
                  )}
                  <div className="flex items-center gap-3 text-[10px] text-[#6b7075] mt-2">
                    {i.assignee && <span>👤 {i.assignee}</span>}
                    <span className="ml-auto">
                      {new Date(i.createdAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </button>
              )
            })}
          </div>
        </div>

        {/* Right: AI Analyst Verdict */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="text-[13px] font-semibold text-white flex items-center gap-2">
              <ChevronRight className="w-4 h-4 text-[#f39c12]" />
              {selected ? selected.title.slice(0, 40) + (selected.title.length > 40 ? '…' : '') : 'Select investigation'}
            </div>
          </div>

          {selected ? (
            <>
              <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4 space-y-2 text-[12px]">
                <div className="text-[13px] font-medium text-white">{selected.title}</div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-[#1a1d21] rounded p-2">
                    <div className="text-[#6b7075] uppercase text-[10px]">Severity</div>
                    <div className="text-white capitalize">{selected.severity}</div>
                  </div>
                  <div className="bg-[#1a1d21] rounded p-2">
                    <div className="text-[#6b7075] uppercase text-[10px]">Status</div>
                    <div className="text-white capitalize">{selected.status.replace('_', ' ')}</div>
                  </div>
                  <div className="bg-[#1a1d21] rounded p-2">
                    <div className="text-[#6b7075] uppercase text-[10px]">Assignee</div>
                    <div className="text-white">{selected.assignee || '—'}</div>
                  </div>
                  <div className="bg-[#1a1d21] rounded p-2">
                    <div className="text-[#6b7075] uppercase text-[10px]">Malicious</div>
                    <div className={selected.malicious ? 'text-[#e74c3c]' : 'text-[#2ecc71]'}>
                      {selected.malicious ? 'Yes' : 'No'}
                    </div>
                  </div>
                </div>
              </div>

              <AnalystVerdictPanel investigationId={selected.id} alertId={selected.alertId} />
            </>
          ) : (
            <div className="bg-[#232629] border border-[#2e3236] rounded-md p-8 text-center text-[12px] text-[#8e9296]">
              Select an investigation to see AI analyst verdict
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
