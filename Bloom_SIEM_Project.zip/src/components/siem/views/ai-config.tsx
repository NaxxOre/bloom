'use client'

import { useEffect, useState } from 'react'
import {
  KeyRound, Plus, Trash2, Star, Check, Loader2, Eye, EyeOff,
  Sparkles, Cpu, Zap, Brain, Bot, X, AlertCircle,
} from 'lucide-react'
import { toast } from 'sonner'

interface Provider {
  id: string
  provider: string
  label: string
  apiKey: string
  baseUrl: string | null
  model: string
  enabled: boolean
  isDefault: boolean
  lastUsedAt: string | null
  createdAt: string
}

interface TestResult {
  success: boolean
  provider?: string
  providerType?: string
  model?: string
  latencyMs?: number
  response?: string
  error?: string
  timestamp?: string
}

const PROVIDER_PRESETS: Record<string, { icon: React.ComponentType<{ className?: string }>; color: string; description: string; defaultModel: string; baseUrl: string }> = {
  zai: { icon: Sparkles, color: 'text-[#f39c12]', description: 'Z.ai GLM models — built-in', defaultModel: 'glm-4.6', baseUrl: 'https://chat.z.ai/api' },
  openai: { icon: Cpu, color: 'text-[#2ecc71]', description: 'GPT-4o, GPT-4 Turbo, o1', defaultModel: 'gpt-4o', baseUrl: 'https://api.openai.com/v1' },
  anthropic: { icon: Brain, color: 'text-[#f4b733]', description: 'Claude 3.5 Sonnet, Opus, Haiku', defaultModel: 'claude-3-5-sonnet-20241022', baseUrl: 'https://api.anthropic.com' },
  groq: { icon: Zap, color: 'text-[#e74c3c]', description: 'Ultra-fast Llama 3.1 inference', defaultModel: 'llama-3.1-70b-versatile', baseUrl: 'https://api.groq.com/openai/v1' },
  mistral: { icon: Bot, color: 'text-[#9b59b6]', description: 'Mistral Large, Codestral, Pixtral', defaultModel: 'mistral-large-latest', baseUrl: 'https://api.mistral.ai/v1' },
  custom: { icon: Cpu, color: 'text-[#8e9296]', description: 'OpenAI-compatible custom endpoint', defaultModel: '', baseUrl: '' },
}

// Improved toggle component
function Toggle({ enabled, onClick, disabled }: { enabled: boolean; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      role="switch"
      aria-checked={enabled}
      className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-[#f39c12] focus:ring-offset-2 focus:ring-offset-[#1a1d21] disabled:cursor-not-allowed disabled:opacity-50 ${
        enabled
          ? 'bg-[#2ecc71] border-[#2ecc71]'
          : 'bg-[#2a2d31] border-[#3a3e42]'
      }`}
    >
      <span
        className={`pointer-events-none inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
          enabled ? 'translate-x-4' : 'translate-x-0'
        }`}
      />
    </button>
  )
}

export function AIConfigView() {
  const [providers, setProviders] = useState<Provider[]>([])
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [revealKeys, setRevealKeys] = useState<Record<string, boolean>>({})
  const [testing, setTesting] = useState<string | null>(null)
  const [testResults, setTestResults] = useState<Record<string, TestResult>>({})

  // New provider form
  const [newProvider, setNewProvider] = useState({
    provider: 'openai',
    label: '',
    apiKey: '',
    baseUrl: '',
    model: '',
    isDefault: false,
  })

  // Edit existing provider API keys
  const [editKeys, setEditKeys] = useState<Record<string, string>>({})

  const load = () => {
    setLoading(true)
    fetch('/api/ai-providers')
      .then((r) => r.text())
      .then((text) => {
        try { return JSON.parse(text) } catch { return { providers: [] } }
      })
      .then((d) => setProviders(d.providers || []))
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const addProvider = async () => {
    if (!newProvider.label || !newProvider.apiKey) {
      toast.error('Label and API key are required')
      return
    }
    const preset = PROVIDER_PRESETS[newProvider.provider]
    const res = await fetch('/api/ai-providers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        provider: newProvider.provider,
        label: newProvider.label,
        apiKey: newProvider.apiKey,
        baseUrl: newProvider.baseUrl || preset.baseUrl,
        model: newProvider.model || preset.defaultModel,
        isDefault: newProvider.isDefault,
      }),
    })
    if (res.ok) {
      toast.success(`Added ${newProvider.label}`)
      setNewProvider({ provider: 'openai', label: '', apiKey: '', baseUrl: '', model: '', isDefault: false })
      setShowAdd(false)
      load()
    } else {
      toast.error('Failed to add provider')
    }
  }

  const toggleEnabled = async (id: string, enabled: boolean) => {
    await fetch('/api/ai-providers', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, enabled }),
    })
    setProviders((prev) => prev.map((p) => (p.id === id ? { ...p, enabled } : p)))
    toast.success(`Provider ${enabled ? 'enabled' : 'disabled'}`)
  }

  const setDefault = async (id: string) => {
    await fetch('/api/ai-providers', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, isDefault: true, enabled: true }),
    })
    load()
    toast.success('Default provider updated')
  }

  const updateApiKey = async (id: string) => {
    const newKey = editKeys[id]
    if (!newKey) return
    await fetch('/api/ai-providers', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, apiKey: newKey }),
    })
    setEditKeys((prev) => {
      const next = { ...prev }
      delete next[id]
      return next
    })
    toast.success('API key updated')
    load()
  }

  const deleteProvider = async (id: string) => {
    if (!confirm('Delete this AI provider?')) return
    await fetch(`/api/ai-providers?id=${id}`, { method: 'DELETE' })
    load()
    toast.success('Provider deleted')
  }

  // REAL test — actually calls the LLM API
  const testProvider = async (id: string) => {
    setTesting(id)
    // Clear previous result
    setTestResults((prev) => {
      const next = { ...prev }
      delete next[id]
      return next
    })
    try {
      const res = await fetch('/api/test-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ providerId: id }),
      })
      const text = await res.text()
      let d: TestResult
      try { d = JSON.parse(text) } catch { d = { success: false, error: 'Empty response from server' } }
      setTestResults((prev) => ({ ...prev, [id]: d }))
      if (d.success) {
        toast.success(`✓ ${d.provider} responded in ${d.latencyMs}ms`)
      } else {
        toast.error(`✗ ${d.provider || 'Test'} failed: ${d.error?.slice(0, 80)}`)
      }
      // Refresh to update lastUsedAt
      load()
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'unknown error'
      setTestResults((prev) => ({ ...prev, [id]: { success: false, error: msg } }))
      toast.error(`Test failed: ${msg}`)
    } finally {
      setTesting(null)
    }
  }

  return (
    <div className="p-5 space-y-5 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-[#f39c12]" />
            AI Providers
          </h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">
            Configure LLM API keys. The Test button sends a real prompt to the provider and returns the actual response.
          </p>
        </div>
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-2 bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[12px] px-4 py-2 rounded transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Provider
        </button>
      </div>

      {/* Default provider banner */}
      {providers.find((p) => p.isDefault && p.enabled) && (
        <div className="bg-[#2ecc71]/10 border border-[#2ecc71]/30 rounded-md p-3 flex items-center gap-2">
          <Check className="w-4 h-4 text-[#2ecc71]" />
          <span className="text-[12px] text-white">
            Default AI provider:{' '}
            <span className="font-semibold">{providers.find((p) => p.isDefault)?.label}</span>
            <span className="text-[#8e9296]"> · model {providers.find((p) => p.isDefault)?.model}</span>
          </span>
        </div>
      )}

      {/* New provider form */}
      {showAdd && (
        <div className="bg-[#232629] border border-[#f39c12] rounded-md p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="text-[14px] font-semibold text-white">Add New AI Provider</div>
            <button onClick={() => setShowAdd(false)} className="text-[#8e9296] hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase">Provider Type</label>
              <select
                value={newProvider.provider}
                onChange={(e) => {
                  const preset = PROVIDER_PRESETS[e.target.value]
                  setNewProvider({
                    ...newProvider,
                    provider: e.target.value,
                    baseUrl: preset.baseUrl,
                    model: preset.defaultModel,
                  })
                }}
                className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white outline-none focus:border-[#f39c12] mt-1"
              >
                {Object.entries(PROVIDER_PRESETS).map(([k, v]) => (
                  <option key={k} value={k}>{k.charAt(0).toUpperCase() + k.slice(1)} — {v.description}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase">Display Label</label>
              <input
                value={newProvider.label}
                onChange={(e) => setNewProvider({ ...newProvider, label: e.target.value })}
                placeholder="e.g. Production GPT-4o"
                className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white outline-none focus:border-[#f39c12] mt-1"
              />
            </div>
            <div className="md:col-span-2">
              <label className="text-[11px] text-[#8e9296] uppercase">API Key</label>
              <input
                type="password"
                value={newProvider.apiKey}
                onChange={(e) => setNewProvider({ ...newProvider, apiKey: e.target.value })}
                placeholder="sk-... (paste your API key here)"
                className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white font-mono outline-none focus:border-[#f39c12] mt-1"
              />
              <p className="text-[10px] text-[#6b7075] mt-1">
                Stored in the SIEM database. In production, encrypt at rest with KMS.
              </p>
            </div>
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase">Base URL</label>
              <input
                value={newProvider.baseUrl}
                onChange={(e) => setNewProvider({ ...newProvider, baseUrl: e.target.value })}
                className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white font-mono outline-none focus:border-[#f39c12] mt-1"
              />
            </div>
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase">Model</label>
              <input
                value={newProvider.model}
                onChange={(e) => setNewProvider({ ...newProvider, model: e.target.value })}
                className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white font-mono outline-none focus:border-[#f39c12] mt-1"
              />
            </div>
            <label className="flex items-center gap-2 text-[12px] text-white md:col-span-2">
              <input
                type="checkbox"
                checked={newProvider.isDefault}
                onChange={(e) => setNewProvider({ ...newProvider, isDefault: e.target.checked })}
                className="w-4 h-4 accent-[#f39c12]"
              />
              Set as default AI provider
            </label>
          </div>
          <div className="flex gap-2 pt-2">
            <button onClick={addProvider} className="bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] text-[12px] font-medium px-4 py-1.5 rounded">
              Add Provider
            </button>
            <button onClick={() => setShowAdd(false)} className="bg-[#2a2d31] hover:bg-[#3a3e42] text-white text-[12px] px-4 py-1.5 rounded">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Provider cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {loading && (
          <div className="md:col-span-2 text-center py-12 text-[#8e9296] text-[13px]">
            <Loader2 className="w-6 h-6 mx-auto mb-2 animate-spin" />
            Loading providers…
          </div>
        )}
        {!loading && providers.map((p) => {
          const preset = PROVIDER_PRESETS[p.provider] || PROVIDER_PRESETS.custom
          const Icon = preset.icon
          const revealed = revealKeys[p.id]
          const editingKey = editKeys[p.id] !== undefined
          const testResult = testResults[p.id]
          return (
            <div
              key={p.id}
              className={`bg-[#232629] border rounded-md p-4 transition-colors ${
                p.isDefault ? 'border-[#f39c12]' : p.enabled ? 'border-[#2e3236]' : 'border-[#2e3236] opacity-70'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className={`w-10 h-10 rounded bg-[#1a1d21] flex items-center justify-center shrink-0`}>
                    <Icon className={`w-5 h-5 ${preset.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <span className="text-[14px] font-semibold text-white truncate">{p.label}</span>
                      {p.isDefault && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#f39c12] text-[#1a1d21] font-medium flex items-center gap-1">
                          <Star className="w-2.5 h-2.5 fill-current" />
                          DEFAULT
                        </span>
                      )}
                      {!p.enabled && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#2a2d31] text-[#8e9296]">
                          DISABLED
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-[#8e9296]">{preset.description}</div>
                    <div className="text-[10px] text-[#6b7075] font-mono mt-0.5">{p.model}</div>
                  </div>
                </div>
                <Toggle enabled={p.enabled} onClick={() => toggleEnabled(p.id, !p.enabled)} />
              </div>

              {/* API key row */}
              <div className="bg-[#1a1d21] rounded p-2 mb-2">
                {editingKey ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="password"
                      value={editKeys[p.id]}
                      onChange={(e) => setEditKeys((prev) => ({ ...prev, [p.id]: e.target.value }))}
                      placeholder="Enter new API key"
                      className="flex-1 bg-transparent text-[11px] text-white font-mono outline-none"
                    />
                    <button
                      onClick={() => updateApiKey(p.id)}
                      className="text-[10px] bg-[#2ecc71] text-[#1a1d21] px-2 py-0.5 rounded font-medium"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditKeys((prev) => {
                        const next = { ...prev }
                        delete next[p.id]
                        return next
                      })}
                      className="text-[10px] text-[#8e9296] px-1"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-[#6b7075] uppercase shrink-0">API Key:</span>
                    <code className="text-[11px] text-[#b0b3b8] font-mono flex-1 truncate">
                      {p.apiKey || '(not set)'}
                    </code>
                    <button
                      onClick={() => setRevealKeys((prev) => ({ ...prev, [p.id]: !prev[p.id] }))}
                      className="text-[#8e9296] hover:text-white"
                    >
                      {revealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    </button>
                    <button
                      onClick={() => setEditKeys((prev) => ({ ...prev, [p.id]: '' }))}
                      className="text-[10px] text-[#f39c12] hover:underline"
                    >
                      Edit
                    </button>
                  </div>
                )}
              </div>

              {/* Base URL */}
              {p.baseUrl && (
                <div className="text-[10px] text-[#6b7075] mb-2 truncate font-mono">
                  → {p.baseUrl}
                </div>
              )}

              {/* Test result panel (real API response) */}
              {testResult && (
                <div className={`rounded p-2.5 mb-2 text-[11px] ${
                  testResult.success
                    ? 'bg-[#2ecc71]/10 border border-[#2ecc71]/30'
                    : 'bg-[#e74c3c]/10 border border-[#e74c3c]/30'
                }`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className={`font-medium flex items-center gap-1 ${testResult.success ? 'text-[#2ecc71]' : 'text-[#e74c3c]'}`}>
                      {testResult.success ? <Check className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                      {testResult.success ? 'Connection OK' : 'Connection Failed'}
                    </span>
                    <span className="text-[10px] text-[#8e9296]">
                      {testResult.latencyMs ? `${testResult.latencyMs}ms` : ''} · {testResult.model}
                    </span>
                  </div>
                  {testResult.success && testResult.response && (
                    <div className="text-[#e8e9ea] font-mono text-[10px] bg-[#1a1d21] rounded p-1.5 mt-1">
                      Response: "{testResult.response}"
                    </div>
                  )}
                  {testResult.error && (
                    <div className="text-[#e74c3c] font-mono text-[10px] bg-[#1a1d21] rounded p-1.5 mt-1 break-words">
                      {testResult.error}
                    </div>
                  )}
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2 border-t border-[#2a2d31] flex-wrap">
                {!p.isDefault && (
                  <button
                    onClick={() => setDefault(p.id)}
                    className="text-[11px] text-[#f39c12] hover:underline flex items-center gap-1"
                  >
                    <Star className="w-3 h-3" />
                    Set default
                  </button>
                )}
                <button
                  onClick={() => testProvider(p.id)}
                  disabled={testing === p.id}
                  className="text-[11px] text-[#4a90e2] hover:underline flex items-center gap-1 disabled:opacity-50"
                >
                  {testing === p.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  Test API
                </button>
                {p.lastUsedAt && (
                  <span className="text-[10px] text-[#6b7075]">
                    Last used {new Date(p.lastUsedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </span>
                )}
                <button
                  onClick={() => deleteProvider(p.id)}
                  className="text-[11px] text-[#e74c3c] hover:underline ml-auto flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {/* Info box */}
      <div className="bg-[#232629] border border-[#2e3236] rounded-md p-4 text-[12px] text-[#8e9296] leading-relaxed">
        <div className="text-[13px] font-semibold text-white mb-2 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#f39c12]" />
          How AI is used in Bloom SIEM
        </div>
        <ul className="space-y-1.5 text-[11px]">
          <li>• <span className="text-white">Test API</span> — sends a real test prompt to the provider and shows the actual response + latency.</li>
          <li>• <span className="text-white">AI Analyst Verdict</span> — generates confidence-scored verdicts on alerts/investigations using the real LLM.</li>
          <li>• <span className="text-white">Auto-Triage</span> — classifies new alerts and prioritizes them for the SOC queue.</li>
          <li>• <span className="text-white">Target Risk Assessment</span> — analyzes real domain/localhost scan results.</li>
          <li>• The default provider is used for all AI calls. Toggle providers on/off and switch defaults anytime.</li>
          <li>• <span className="text-[#f4b733]">Built-in ZAI provider</span> is auto-configured via z-ai-web-dev-sdk — add your own OpenAI/Anthropic/Groq/Mistral keys to use those models.</li>
        </ul>
      </div>
    </div>
  )
}
