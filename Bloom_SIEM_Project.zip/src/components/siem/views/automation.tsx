'use client'

import { useEffect, useState } from 'react'
import {
  Ban, Bot, Clock, FileText, Network, Plus,
  ShieldX, UserX, Bell, Activity, Globe, LogOut, Zap,
} from 'lucide-react'
import { toast } from 'sonner'
import { Toggle } from '@/components/siem/toggle'

interface Rule {
  id: string; name: string; description: string; enabled: boolean
  trigger: string; condition: string; action: string; cooldownMin: number
  lastFiredAt: string | null; triggerCount: number; createdAt: string
}

interface Action {
  id: string; action: string; target: string; status: string; details: string | null
  initiatedBy: string; createdAt: string
  rule?: { name: string } | null; alert?: { title: string; severity: string } | null
}

const ACTION_META: Record<string, { icon: React.ComponentType<{ className?: string }>; color: string; label: string }> = {
  block_ip: { icon: Ban, color: 'text-[#e74c3c]', label: 'Block IP' },
  block_country: { icon: Globe, color: 'text-[#e74c3c]', label: 'Block Country' },
  sign_out_session: { icon: LogOut, color: 'text-[#f39c12]', label: 'Sign Out Session' },
  isolate_host: { icon: Network, color: 'text-[#f39c12]', label: 'Isolate Host' },
  disable_user: { icon: UserX, color: 'text-[#f4b733]', label: 'Disable User' },
  quarantine_file: { icon: ShieldX, color: 'text-[#9b59b6]', label: 'Quarantine File' },
  create_ticket: { icon: FileText, color: 'text-[#4a90e2]', label: 'Create Ticket' },
  notify: { icon: Bell, color: 'text-[#2ecc71]', label: 'Notify Telegram' },
}

const TRIGGER_OPTIONS = [
  { value: 'country', label: 'Visitor Country', desc: 'Trigger when traffic comes from specific countries' },
  { value: 'brute_force', label: 'Brute Force Attack', desc: 'Same IP hitting the same input field >5 times' },
  { value: 'session_replication', label: 'Session Replication', desc: 'Same session used from multiple IPs' },
  { value: 'malware_detected', label: 'Malware Upload', desc: 'File scan detects malicious content' },
  { value: 'sql_xss', label: 'SQLi / XSS Attempt', desc: 'Malicious input detected in form fields' },
  { value: 'bot_traffic', label: 'Bot Traffic', desc: 'Non-browser user agent detected' },
  { value: 'alert_severity', label: 'Alert Severity', desc: 'Any alert of high/critical severity' },
  { value: 'source_ip_repeat', label: 'Source IP Repeat', desc: 'Same IP appearing 3+ times in 10 minutes' },
]

const COUNTRY_OPTIONS = [
  { code: 'MM', name: 'Myanmar' }, { code: 'CN', name: 'China' }, { code: 'RU', name: 'Russia' },
  { code: 'KP', name: 'North Korea' }, { code: 'IR', name: 'Iran' }, { code: 'SY', name: 'Syria' },
  { code: 'CU', name: 'Cuba' }, { code: 'SD', name: 'Sudan' }, { code: 'VN', name: 'Vietnam' },
  { code: 'BR', name: 'Brazil' }, { code: 'IN', name: 'India' }, { code: 'ID', name: 'Indonesia' },
  { code: 'PH', name: 'Philippines' }, { code: 'TH', name: 'Thailand' }, { code: 'MY', name: 'Malaysia' },
  { code: 'SG', name: 'Singapore' }, { code: 'JP', name: 'Japan' }, { code: 'KR', name: 'South Korea' },
  { code: 'PK', name: 'Pakistan' }, { code: 'BD', name: 'Bangladesh' }, { code: 'LK', name: 'Sri Lanka' },
  { code: 'NP', name: 'Nepal' }, { code: 'AF', name: 'Afghanistan' }, { code: 'IQ', name: 'Iraq' },
  { code: 'SA', name: 'Saudi Arabia' }, { code: 'AE', name: 'UAE' }, { code: 'EG', name: 'Egypt' },
  { code: 'NG', name: 'Nigeria' }, { code: 'ZA', name: 'South Africa' }, { code: 'KE', name: 'Kenya' },
  { code: 'MA', name: 'Morocco' }, { code: 'GH', name: 'Ghana' }, { code: 'ET', name: 'Ethiopia' },
  { code: 'TZ', name: 'Tanzania' }, { code: 'US', name: 'United States' }, { code: 'CA', name: 'Canada' },
  { code: 'MX', name: 'Mexico' }, { code: 'GB', name: 'United Kingdom' }, { code: 'IE', name: 'Ireland' },
  { code: 'FR', name: 'France' }, { code: 'DE', name: 'Germany' }, { code: 'IT', name: 'Italy' },
  { code: 'ES', name: 'Spain' }, { code: 'PT', name: 'Portugal' }, { code: 'NL', name: 'Netherlands' },
  { code: 'BE', name: 'Belgium' }, { code: 'CH', name: 'Switzerland' }, { code: 'AT', name: 'Austria' },
  { code: 'SE', name: 'Sweden' }, { code: 'NO', name: 'Norway' }, { code: 'FI', name: 'Finland' },
  { code: 'DK', name: 'Denmark' }, { code: 'PL', name: 'Poland' }, { code: 'CZ', name: 'Czech Republic' },
  { code: 'HU', name: 'Hungary' }, { code: 'RO', name: 'Romania' }, { code: 'BG', name: 'Bulgaria' },
  { code: 'GR', name: 'Greece' }, { code: 'TR', name: 'Turkey' }, { code: 'UA', name: 'Ukraine' },
  { code: 'BY', name: 'Belarus' }, { code: 'RS', name: 'Serbia' }, { code: 'HR', name: 'Croatia' },
  { code: 'IL', name: 'Israel' }, { code: 'JO', name: 'Jordan' }, { code: 'LB', name: 'Lebanon' },
  { code: 'AU', name: 'Australia' }, { code: 'NZ', name: 'New Zealand' }, { code: 'AR', name: 'Argentina' },
  { code: 'CL', name: 'Chile' }, { code: 'CO', name: 'Colombia' }, { code: 'PE', name: 'Peru' },
  { code: 'VE', name: 'Venezuela' }, { code: 'CR', name: 'Costa Rica' }, { code: 'PA', name: 'Panama' },
]

export function AutomationView() {
  const [rules, setRules] = useState<Rule[]>([])
  const [actions, setActions] = useState<Action[]>([])
  const [showNew, setShowNew] = useState(false)
  const [newRule, setNewRule] = useState({
    name: '', description: '', trigger: 'country', action: 'block_ip',
    cooldownMin: 30, countries: [] as string[],
  })

  const load = () => {
    fetch('/api/automation').then((r) => r.json()).then((d) => {
      setRules(d.rules || []); setActions(d.actions || [])
    })
  }
  useEffect(() => { load() }, [])

  const toggleRule = async (ruleId: string, enabled: boolean) => {
    await fetch('/api/automation', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ruleId, enabled }) })
    setRules((prev) => prev.map((r) => (r.id === ruleId ? { ...r, enabled } : r)))
    toast.success(`Rule ${enabled ? 'enabled' : 'disabled'}`)
  }

  const createRule = async () => {
    if (!newRule.name) { toast.error('Rule name is required'); return }
    let condition = '{}'
    if (newRule.trigger === 'country' && newRule.countries.length > 0) {
      condition = JSON.stringify({ countries: newRule.countries })
    }
    await fetch('/api/automation', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: newRule.name, description: newRule.description, trigger: newRule.trigger, action: newRule.action, cooldownMin: newRule.cooldownMin, condition }),
    })
    if (newRule.trigger === 'country' && newRule.countries.length > 0) {
      toast.success(`Rule created — blocking ${newRule.countries.length} countries`)
    } else {
      toast.success('Automation rule created')
    }
    setNewRule({ name: '', description: '', trigger: 'country', action: 'block_ip', cooldownMin: 30, countries: [] })
    setShowNew(false); load()
  }

  return (
    <div className="p-5 space-y-5 max-w-[1200px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] font-bold text-white flex items-center gap-2">
            <Bot className="w-5 h-5 text-[#f39c12]" />Automation
          </h1>
          <p className="text-[12px] text-[#8e9296] mt-0.5">Real automated responses — country blocking, brute-force protection, session revocation, malware quarantine</p>
        </div>
        <button onClick={() => setShowNew(!showNew)} className="flex items-center gap-2 bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[12px] px-4 py-2 rounded">
          <Plus className="w-3.5 h-3.5" />New Rule
        </button>
      </div>

      {/* How blocking works */}
      <div className="bg-[#4a90e2]/10 border border-[#4a90e2]/30 rounded-md p-3 text-[11px] text-[#b0b3b8]">
        <strong className="text-[#4a90e2]">How blocking works:</strong>{' '}
        Rules are enforced by your site's middleware (Next.js or Express). The middleware calls Bloom's <code className="text-[#f4b733]">/api/sdk/evaluate</code> on every request — if the IP/country/session is blocked, it returns 403 immediately.
        The HTML script tag <strong className="text-[#e74c3c]">cannot block</strong> (it runs after page load) — it's monitoring only.
      </div>

      {/* New rule form */}
      {showNew && (
        <div className="bg-[#232629] border border-[#f39c12] rounded-md p-5 space-y-4">
          <div className="text-[14px] font-semibold text-white">Create New Automation Rule</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase">Rule Name</label>
              <input value={newRule.name} onChange={(e) => setNewRule({ ...newRule, name: e.target.value })} placeholder="e.g. Block high-risk countries" className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white outline-none focus:border-[#f39c12] mt-1" />
            </div>
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase">Description</label>
              <input value={newRule.description} onChange={(e) => setNewRule({ ...newRule, description: e.target.value })} placeholder="What this rule does" className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white outline-none focus:border-[#f39c12] mt-1" />
            </div>
          </div>

          <div>
            <label className="text-[11px] text-[#8e9296] uppercase mb-2 block">When to trigger</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              {TRIGGER_OPTIONS.map((opt) => (
                <button key={opt.value} onClick={() => setNewRule({ ...newRule, trigger: opt.value })}
                  className={`text-left p-2.5 rounded border transition-colors ${newRule.trigger === opt.value ? 'border-[#f39c12] bg-[#f39c12]/10' : 'border-[#2e3236] bg-[#1a1d21] hover:border-[#3a3e42]'}`}>
                  <div className="text-[12px] font-medium text-white">{opt.label}</div>
                  <div className="text-[10px] text-[#8e9296] mt-0.5">{opt.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {newRule.trigger === 'country' && (
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase mb-2 block">Select countries to block ({newRule.countries.length} selected)</label>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-1.5 max-h-[200px] overflow-y-auto">
                {COUNTRY_OPTIONS.map((c) => (
                  <button key={c.code} onClick={() => {
                    const selected = newRule.countries.includes(c.code)
                    setNewRule({ ...newRule, countries: selected ? newRule.countries.filter((x) => x !== c.code) : [...newRule.countries, c.code] })
                  }} className={`text-[11px] px-2 py-1.5 rounded border transition-colors ${newRule.countries.includes(c.code) ? 'border-[#e74c3c] bg-[#e74c3c]/20 text-[#e74c3c]' : 'border-[#2e3236] bg-[#1a1d21] text-[#8e9296] hover:text-white'}`}>
                    {c.code} — {c.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase">Action</label>
              <select value={newRule.action} onChange={(e) => setNewRule({ ...newRule, action: e.target.value })} className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white mt-1">
                {Object.entries(ACTION_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] text-[#8e9296] uppercase">Cooldown (minutes)</label>
              <input type="number" min={1} value={newRule.cooldownMin} onChange={(e) => setNewRule({ ...newRule, cooldownMin: Number(e.target.value) })} className="w-full bg-[#1a1d21] border border-[#2e3236] rounded px-3 py-2 text-[12px] text-white mt-1" />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button onClick={createRule} className="bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] text-[12px] font-medium px-4 py-1.5 rounded">Create Rule</button>
            <button onClick={() => setShowNew(false)} className="bg-[#2a2d31] hover:bg-[#3a3e42] text-white text-[12px] px-4 py-1.5 rounded">Cancel</button>
          </div>
        </div>
      )}

      {/* Active rules */}
      <div>
        <div className="text-[14px] font-semibold text-white mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#f39c12]" />Active Rules ({rules.filter((r) => r.enabled).length}/{rules.length})
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {rules.length === 0 ? (
            <div className="text-[12px] text-[#6b7075] py-8 text-center col-span-2">No rules yet. Click "New Rule" to create one.</div>
          ) : (
            rules.map((r) => {
              const meta = ACTION_META[r.action] || { icon: Bot, color: 'text-[#8e9296]', label: r.action }
              const Icon = meta.icon
              let conditionDisplay = ''
              try { const cond = JSON.parse(r.condition); if (cond.countries) conditionDisplay = `Countries: ${cond.countries.join(', ')}` } catch {}
              return (
                <div key={r.id} className={`bg-[#232629] border rounded-md p-4 ${r.enabled ? 'border-[#2e3236]' : 'border-[#2e3236] opacity-60'}`}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className="w-8 h-8 rounded bg-[#1a1d21] flex items-center justify-center shrink-0"><Icon className={`w-4 h-4 ${meta.color}`} /></div>
                      <div className="flex-1 min-w-0">
                        <div className="text-[13px] font-medium text-white">{r.name}</div>
                        <div className="text-[11px] text-[#8e9296] line-clamp-2 mt-0.5">{r.description || conditionDisplay}</div>
                      </div>
                    </div>
                    <Toggle enabled={r.enabled} onClick={() => toggleRule(r.id, !r.enabled)} />
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-[#6b7075] mt-3 pt-3 border-t border-[#2a2d31]">
                    <span className="flex items-center gap-1"><Activity className="w-3 h-3" />{TRIGGER_OPTIONS.find((t) => t.value === r.trigger)?.label || r.trigger}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{r.cooldownMin}m cooldown</span>
                    {conditionDisplay && <span className="flex items-center gap-1"><Globe className="w-3 h-3" />{conditionDisplay}</span>}
                    <span className="ml-auto">Fired <span className="text-[#f39c12] font-medium">{r.triggerCount}</span> times</span>
                  </div>
                </div>
              )
            })
          )}
        </div>
      </div>

      {/* Action history */}
      {actions.length > 0 && (
        <div>
          <div className="text-[14px] font-semibold text-white mb-3 flex items-center gap-2"><Clock className="w-4 h-4 text-[#f39c12]" />Action History ({actions.length})</div>
          <div className="bg-[#232629] border border-[#2e3236] rounded-md overflow-hidden">
            <div className="grid grid-cols-[2fr_1.5fr_2fr_1fr_1fr_1.5fr] gap-3 px-4 py-2 text-[10px] uppercase text-[#6b7075] border-b border-[#2e3236] font-medium">
              <span>Action</span><span>Target</span><span>Triggered By</span><span>By</span><span>Status</span><span>Time</span>
            </div>
            <div className="max-h-[300px] overflow-y-auto">
              {actions.slice(0, 20).map((a) => {
                const meta = ACTION_META[a.action]; const Icon = meta?.icon || Bot
                return (
                  <div key={a.id} className="grid grid-cols-[2fr_1.5fr_2fr_1fr_1fr_1.5fr] gap-3 px-4 py-2 text-[11px] border-b border-[#2a2d31] hover:bg-[#2a2d31]">
                    <span className="flex items-center gap-2 text-white"><Icon className={`w-3.5 h-3.5 ${meta?.color || 'text-[#8e9296]'}`} />{meta?.label || a.action}</span>
                    <span className="text-[#b0b3b8] font-mono truncate">{a.target}</span>
                    <span className="text-[#8e9296] truncate">{a.alert?.title || a.rule?.name || 'Manual'}</span>
                    <span className={a.initiatedBy === 'ai' ? 'text-[#f39c12]' : 'text-[#4a90e2]'}>{a.initiatedBy === 'ai' ? 'AI' : 'User'}</span>
                    <span className={a.status === 'success' ? 'text-[#2ecc71]' : 'text-[#e74c3c]'}>{a.status}</span>
                    <span className="text-[#6b7075]">{new Date(a.createdAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
