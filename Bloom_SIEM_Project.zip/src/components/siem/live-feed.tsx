'use client'

import { useEffect, useState } from 'react'
import { useSiemStore, type LiveEvent } from '@/lib/siem-store'
import { ScrollArea } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'
import { Activity, AlertTriangle, Ban, Bell, Bot, Clock, Heart, Network, ShieldX, UserX } from 'lucide-react'

const ACTION_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  block_ip: Ban,
  isolate_host: Network,
  disable_user: UserX,
  quarantine_file: ShieldX,
  create_ticket: AlertTriangle,
  notify: Bell,
}

export function LiveActivityFeed() {
  const liveEvents = useSiemStore((s) => s.liveEvents)
  const pushLiveEvent = useSiemStore((s) => s.pushLiveEvent)
  const wsConnected = useSiemStore((s) => s.wsConnected)
  const setWsConnected = useSiemStore((s) => s.setWsConnected)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let es: EventSource | null = null
    let closed = false

    const connect = () => {
      if (closed) return
      es = new EventSource('/api/live?mode=sse')

      es.onopen = () => {
        setWsConnected(true)
        setError(null)
      }

      es.onmessage = (msg) => {
        try {
          const data = JSON.parse(msg.data) as LiveEvent & { type: string }
          if (data.type === 'hello') return
          pushLiveEvent({
            id: data.id,
            type: data.type as LiveEvent['type'],
            message: data.message,
            severity: data.severity,
            ts: data.ts,
          })
        } catch {
          // ignore parse errors (e.g. ping comments)
        }
      }

      es.onerror = () => {
        setWsConnected(false)
        setError('Reconnecting...')
        es?.close()
        setTimeout(connect, 3000)
      }
    }

    connect()

    return () => {
      closed = true
      es?.close()
      setWsConnected(false)
    }
  }, [pushLiveEvent, setWsConnected])

  return (
    <div className="bg-[#232629] border border-[#2e3236] rounded-md flex flex-col h-[calc(100vh-120px)]">
      <div className="px-4 py-3 border-b border-[#2e3236] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-[#f39c12]" />
          <h3 className="text-[14px] font-semibold text-white">Live Activity Feed</h3>
        </div>
        <div className="flex items-center gap-1.5 text-[11px]">
          <span className={`relative w-1.5 h-1.5 ${wsConnected ? '' : 'opacity-40'}`}>
            <span className={`absolute inset-0 rounded-full ${wsConnected ? 'bg-[#2ecc71] bloom-pulse' : 'bg-[#8e9296]'}`} />
          </span>
          <span className="text-[#8e9296]">{wsConnected ? 'Streaming' : error || 'Disconnected'}</span>
        </div>
      </div>
      <ScrollArea className="flex-1 min-h-0">
        <div className="px-3 py-2 space-y-1">
          {liveEvents.length === 0 && (
            <div className="text-[12px] text-[#6b7075] py-8 text-center">
              Waiting for live events...
            </div>
          )}
          {liveEvents.map((e) => {
            const Icon =
              e.type === 'heartbeat' ? Heart :
              e.type === 'alert' || e.type === 'agent_offline' ? AlertTriangle :
              e.type === 'action' ? (ACTION_ICONS[e.message.split(' ')[1]] || Bot) :
              Clock
            const sevColor =
              e.severity === 'critical' ? 'text-[#e74c3c]' :
              e.severity === 'high' ? 'text-[#f39c12]' :
              e.severity === 'medium' ? 'text-[#f4b733]' :
              e.severity === 'low' ? 'text-[#8e9296]' :
              'text-[#8e9296]'
            return (
              <div
                key={e.id}
                className="flex items-start gap-2 px-2 py-1.5 rounded hover:bg-[#2a2d31] transition-colors"
              >
                <Icon className={cn('w-3.5 h-3.5 mt-0.5 shrink-0', sevColor)} />
                <div className="flex-1 min-w-0">
                  <div className="text-[12px] text-[#e8e9ea] leading-tight">{e.message}</div>
                  <div className="text-[10px] text-[#6b7075] mt-0.5">
                    {new Date(e.ts).toLocaleTimeString()}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </ScrollArea>
    </div>
  )
}
