'use client'

import { Search, Bell, ChevronDown, User } from 'lucide-react'
import { useEffect, useState } from 'react'

const TOP_TABS: { label: string; path: string; viewId: string }[] = [
  { label: 'Attack Surface', path: '/attack-surface', viewId: 'attack_surface' },
  { label: 'Exposure Management', path: '/exposure', viewId: 'exposure' },
  { label: 'Detection & Response', path: '/response', viewId: 'response' },
]

const VIEW_TITLES: Record<string, string> = {
  home: 'Command Home',
  monitored_targets: 'Monitored Targets',
  attack_surface: 'Attack Surface',
  exposure: 'Exposure Management',
  projects: 'Projects',
  traffic: 'Traffic Overview',
  live_logs: 'Live Logs',
  reports: 'Reports & Dashboards',
  response: 'Response & Remediation',
  alerts: 'Alerts',
  intelligence: 'Intelligence',
  controls: 'Controls & Compliance',
  connectors: 'Data Sources & Blocklist',
  automation: 'Automation',
  ai_config: 'AI Providers',
  telegram: 'Telegram Bot',
  admin: 'Administration',
}

export function Header({ activeView, onNavigate }: {
  activeView: string
  onNavigate: (path: string) => void
}) {
  const [connected, setConnected] = useState(false)

  useEffect(() => {
    let es: EventSource | null = null
    let closed = false
    const connect = () => {
      if (closed) return
      es = new EventSource('/api/live?mode=sse')
      es.onopen = () => setConnected(true)
      es.onerror = () => {
        setConnected(false)
        es?.close()
        setTimeout(connect, 3000)
      }
    }
    connect()
    return () => { closed = true; es?.close() }
  }, [])

  const activeTab = TOP_TABS.find((t) => t.viewId === activeView)?.viewId

  return (
    <header className="h-14 shrink-0 border-b border-[#2e3236] bg-[#1a1d21] flex items-center justify-between px-5">
      <div className="flex items-center gap-1">
        {TOP_TABS.map((tab) => {
          const isActive = activeTab === tab.viewId
          return (
            <button
              key={tab.path}
              onClick={() => onNavigate(tab.path)}
              className={`text-[13px] px-3 py-1.5 rounded transition-colors relative ${
                isActive ? 'text-white' : 'text-[#8e9296] hover:text-white'
              }`}
            >
              {tab.label}
              {isActive && (
                <span className="absolute -bottom-[1px] left-0 right-0 h-0.5 bg-[#f39c12]" />
              )}
            </button>
          )
        })}
      </div>

      <div className="absolute left-1/2 -translate-x-1/2 text-[13px] text-[#8e9296] hidden md:block">
        <span className="text-white font-medium">{VIEW_TITLES[activeView] || 'Bloom'}</span>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden md:flex items-center gap-2 bg-[#2a2d31] rounded px-3 py-1.5 w-64">
          <Search className="w-3.5 h-3.5 text-[#8e9296]" />
          <input
            placeholder="Search IPs, hosts, alerts..."
            className="bg-transparent text-[12px] text-white placeholder:text-[#6b7075] outline-none flex-1"
          />
          <kbd className="text-[10px] text-[#6b7075] border border-[#3a3e42] rounded px-1">⌘K</kbd>
        </div>

        <div className="flex items-center gap-1.5 text-[11px]">
          <span className={`relative w-2 h-2 ${connected ? '' : 'opacity-40'}`}>
            <span className={`absolute inset-0 rounded-full ${connected ? 'bg-[#2ecc71] bloom-pulse' : 'bg-[#8e9296]'}`} />
          </span>
          <span className="text-[#8e9296]">{connected ? 'Live' : 'Offline'}</span>
        </div>

        <button className="relative w-8 h-8 rounded hover:bg-[#2a2d31] flex items-center justify-center">
          <Bell className="w-4 h-4 text-[#8e9296]" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-[#e74c3c]" />
        </button>

        <button className="flex items-center gap-2 hover:bg-[#2a2d31] rounded px-2 py-1.5">
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#f39c12] to-[#e67e22] flex items-center justify-center">
            <User className="w-3.5 h-3.5 text-[#1a1d21]" />
          </div>
          <div className="text-left hidden md:block">
            <div className="text-[12px] text-white leading-tight">soc-admin</div>
            <div className="text-[10px] text-[#8e9296] leading-tight">SOC Lead</div>
          </div>
          <ChevronDown className="w-3 h-3 text-[#8e9296] hidden md:block" />
        </button>
      </div>
    </header>
  )
}
