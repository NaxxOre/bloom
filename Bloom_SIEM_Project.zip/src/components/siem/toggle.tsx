'use client'

import { cn } from '@/lib/utils'

export function Toggle({ enabled, onClick, disabled }: {
  enabled: boolean
  onClick: () => void
  disabled?: boolean
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      role="switch"
      aria-checked={enabled}
      className={cn(
        'relative inline-flex h-7 w-12 shrink-0 cursor-pointer rounded-full border-2 transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-[#f39c12] focus:ring-offset-2 focus:ring-offset-[#1a1d21] disabled:cursor-not-allowed disabled:opacity-50',
        enabled
          ? 'bg-[#2ecc71] border-[#2ecc71]'
          : 'bg-[#1a1d21] border-[#3a3e42]'
      )}
    >
      {/* ON/OFF label - shown on the left side when enabled, right side when disabled */}
      <span
        className={cn(
          'absolute top-1/2 -translate-y-1/2 text-[8px] font-bold uppercase tracking-wider transition-opacity duration-200',
          enabled ? 'left-1.5 text-[#1a1d21] opacity-100' : 'right-1.5 text-[#6b7075] opacity-100'
        )}
      >
        {enabled ? 'ON' : 'OFF'}
      </span>
      {/* The sliding knob */}
      <span
        className={cn(
          'pointer-events-none absolute top-1/2 h-5 w-5 -translate-y-1/2 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out',
          enabled ? 'left-6' : 'left-0.5'
        )}
      />
    </button>
  )
}
