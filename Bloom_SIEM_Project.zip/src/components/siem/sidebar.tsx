'use client'

import { cn } from '@/lib/utils'
import {
  Home, BarChart3, Siren, ShieldAlert, Network, Shield,
  BrainCircuit, ShieldCheck, Plug, Bot, Settings, Activity,
  KeyRound, Globe, Crosshair, Send, LayoutDashboard,
} from 'lucide-react'

function BloomLogo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <path d="M 50 50 Q 30 30 20 15 Q 35 25 50 50 Z" fill="#4A90E2" opacity="0.95" />
      <path d="M 50 50 Q 70 30 80 15 Q 65 25 50 50 Z" fill="#F39C12" opacity="0.95" />
      <path d="M 50 50 Q 75 55 88 55 Q 70 60 50 50 Z" fill="#F4D03F" opacity="0.95" />
      <path d="M 50 50 Q 50 75 50 90 Q 45 70 50 50 Z" fill="#2ECC71" opacity="0.95" />
      <path d="M 50 50 Q 25 55 12 55 Q 30 60 50 50 Z" fill="#9B59B6" opacity="0.95" />
      <circle cx="50" cy="50" r="6" fill="#1a1d21" />
    </svg>
  )
}

interface NavItem {
  path: string
  viewId: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  badge?: string
  section?: string
}

const NAV_ITEMS: NavItem[] = [
  { path: '/', viewId: 'home', label: 'Command Home', icon: Home, section: 'Overview' },
  { path: '/monitored-targets', viewId: 'monitored_targets', label: 'Monitored Targets', icon: Network, section: 'Overview' },
  { path: '/attack-surface', viewId: 'attack_surface', label: 'Attack Surface', icon: Globe, section: 'Overview' },
  { path: '/exposure', viewId: 'exposure', label: 'Exposure Management', icon: Crosshair, section: 'Overview' },
  { path: '/projects', viewId: 'projects', label: 'Projects (SDK)', icon: LayoutDashboard, section: 'Connected Sites' },
  { path: '/traffic', viewId: 'traffic', label: 'Traffic Overview', icon: Activity, section: 'Connected Sites' },
  { path: '/live-logs', viewId: 'live_logs', label: 'Live Logs', icon: Activity, section: 'Connected Sites' },
  { path: '/reports', viewId: 'reports', label: 'Reports & Dashboards', icon: BarChart3, section: 'Detection' },
  { path: '/response', viewId: 'response', label: 'Response & Remediation', icon: Activity, section: 'Detection' },
  { path: '/alerts', viewId: 'alerts', label: 'Alerts', icon: Siren, badge: 'live', section: 'Detection' },
  { path: '/intelligence', viewId: 'intelligence', label: 'Intelligence', icon: BrainCircuit, section: 'Configuration' },
  { path: '/controls', viewId: 'controls', label: 'Controls & Compliance', icon: ShieldCheck, section: 'Configuration' },
  { path: '/connectors', viewId: 'connectors', label: 'Data Sources & Blocklist', icon: Plug, section: 'Configuration' },
  { path: '/automation', viewId: 'automation', label: 'Automation', icon: Bot, section: 'Configuration' },
  { path: '/ai-providers', viewId: 'ai_config', label: 'AI Providers', icon: KeyRound, section: 'Configuration' },
  { path: '/telegram', viewId: 'telegram', label: 'Telegram Bot', icon: Send, section: 'Configuration' },
  { path: '/admin', viewId: 'admin', label: 'Administration', icon: Settings, section: 'Configuration' },
]

export function Sidebar({ activeView, onNavigate }: {
  activeView: string
  onNavigate: (path: string) => void
}) {
  const sections: Record<string, NavItem[]> = {}
  for (const item of NAV_ITEMS) {
    const s = item.section || 'Other'
    if (!sections[s]) sections[s] = []
    sections[s].push(item)
  }

  return (
    <aside className="w-60 shrink-0 border-r border-[#2e3236] bg-[#1a1d21] flex flex-col">
      <div className="h-14 flex items-center px-5 border-b border-[#2e3236]">
        <button onClick={() => onNavigate('/')} className="flex items-center gap-2.5">
          <BloomLogo size={36} />
          <span className="text-[18px] font-bold text-white tracking-tight">Bloom</span>
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2">
        {Object.entries(sections).map(([section, items]) => (
          <div key={section}>
            <div className="px-3 mt-4 mb-1.5 text-[10px] uppercase tracking-wider text-[#6b7075] font-semibold">
              {section}
            </div>
            {items.map((item) => {
              const active = activeView === item.viewId
              const Icon = item.icon
              return (
                <button
                  key={item.path}
                  onClick={() => onNavigate(item.path)}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-2 rounded-md text-[13px] transition-all mb-0.5 group',
                    active
                      ? 'bg-[#2a2d31] text-white font-medium'
                      : 'text-[#8e9296] hover:bg-[#232629] hover:text-white'
                  )}
                >
                  <Icon
                    className={cn(
                      'w-4 h-4 shrink-0',
                      active ? 'text-[#f39c12]' : 'text-[#8e9296] group-hover:text-white'
                    )}
                  />
                  <span className="flex-1 text-left truncate">{item.label}</span>
                  {item.badge === 'live' && (
                    <span className="flex items-center gap-1 text-[10px] text-[#2ecc71]">
                      <span className="relative w-1.5 h-1.5">
                        <span className="absolute inset-0 rounded-full bg-[#2ecc71] bloom-pulse" />
                      </span>
                      LIVE
                    </span>
                  )}
                </button>
              )
            })}
          </div>
        ))}
      </nav>

      <div className="px-4 py-3 border-t border-[#2e3236]">
        <div className="flex items-center gap-2 text-[11px] text-[#8e9296]">
          <span className="relative w-2 h-2">
            <span className="absolute inset-0 rounded-full bg-[#2ecc71] bloom-pulse" />
          </span>
          <span>All systems operational</span>
        </div>
        <div className="text-[10px] text-[#6b7075] mt-1 pl-4">v2.7.0</div>
      </div>
    </aside>
  )
}
