'use client'

import { useEffect, useState } from 'react'
import {
  BrainCircuit, ShieldCheck, ShieldAlert, ShieldX, AlertTriangle,
  Loader2, Sparkles, TrendingUp, ChevronRight, CheckCircle2,
} from 'lucide-react'
import { toast } from 'sonner'

interface AnalystVerdict {
  id: string
  verdict: 'auto_contain' | 'safe' | 'high_risk' | 'critical'
  confidence: number
  summary: string
  rationale: string
  recommendedActions: string[]
  keyFindings: string[]
  provider: string
  model: string
  createdAt: string
}

const VERDICT_META: Record<string, { icon: React.ComponentType<{ className?: string }>; color: string; bg: string; label: string; description: string }> = {
  safe: {
    icon: ShieldCheck,
    color: 'text-[#2ecc71]',
    bg: 'bg-[#2ecc71]/10 border-[#2ecc71]/30',
    label: 'Safe',
    description: 'Benign activity — no action required',
  },
  auto_contain: {
    icon: ShieldAlert,
    color: 'text-[#f4b733]',
    bg: 'bg-[#f4b733]/10 border-[#f4b733]/30',
    label: 'Auto-Contain',
    description: 'Threat is real but contained — monitor only',
  },
  high_risk: {
    icon: ShieldX,
    color: 'text-[#f39c12]',
    bg: 'bg-[#f39c12]/10 border-[#f39c12]/30',
    label: 'High Risk Activity',
    description: 'Active threat — immediate response required',
  },
  critical: {
    icon: AlertTriangle,
    color: 'text-[#e74c3c]',
    bg: 'bg-[#e74c3c]/10 border-[#e74c3c]/30',
    label: 'Critical — Confirmed Breach',
    description: 'Confirmed compromise — page SOC immediately',
  },
}

export function AnalystVerdictPanel({
  alertId,
  investigationId,
}: {
  alertId?: string
  investigationId?: string
}) {
  const [verdict, setVerdict] = useState<AnalystVerdict | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const loadExisting = async () => {
    if (!alertId && !investigationId) return
    try {
      const params = new URLSearchParams()
      if (alertId) params.set('alertId', alertId)
      if (investigationId) params.set('investigationId', investigationId)
      const res = await fetch(`/api/ai-analyst?${params}`)
      if (res.ok) {
        const d = await res.json()
        if (d.verdict) {
          setVerdict({
            ...d.verdict,
            recommendedActions: JSON.parse(d.verdict.recommendedActions || '[]'),
            keyFindings: JSON.parse(d.verdict.keyFindings || '[]'),
          })
        }
      }
    } catch {
      // ignore
    }
  }

  useEffect(() => {
    setVerdict(null)
    setError(null)
    loadExisting()
  }, [alertId, investigationId])

  const generate = async (force = false) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/ai-analyst', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alertId, investigationId, force }),
      })
      if (!res.ok) {
        const d = await res.json().catch(() => ({}))
        throw new Error(d.error || `HTTP ${res.status}`)
      }
      const d = await res.json()
      if (d.verdict) {
        setVerdict({
          ...d.verdict,
          recommendedActions: JSON.parse(d.verdict.recommendedActions || '[]'),
          keyFindings: JSON.parse(d.verdict.keyFindings || '[]'),
        })
        toast.success(d.cached ? 'Loaded cached verdict' : `AI verdict generated (${d.verdict.confidence}% confidence)`)
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to generate verdict'
      setError(msg)
      toast.error(`AI Analyst: ${msg}`)
    } finally {
      setLoading(false)
    }
  }

  const meta = verdict ? VERDICT_META[verdict.verdict] || VERDICT_META.high_risk : null
  const VerdictIcon = meta?.icon

  return (
    <div className={`rounded-md border ${verdict && meta ? meta.bg : 'bg-[#1a1d21] border-[#2e3236]'}`}>
      {/* Header */}
      <div className="px-4 py-3 border-b border-[#2e3236]/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-4 h-4 text-[#f39c12]" />
          <span className="text-[13px] font-semibold text-white">Bloom AI SOC</span>
          {verdict && (
            <span className="text-[10px] text-[#6b7075] px-1.5 py-0.5 bg-[#2a2d31] rounded">
              {verdict.provider} · {verdict.model}
            </span>
          )}
        </div>
        {verdict && (
          <button
            onClick={() => generate(true)}
            disabled={loading}
            className="text-[10px] text-[#f39c12] hover:underline flex items-center gap-1 disabled:opacity-50"
          >
            <Sparkles className="w-3 h-3" />
            {loading ? 'Re-analyzing...' : 'Re-analyze'}
          </button>
        )}
      </div>

      {/* Body */}
      {!verdict && !loading && !error && (
        <div className="p-6 text-center">
          <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-[#2a2d31] flex items-center justify-center">
            <BrainCircuit className="w-6 h-6 text-[#8e9296]" />
          </div>
          <div className="text-[13px] text-white font-medium mb-1">AI Analyst Verdict</div>
          <p className="text-[11px] text-[#8e9296] mb-4 max-w-xs mx-auto">
            Generate an AI-powered verdict with confidence score, summary, rationale, and recommended actions.
          </p>
          <button
            onClick={() => generate(false)}
            disabled={loading}
            className="inline-flex items-center gap-2 bg-[#f39c12] hover:bg-[#e67e22] text-[#1a1d21] font-medium text-[12px] px-4 py-2 rounded transition-colors disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Generate AI Verdict
          </button>
        </div>
      )}

      {loading && (
        <div className="p-8 text-center">
          <Loader2 className="w-6 h-6 mx-auto mb-3 text-[#f39c12] animate-spin" />
          <div className="text-[12px] text-[#8e9296]">Analyzing alert context…</div>
          <div className="text-[10px] text-[#6b7075] mt-1">
            Gathering logs, prior actions, MITRE context
          </div>
        </div>
      )}

      {error && !loading && (
        <div className="p-4">
          <div className="bg-[#e74c3c]/10 border border-[#e74c3c]/30 rounded p-3 text-[11px] text-[#e74c3c] mb-3">
            <strong>Generation failed:</strong> {error}
          </div>
          <button
            onClick={() => generate(true)}
            className="w-full bg-[#2a2d31] hover:bg-[#3a3e42] text-white text-[11px] py-2 rounded"
          >
            Try Again
          </button>
        </div>
      )}

      {verdict && meta && VerdictIcon && !loading && (
        <div className="p-4 space-y-4">
          {/* Verdict + confidence */}
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-full ${meta.bg} flex items-center justify-center shrink-0`}>
              <VerdictIcon className={`w-5 h-5 ${meta.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <span className={`text-[15px] font-bold ${meta.color}`}>{meta.label}</span>
                <span className="text-[10px] text-[#6b7075]">·</span>
                <span className="text-[11px] text-[#8e9296]">
                  confidence {verdict.confidence}%
                </span>
              </div>
              <div className="text-[11px] text-[#8e9296]">{meta.description}</div>
              {/* Confidence bar */}
              <div className="mt-2 h-1.5 bg-[#2a2d31] rounded overflow-hidden">
                <div
                  className={`h-full rounded ${verdict.confidence >= 75 ? 'bg-[#2ecc71]' : verdict.confidence >= 50 ? 'bg-[#f4b733]' : 'bg-[#e74c3c]'}`}
                  style={{ width: `${verdict.confidence}%` }}
                />
              </div>
            </div>
          </div>

          {/* Verdict action chips */}
          <div className="flex flex-wrap gap-1.5">
            {(verdict.verdict === 'high_risk' || verdict.verdict === 'critical') && (
              <>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#f39c12] text-[#1a1d21] font-medium">Auto-contain</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#2a2d31] text-[#8e9296]">Escalate</span>
              </>
            )}
            {verdict.verdict === 'auto_contain' && (
              <>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#2ecc71] text-[#1a1d21] font-medium">Safe to contain</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#2a2d31] text-[#8e9296]">Monitor</span>
              </>
            )}
            {verdict.verdict === 'safe' && (
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#2a2d31] text-[#8e9296]">No action</span>
            )}
          </div>

          {/* Summary */}
          <div>
            <div className="text-[10px] uppercase tracking-wide text-[#6b7075] mb-1.5 font-medium">Summary</div>
            <p className="text-[12px] text-[#e8e9ea] leading-relaxed">{verdict.summary}</p>
          </div>

          {/* Rationale */}
          <div>
            <div className="text-[10px] uppercase tracking-wide text-[#6b7075] mb-1.5 font-medium">Rationale</div>
            <p className="text-[12px] text-[#b0b3b8] leading-relaxed">{verdict.rationale}</p>
          </div>

          {/* Key findings + recommended actions in two columns */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <div className="text-[10px] uppercase tracking-wide text-[#6b7075] mb-1.5 font-medium">Key Findings</div>
              <ul className="space-y-1">
                {verdict.keyFindings.map((f, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-[11px] text-[#b0b3b8]">
                    <ChevronRight className="w-3 h-3 mt-0.5 text-[#f39c12] shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wide text-[#6b7075] mb-1.5 font-medium">Recommended Actions</div>
              <ul className="space-y-1">
                {verdict.recommendedActions.map((a, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-[11px] text-[#b0b3b8]">
                    <CheckCircle2 className="w-3 h-3 mt-0.5 text-[#2ecc71] shrink-0" />
                    <span>{a}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-2 border-t border-[#2e3236]/50 flex items-center justify-between text-[10px] text-[#6b7075]">
            <span className="flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Generated {new Date(verdict.createdAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </span>
            <span className="font-mono">{verdict.provider}/{verdict.model}</span>
          </div>
        </div>
      )}
    </div>
  )
}
