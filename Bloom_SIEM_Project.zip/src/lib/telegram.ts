import { db } from '@/lib/db'

export async function notifyTelegram(message: string, opts?: { requireApproval?: boolean; callbackData?: string }): Promise<boolean> {
  const config = await db.telegramConfig.findFirst()
  if (!config || !config.enabled) return false
  try {
    const body: Record<string, unknown> = { chat_id: config.chatId, text: message, parse_mode: 'HTML' }
    if (opts?.requireApproval) {
      body.reply_markup = { inline_keyboard: [[{ text: '✅ Approve', callback_data: opts.callbackData || 'bloom_approve' }, { text: '❌ Deny', callback_data: 'bloom_deny' }]] }
    }
    const res = await fetch(`https://api.telegram.org/bot${config.botToken}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(5000),
    })
    const data = await res.json()
    return Boolean(data.ok)
  } catch { return false }
}
