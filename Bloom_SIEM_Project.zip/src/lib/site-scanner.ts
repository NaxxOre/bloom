import { db } from '@/lib/db'
import { chromium } from 'playwright'

export interface SiteScanResult {
  url: string
  routes: { path: string; method: string; statusCode: number; accessible: boolean }[]
  forms: { action: string; method: string; fields: { name: string; type: string; required: boolean; placeholder: string | null }[] }[]
  buttons: { text: string; href: string | null; type: string }[]
  links: { href: string; text: string }[]
  inputs: { name: string; type: string; required: boolean; placeholder: string | null; id: string | null; class: string | null }[]
  title: string
  metaDescription: string | null
  scanDuration: number
  crawledPages: number
  isSpa: boolean
}

/**
 * Deep crawl using Playwright (headless Chromium).
 * Renders the page with JavaScript, clicks buttons to discover hidden content,
 * and extracts ALL elements from the rendered DOM — not just static HTML.
 */
export async function scanSite(baseUrl: string): Promise<SiteScanResult> {
  const startTime = Date.now()
  const url = baseUrl.startsWith('http') ? baseUrl : `https://${baseUrl}`
  const origin = new URL(url).origin

  let browser
  try {
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] })
  } catch {
    // Fallback to static fetch if Playwright can't launch
    return staticScan(url, startTime)
  }

  const context = await browser.newContext({
    userAgent: 'Bloom-SIEM-Crawler/1.0',
    viewport: { width: 1280, height: 720 },
  })
  const page = await context.newPage()

  const allForms: SiteScanResult['forms'] = []
  const allButtons: { text: string; href: string | null; type: string }[] = []
  const allLinks: { href: string; text: string }[] = []
  const allInputs: SiteScanResult['inputs'] = []
  const allRoutes: { path: string; method: string; statusCode: number; accessible: boolean }[] = []
  const visitedUrls = new Set<string>()
  let title = ''
  let metaDescription: string | null = null
  let isSpa = false

  try {
    // Navigate to homepage
    const response = await page.goto(url, { waitUntil: 'networkidle', timeout: 20000 })
    const statusCode = response?.status() || 0
    await page.waitForTimeout(2000) // Wait for JS frameworks to render

    title = await page.title()
    allRoutes.push({ path: '/', method: 'GET', statusCode, accessible: statusCode < 400 })

    // Check if it's a SPA (empty body in static HTML but content after JS)
    const staticHtml = await page.content()
    if (staticHtml.includes('<div id="root"></div>') || staticHtml.includes('<div id="app"></div>') || staticHtml.includes('<div id="__next"></div>')) {
      isSpa = true
    }

    // Extract meta description
    metaDescription = await page.evaluate(() => {
      const meta = document.querySelector('meta[name="description"]')
      return meta?.getAttribute('content') || null
    }).catch(() => null)

    // Extract elements from the rendered page
    const extracted = await extractFromPage(page, origin)
    allForms.push(...extracted.forms)
    allButtons.push(...extracted.buttons)
    allLinks.push(...extracted.links)
    allInputs.push(...extracted.inputs)

    // If it's a SPA, try clicking buttons to discover hidden content (forms/inputs that appear after interaction)
    if (isSpa || extracted.buttons.length > 0) {
      // Click each visible button (up to 5) to discover hidden forms/inputs
      const clickButtons = extracted.buttons.filter(b => b.text && b.text.length > 2 && b.text.length < 40).slice(0, 5)
      for (const btn of clickButtons) {
        try {
          // Try to find and click the button by text
          const locator = page.getByText(btn.text, { exact: true }).first()
          if (await locator.isVisible({ timeout: 1000 })) {
            await locator.click({ timeout: 3000 })
            await page.waitForTimeout(1500) // Wait for new content to render

            // Extract elements from the new view
            const afterClick = await extractFromPage(page, origin)
            // Only add new elements we haven't seen
            for (const f of afterClick.forms) if (!allForms.some(af => af.action === f.action)) allForms.push(f)
            for (const i of afterClick.inputs) if (!allInputs.some(ai => ai.name === i.name)) allInputs.push(i)
            for (const b of afterClick.buttons) if (!allButtons.some(ab => ab.text === b.text)) allButtons.push(b)
            for (const l of afterClick.links) if (!allLinks.some(al => al.href === l.href)) allLinks.push(l)

            // Go back to homepage for the next button click
            await page.goBack({ waitUntil: 'networkidle', timeout: 10000 }).catch(() => {})
            await page.waitForTimeout(1000)
          }
        } catch { /* skip if button can't be clicked */ }
      }
    }

    // Crawl internal links (up to 5)
    const internalLinks = allLinks
      .filter(l => l.href.startsWith(origin) || l.href.startsWith('/'))
      .map(l => l.href.startsWith('/') ? origin + l.href : l.href)
      .filter(href => !href.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|woff|pdf)$/i))
      .filter(href => !visitedUrls.has(href))
      .slice(0, 5)

    for (const linkUrl of internalLinks) {
      if (visitedUrls.has(linkUrl)) continue
      visitedUrls.add(linkUrl)
      try {
        const res = await page.goto(linkUrl, { waitUntil: 'networkidle', timeout: 10000 })
        await page.waitForTimeout(1500)
        const path = new URL(page.url()).pathname
        if (!allRoutes.some(r => r.path === path)) {
          allRoutes.push({ path, method: 'GET', statusCode: res?.status() || 0, accessible: (res?.status() || 0) < 400 })
        }
        const linkExtracted = await extractFromPage(page, origin)
        for (const f of linkExtracted.forms) if (!allForms.some(af => af.action === f.action)) allForms.push(f)
        for (const i of linkExtracted.inputs) if (!allInputs.some(ai => ai.name === i.name)) allInputs.push(i)
        for (const b of linkExtracted.buttons) if (!allButtons.some(ab => ab.text === b.text)) allButtons.push(b)
        for (const l of linkExtracted.links) if (!allLinks.some(al => al.href === l.href)) allLinks.push(l)
      } catch { /* skip inaccessible pages */ }
    }

  } catch (err) {
    // If Playwright fails entirely, fall back to static scan
    await browser.close()
    return staticScan(url, startTime)
  }

  await browser.close()

  // Deduplicate
  const uniqueButtons = dedupe(allButtons, 'text')
  const uniqueForms = dedupe(allForms, 'action')
  const uniqueInputs = dedupe(allInputs, 'name')
  const uniqueLinks = Array.from(new Map(allLinks.map(l => [l.href, l])).values())

  return {
    url, routes: allRoutes, forms: uniqueForms, buttons: uniqueButtons,
    links: uniqueLinks.slice(0, 50), inputs: uniqueInputs,
    title, metaDescription, scanDuration: Date.now() - startTime,
    crawledPages: allRoutes.length, isSpa,
  }
}

async function extractFromPage(page: import('playwright').Page, origin: string) {
  return page.evaluate((origin) => {
    const forms: { action: string; method: string; fields: { name: string; type: string; required: boolean; placeholder: string | null }[] }[] = []
    const buttons: { text: string; href: string | null; type: string }[] = []
    const links: { href: string; text: string }[] = []
    const inputs: { name: string; type: string; required: boolean; placeholder: string | null; id: string | null; class: string | null }[] = []

    // Extract forms
    document.querySelectorAll('form').forEach(form => {
      const action = form.getAttribute('action') || '(same page)'
      const method = (form.getAttribute('method') || 'GET').toUpperCase()
      const fields: { name: string; type: string; required: boolean; placeholder: string | null }[] = []
      form.querySelectorAll('input, textarea, select').forEach(inp => {
        const name = inp.getAttribute('name') || inp.getAttribute('id') || inp.getAttribute('placeholder') || ''
        if (name) fields.push({
          name,
          type: inp.getAttribute('type') || (inp.tagName.toLowerCase() === 'textarea' ? 'textarea' : 'text'),
          required: inp.hasAttribute('required'),
          placeholder: inp.getAttribute('placeholder'),
        })
      })
      forms.push({ action, method, fields })
    })

    // Extract ALL inputs (including standalone ones not in forms — common in React/Vue)
    document.querySelectorAll('input').forEach(inp => {
      const name = inp.getAttribute('name') || inp.getAttribute('id') || inp.getAttribute('placeholder') || ''
      if (name) inputs.push({
        name,
        type: inp.getAttribute('type') || 'text',
        required: inp.hasAttribute('required'),
        placeholder: inp.getAttribute('placeholder'),
        id: inp.getAttribute('id'),
        class: inp.getAttribute('class'),
      })
    })

    // Extract buttons
    const seenBtns = new Set<string>()
    document.querySelectorAll('button').forEach(btn => {
      const text = btn.textContent?.trim().slice(0, 50) || ''
      if (text && !seenBtns.has(text)) { seenBtns.add(text); buttons.push({ text, href: null, type: 'button' }) }
    })
    document.querySelectorAll('input[type="submit"]').forEach(btn => {
      const text = btn.getAttribute('value') || 'Submit'
      if (!seenBtns.has(text)) { seenBtns.add(text); buttons.push({ text, href: null, type: 'submit' }) }
    })
    document.querySelectorAll('[role="button"], [class*="btn"], [class*="button"]').forEach(btn => {
      const text = btn.textContent?.trim().slice(0, 50) || ''
      if (text && !seenBtns.has(text)) { seenBtns.add(text); buttons.push({ text, href: null, type: 'role-button' }) }
    })

    // Extract links
    const seenLinks = new Set<string>()
    document.querySelectorAll('a[href]').forEach(a => {
      const href = a.getAttribute('href') || ''
      const text = a.textContent?.trim().slice(0, 50) || ''
      if (href && text && !href.startsWith('#') && !href.startsWith('mailto:') && !href.startsWith('tel:') && !href.startsWith('javascript:') && !seenLinks.has(href)) {
        seenLinks.add(href)
        links.push({ href, text })
      }
    })

    return { forms, buttons, links, inputs }
  }, origin)
}

function dedupe<T>(arr: T[], key: keyof T): T[] {
  const seen = new Set<string>()
  return arr.filter(item => {
    const k = String(item[key])
    if (seen.has(k)) return false
    seen.add(k)
    return true
  })
}

// Fallback: static HTML scan (no JavaScript rendering)
async function staticScan(url: string, startTime: number): Promise<SiteScanResult> {
  let html = ''
  let statusCode = 0
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(15000), headers: { 'User-Agent': 'Bloom-SIEM-Crawler/1.0' }, redirect: 'follow' })
    statusCode = res.status
    html = await res.text()
  } catch {
    return { url, routes: [], forms: [], buttons: [], links: [], inputs: [], title: 'Scan failed', metaDescription: null, scanDuration: Date.now() - startTime, crawledPages: 0, isSpa: false }
  }
  const title = html.match(/<title[^>]*>(.*?)<\/title>/is)?.[1]?.trim() || url
  return { url, routes: [{ path: '/', method: 'GET', statusCode, accessible: statusCode < 400 }], forms: [], buttons: [], links: [], inputs: [], title, metaDescription: null, scanDuration: Date.now() - startTime, crawledPages: 1, isSpa: html.includes('<div id="root"></div>') || html.includes('<div id="app"></div>') }
}

export async function scanAndStoreProject(projectId: string): Promise<SiteScanResult> {
  const project = await db.project.findUnique({ where: { id: projectId } })
  if (!project) throw new Error('Project not found')
  const domain = project.domain.startsWith('http') ? project.domain : `https://${project.domain}`
  const result = await scanSite(domain)

  const events = []

  // Store discovered routes
  for (const route of result.routes) {
    events.push({
      projectId, method: route.method, path: route.path, host: project.domain,
      ip: '0.0.0.0', userAgent: 'Bloom-SIEM-Crawler/1.0',
      action: route.accessible ? 'allowed' : 'denied',
      rule: route.accessible ? null : 'Route not accessible',
      statusCode: route.statusCode, responseTime: 0, inputSnippet: null,
    })
  }

  // Store discovered form fields
  for (const form of result.forms) {
    for (const field of form.fields) {
      events.push({
        projectId, method: form.method, path: form.action || '/', host: project.domain,
        ip: '0.0.0.0', userAgent: 'Bloom-SIEM-Crawler/1.0',
        action: 'logged', rule: null, statusCode: 200, responseTime: 0,
        inputSnippet: JSON.stringify({ [field.name]: '', _type: field.type, _required: field.required, _placeholder: field.placeholder }),
      })
    }
  }

  // Store standalone inputs
  for (const input of result.inputs) {
    const alreadyInForm = result.forms.some(f => f.fields.some(ff => ff.name === input.name))
    if (!alreadyInForm) {
      events.push({
        projectId, method: 'GET', path: '/', host: project.domain,
        ip: '0.0.0.0', userAgent: 'Bloom-SIEM-Crawler/1.0',
        action: 'logged', rule: null, statusCode: 200, responseTime: 0,
        inputSnippet: JSON.stringify({ [input.name]: '', _type: input.type, _required: input.required, _placeholder: input.placeholder }),
      })
    }
  }

  // Store discovered buttons
  for (const button of result.buttons) {
    events.push({
      projectId, method: 'GET', path: button.href || '/', host: project.domain,
      ip: '0.0.0.0', userAgent: 'Bloom-SIEM-Crawler/1.0',
      action: 'logged', rule: null, statusCode: 200, responseTime: 0,
      inputSnippet: `click:${button.text}`,
    })
  }

  if (events.length > 0) {
    await db.siteEvent.createMany({ data: events.slice(0, 200) })
  }
  await db.project.update({ where: { id: projectId }, data: { status: 'connected', lastEventAt: new Date() } })
  return result
}
