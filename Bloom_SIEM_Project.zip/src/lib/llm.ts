import ZAI from 'z-ai-web-dev-sdk'
import { db } from '@/lib/db'

export interface LLMProvider {
  provider: string
  model: string
  apiKey: string
  baseUrl?: string | null
}

let zaiInstance: ZAI | null = null
async function getZai(): Promise<ZAI> {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create()
  }
  return zaiInstance
}

/**
 * Get the configured/default AI provider.
 * Falls back to ZAI (built-in to sandbox) if none configured.
 */
export async function getDefaultProvider(): Promise<LLMProvider> {
  const providers = await db.aIProvider.findMany({
    where: { enabled: true, NOT: { apiKey: '' } },
    orderBy: [{ isDefault: 'desc' }, { updatedAt: 'desc' }],
  })

  if (providers.length === 0) {
    // Fall back to built-in ZAI (auto-configured in this sandbox)
    const zai = await db.aIProvider.findFirst({
      where: { provider: 'zai', isDefault: true },
    })
    if (zai) {
      return {
        provider: zai.provider,
        model: zai.model,
        apiKey: zai.apiKey,
        baseUrl: zai.baseUrl,
      }
    }
  }

  const p = providers[0]
  return {
    provider: p.provider,
    model: p.model,
    apiKey: p.apiKey,
    baseUrl: p.baseUrl,
  }
}

/**
 * Run a chat completion. Uses ZAI SDK for the built-in zai provider.
 * For OpenAI/Anthropic/Groq/Mistral, calls their OpenAI-compatible APIs.
 */
export async function runChat(
  messages: { role: 'system' | 'user' | 'assistant'; content: string }[],
  opts: { temperature?: number; maxTokens?: number } = {}
): Promise<{ content: string; provider: string; model: string }> {
  const provider = await getDefaultProvider()

  // Built-in ZAI provider — use SDK
  if (provider.provider === 'zai') {
    const zai = await getZai()
    const response = await zai.chat.completions.create({
      messages,
      temperature: opts.temperature ?? 0.4,
      max_tokens: opts.maxTokens ?? 1200,
    })
    return {
      content: response.choices[0]?.message?.content || '',
      provider: 'zai',
      model: provider.model,
    }
  }

  // OpenAI-compatible providers
  const baseUrl = provider.baseUrl?.replace(/\/$/, '') || 'https://api.openai.com/v1'
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${provider.apiKey}`,
  }
  // Anthropic uses different auth header
  if (provider.provider === 'anthropic') {
    headers['x-api-key'] = provider.apiKey
    headers['anthropic-version'] = '2023-06-01'
    delete headers.Authorization
  }

  const body: Record<string, unknown> = {
    model: provider.model,
    messages,
    temperature: opts.temperature ?? 0.4,
    max_tokens: opts.maxTokens ?? 1200,
  }

  const url = provider.provider === 'anthropic'
    ? `${baseUrl}/messages`
    : `${baseUrl}/chat/completions`

  const res = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  })

  if (!res.ok) {
    const err = await res.text()
    throw new Error(`LLM API error (${res.status}): ${err.slice(0, 300)}`)
  }

  const data = await res.json()
  const content = provider.provider === 'anthropic'
    ? data.content?.[0]?.text
    : data.choices?.[0]?.message?.content

  return { content: content || '', provider: provider.provider, model: provider.model }
}

/**
 * Generate an AI analyst verdict for an alert or investigation.
 * Returns structured JSON: verdict, confidence, summary, rationale, recommendedActions, keyFindings.
 */
export async function generateAnalystVerdict(params: {
  alertId?: string
  investigationId?: string
}): Promise<{
  verdict: 'auto_contain' | 'safe' | 'high_risk' | 'critical'
  confidence: number
  summary: string
  rationale: string
  recommendedActions: string[]
  keyFindings: string[]
  provider: string
  model: string
}> {
  // Gather context
  let alert = null
  let investigation = null
  if (params.alertId) {
    alert = await db.alert.findUnique({ where: { id: params.alertId } })
  }
  if (params.investigationId) {
    investigation = await db.investigation.findUnique({ where: { id: params.investigationId } })
    if (investigation?.alertId && !alert) {
      alert = await db.alert.findUnique({ where: { id: investigation.alertId } })
    }
  }

  if (!alert && !investigation) {
    throw new Error('No alert or investigation found')
  }

  // Gather related logs and recent actions for context
  const recentLogs = alert?.srcIp
    ? await db.log.findMany({
        where: { OR: [{ srcIp: alert.srcIp }, { dstIp: alert.srcIp }] },
        take: 10,
        orderBy: { timestamp: 'desc' },
      })
    : []

  const recentActions = await db.autoAction.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    where: { OR: [{ alertId: alert?.id }, { target: alert?.srcIp }] },
  })

  // Build the prompt
  const systemPrompt = `You are Bloom AI SOC, an expert security operations analyst. You analyze security alerts and provide structured verdicts.

Always respond with valid JSON only (no markdown, no explanations outside the JSON) in this exact schema:
{
  "verdict": "auto_contain" | "safe" | "high_risk" | "critical",
  "confidence": <0-100 integer>,
  "summary": "<one sentence summary of the activity>",
  "rationale": "<2-4 sentence explanation of why this verdict was reached>",
  "recommendedActions": ["<action 1>", "<action 2>", ...],
  "keyFindings": ["<finding 1>", "<finding 2>", ...]
}

Guidelines:
- "auto_contain" = threat is real but contained; no immediate escalation needed
- "safe" = benign / false positive; no action needed
- "high_risk" = active threat requiring immediate response
- "critical" = confirmed breach, page SOC immediately
- confidence should reflect certainty in the verdict (e.g. 70-95 for clear cases, 30-60 for ambiguous)
- recommendedActions: 2-5 concrete steps (block IP, isolate host, disable user, escalate, etc.)
- keyFindings: 2-4 specific observations that drove the verdict`

  const userPrompt = `Analyze this security alert:

ALERT:
- Title: ${alert?.title || investigation?.title || 'Unknown'}
- Severity: ${alert?.severity || investigation?.severity || 'unknown'}
- MITRE Tactic: ${alert?.mitreTactic || 'unknown'}
- MITRE Technique: ${alert?.mitreTechnique || 'unknown'}
- Source IP: ${alert?.srcIp || 'unknown'}
- Source: ${alert?.source || 'unknown'}
- Detected By: ${alert?.triggeredBy || 'unknown'}
- Description: ${alert?.description || investigation?.summary || 'No description'}

RELATED LOGS (most recent first):
${recentLogs.length > 0
  ? recentLogs.map((l) => `  - [${l.severity}] ${l.source} · ${l.message} · src=${l.srcIp || '-'} dst=${l.dstIp || '-'} port=${l.dstPort || '-'}`).join('\n')
  : '  (no related logs found)'
}

PRIOR ACTIONS:
${recentActions.length > 0
  ? recentActions.map((a) => `  - ${a.action} → ${a.target} (${a.status}, by ${a.initiatedBy})`).join('\n')
  : '  (no prior actions)'
}

Provide your verdict as JSON.`

  try {
    const result = await runChat(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      { temperature: 0.3, maxTokens: 900 }
    )

    // Parse JSON from response (strip any markdown fences)
    let content = result.content.trim()
    if (content.startsWith('```')) {
      content = content.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '')
    }
    const parsed = JSON.parse(content)

    return {
      verdict: parsed.verdict || 'high_risk',
      confidence: Math.min(100, Math.max(0, Number(parsed.confidence) || 50)),
      summary: parsed.summary || 'No summary provided.',
      rationale: parsed.rationale || 'No rationale provided.',
      recommendedActions: Array.isArray(parsed.recommendedActions) ? parsed.recommendedActions : [],
      keyFindings: Array.isArray(parsed.keyFindings) ? parsed.keyFindings : [],
      provider: result.provider,
      model: result.model,
    }
  } catch (err) {
    // Fallback rule-based verdict if LLM fails
    console.error('[AI Analyst] LLM call failed, using rule-based fallback:', err)
    const sev = alert?.severity || 'medium'
    const verdict =
      sev === 'critical' ? 'critical' :
      sev === 'high' ? 'high_risk' :
      sev === 'medium' ? 'auto_contain' : 'safe'
    return {
      verdict: verdict as 'auto_contain' | 'safe' | 'high_risk' | 'critical',
      confidence: sev === 'critical' ? 92 : sev === 'high' ? 78 : sev === 'medium' ? 62 : 45,
      summary: `${alert?.title || 'Alert'} — severity ${sev}, source ${alert?.srcIp || 'unknown'}.`,
      rationale: `Rule-based fallback verdict (LLM unavailable). Alert matches pattern for ${alert?.mitreTactic || 'unknown'} tactic. Severity drives the verdict.`,
      recommendedActions: [
        sev === 'critical' || sev === 'high' ? `Block source IP ${alert?.srcIp}` : 'Monitor source IP for 24h',
        alert?.agentId ? 'Isolate affected host' : 'Verify affected assets',
        'Create investigation ticket',
        'Notify SOC team',
      ],
      keyFindings: [
        `Severity: ${sev}`,
        `MITRE tactic: ${alert?.mitreTactic || 'unknown'}`,
        `Source IP: ${alert?.srcIp || 'unknown'}`,
        `Triggered by: ${alert?.triggeredBy || 'unknown'}`,
      ],
      provider: 'rule-based',
      model: 'fallback',
    }
  }
}
