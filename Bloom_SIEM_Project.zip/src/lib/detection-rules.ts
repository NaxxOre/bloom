import { db } from '@/lib/db'
import { notifyTelegram } from '@/lib/telegram'
import { generateAnalystVerdict } from '@/lib/llm'

// MITRE ATT&CK mapped detection rules
// Each rule: condition → detect → MITRE map → AI score → playbook response
export interface DetectionRule {
  id: string
  name: string
  description: string
  tactic: string
  techniqueId: string
  techniqueName: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  // Detection condition
  check: (events: SiteEventInput[]) => DetectionMatch[]
  // Playbook (automated response steps)
  playbook: {
    blockIp?: boolean
    revokeSession?: boolean
    telegramAlert?: boolean
    aiAnalysis?: boolean
    quarantineFile?: boolean
  }
}

interface SiteEventInput {
  ip: string
  path: string
  method: string
  userAgent: string | null
  inputSnippet: string | null
  fileName: string | null
  fileVerdict: string | null
  sessionId: string | null
  statusCode: number | null
  timestamp: Date
}

interface DetectionMatch {
  ruleId: string
  ip: string
  details: string
  events: SiteEventInput[]
}

export const DETECTION_RULES: DetectionRule[] = [
  {
    id: 'BRUTE_FORCE_001',
    name: 'Multiple Failed Login Attempts',
    description: 'Detects repeated failed login attempts from the same IP address.',
    tactic: 'Credential Access',
    techniqueId: 'T1110',
    techniqueName: 'Brute Force',
    severity: 'high',
    check: (events) => {
      // Group by IP, count events with input fields like username/email/password
      const ipCounts: Record<string, SiteEventInput[]> = {}
      for (const e of events) {
        if (!e.inputSnippet || e.inputSnippet.startsWith('click:')) continue
        const hasLoginField = /username|email|password|user|login|passwd/i.test(e.inputSnippet)
        if (hasLoginField) {
          if (!ipCounts[e.ip]) ipCounts[e.ip] = []
          ipCounts[e.ip].push(e)
        }
      }
      const matches: DetectionMatch[] = []
      for (const [ip, evts] of Object.entries(ipCounts)) {
        if (evts.length >= 5) {
          matches.push({
            ruleId: 'BRUTE_FORCE_001',
            ip,
            details: `${evts.length} login attempts from ${ip} — fields: ${evts[0].inputSnippet?.slice(0, 60)}`,
            events: evts,
          })
        }
      }
      return matches
    },
    playbook: { blockIp: true, telegramAlert: true, aiAnalysis: true },
  },
  {
    id: 'ROUTE_SCAN_001',
    name: 'Route Scanning',
    description: 'Many 404/403 requests across sensitive paths from same IP.',
    tactic: 'Discovery',
    techniqueId: 'T1595',
    techniqueName: 'Active Scanning',
    severity: 'medium',
    check: (events) => {
      const ipErrors: Record<string, SiteEventInput[]> = {}
      for (const e of events) {
        if (e.statusCode && e.statusCode >= 400) {
          if (!ipErrors[e.ip]) ipErrors[e.ip] = []
          ipErrors[e.ip].push(e)
        }
      }
      const matches: DetectionMatch[] = []
      for (const [ip, evts] of Object.entries(ipErrors)) {
        if (evts.length >= 5) {
          matches.push({
            ruleId: 'ROUTE_SCAN_001',
            ip,
            details: `${evts.length} error responses (404/403) from ${ip} across ${new Set(evts.map(e => e.path)).size} paths`,
            events: evts,
          })
        }
      }
      return matches
    },
    playbook: { blockIp: false, telegramAlert: true, aiAnalysis: true },
  },
  {
    id: 'MALWARE_001',
    name: 'Suspicious File Upload',
    description: 'File with double extension or known malicious hash uploaded.',
    tactic: 'Execution',
    techniqueId: 'T1204',
    techniqueName: 'User Execution',
    severity: 'critical',
    check: (events) => {
      const matches: DetectionMatch[] = []
      for (const e of events) {
        if (e.fileVerdict === 'malicious') {
          matches.push({
            ruleId: 'MALWARE_001',
            ip: e.ip,
            details: `Malicious file upload: ${e.fileName} (verdict: ${e.fileVerdict})`,
            events: [e],
          })
        }
      }
      return matches
    },
    playbook: { blockIp: true, revokeSession: true, telegramAlert: true, aiAnalysis: true, quarantineFile: true },
  },
  {
    id: 'SQLI_001',
    name: 'SQL Injection Attempt',
    description: 'SQL injection patterns detected in input fields.',
    tactic: 'Initial Access',
    techniqueId: 'T1190',
    techniqueName: 'Exploit Public-Facing Application',
    severity: 'high',
    check: (events) => {
      const sqliPattern = /union\s+select|'\s*or\s*'?1'?\s*=?\s*1|;\s*drop\s+table|xp_cmdshell|information_schema/i
      const matches: DetectionMatch[] = []
      for (const e of events) {
        if (e.inputSnippet && sqliPattern.test(e.inputSnippet)) {
          matches.push({
            ruleId: 'SQLI_001',
            ip: e.ip,
            details: `SQLi pattern in input: ${e.inputSnippet.slice(0, 80)}`,
            events: [e],
          })
        }
      }
      return matches
    },
    playbook: { blockIp: true, telegramAlert: true, aiAnalysis: true },
  },
  {
    id: 'XSS_001',
    name: 'Cross-Site Scripting Attempt',
    description: 'XSS payloads detected in input fields.',
    tactic: 'Execution',
    techniqueId: 'T1059',
    techniqueName: 'Command and Scripting Interpreter',
    severity: 'high',
    check: (events) => {
      const xssPattern = /<script|javascript:|onerror\s*=|onload\s*=|<iframe|document\.cookie/i
      const matches: DetectionMatch[] = []
      for (const e of events) {
        if (e.inputSnippet && xssPattern.test(e.inputSnippet)) {
          matches.push({
            ruleId: 'XSS_001',
            ip: e.ip,
            details: `XSS pattern in input: ${e.inputSnippet.slice(0, 80)}`,
            events: [e],
          })
        }
      }
      return matches
    },
    playbook: { blockIp: true, telegramAlert: true, aiAnalysis: true },
  },
  {
    id: 'SESSION_REPL_001',
    name: 'Session Replication',
    description: 'Same session token used from multiple IPs.',
    tactic: 'Credential Access',
    techniqueId: 'T1078',
    techniqueName: 'Valid Accounts',
    severity: 'high',
    check: (events) => {
      const sessionIps: Record<string, Set<string>> = {}
      const sessionEvents: Record<string, SiteEventInput[]> = {}
      for (const e of events) {
        if (!e.sessionId) continue
        if (!sessionIps[e.sessionId]) { sessionIps[e.sessionId] = new Set(); sessionEvents[e.sessionId] = [] }
        sessionIps[e.sessionId].add(e.ip)
        sessionEvents[e.sessionId].push(e)
      }
      const matches: DetectionMatch[] = []
      for (const [sessionId, ips] of Object.entries(sessionIps)) {
        if (ips.size > 1) {
          matches.push({
            ruleId: 'SESSION_REPL_001',
            ip: Array.from(ips)[0],
            details: `Session ${sessionId.slice(0, 12)}… used from ${ips.size} IPs: ${Array.from(ips).join(', ')}`,
            events: sessionEvents[sessionId],
          })
        }
      }
      return matches
    },
    playbook: { revokeSession: true, telegramAlert: true, aiAnalysis: true },
  },
]

/**
 * Run all detection rules against recent SiteEvents for a project.
 * When a rule matches, execute the playbook:
 *   1. Create an alert with MITRE mapping
 *   2. If AI analysis is enabled, call the AI analyst for a confidence score
 *   3. If blockIp is enabled, add the IP to the blocklist
 *   4. If revokeSession is enabled, revoke the session
 *   5. If telegramAlert is enabled, send a Telegram notification
 */
export async function runDetectionPlaybook(projectId: string, projectDomain: string) {
  // Get events from the last 10 minutes
  const since = new Date(Date.now() - 10 * 60 * 1000)
  const events = await db.siteEvent.findMany({
    where: { projectId, timestamp: { gt: since } },
    orderBy: { timestamp: 'desc' },
    take: 500,
  })

  const siteEvents: SiteEventInput[] = events.map(e => ({
    ip: e.ip,
    path: e.path,
    method: e.method,
    userAgent: e.userAgent,
    inputSnippet: e.inputSnippet,
    fileName: e.fileName,
    fileVerdict: e.fileVerdict,
    sessionId: e.sessionId,
    statusCode: e.statusCode,
    timestamp: e.timestamp,
  }))

  const alertsCreated: { id: string; title: string; mitreTechnique: string; severity: string; ip: string }[] = []

  for (const rule of DETECTION_RULES) {
    const matches = rule.check(siteEvents)

    for (const match of matches) {
      // Check cooldown — don't create duplicate alerts within 5 minutes
      const existing = await db.alert.findFirst({
        where: {
          srcIp: match.ip,
          title: { contains: rule.name },
          createdAt: { gt: new Date(Date.now() - 5 * 60 * 1000) },
        },
      })
      if (existing) continue

      // Step 1: Create alert with MITRE mapping
      const alert = await db.alert.create({
        data: {
          title: `${rule.name} — ${match.ip}`,
          description: `${rule.description}\n\nDetails: ${match.details}\nMITRE: ${rule.tactic} — ${rule.techniqueId} ${rule.techniqueName}`,
          severity: rule.severity,
          status: 'new',
          mitreTactic: rule.tactic,
          mitreTechnique: rule.techniqueId,
          source: 'endpoint',
          srcIp: match.ip,
          triggeredBy: 'rule',
        },
      })

      alertsCreated.push({
        id: alert.id,
        title: alert.title,
        mitreTechnique: `${rule.techniqueId} ${rule.techniqueName}`,
        severity: rule.severity,
        ip: match.ip,
      })

      // Step 2: AI analysis (if enabled in playbook)
      if (rule.playbook.aiAnalysis) {
        try {
          const verdict = await generateAnalystVerdict({ alertId: alert.id })
          // Store the AI verdict
          await db.analystVerdict.create({
            data: {
              alertId: alert.id,
              verdict: verdict.verdict,
              confidence: verdict.confidence,
              summary: verdict.summary,
              rationale: verdict.rationale,
              recommendedActions: JSON.stringify(verdict.recommendedActions),
              keyFindings: JSON.stringify(verdict.keyFindings),
              provider: verdict.provider,
              model: verdict.model,
            },
          })
        } catch { /* AI analysis is best-effort */ }
      }

      // Step 3: Block IP (if enabled)
      if (rule.playbook.blockIp) {
        await db.domain.upsert({
          where: { hostname: match.ip },
          update: { status: 'blocked', source: 'auto_action', reason: `Blocked by rule: ${rule.name}` },
          create: { hostname: match.ip, type: 'ip', status: 'blocked', source: 'auto_action', reason: `Blocked by rule: ${rule.name}` },
        })
      }

      // Step 4: Revoke session (if enabled)
      if (rule.playbook.revokeSession && match.events[0]?.sessionId) {
        await db.sessionRevocation.create({
          data: {
            projectId,
            sessionId: match.events[0].sessionId.slice(0, 64),
            reason: `Revoked by rule: ${rule.name}`,
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
          },
        })
      }

      // Step 5: Telegram alert (if enabled)
      if (rule.playbook.telegramAlert) {
        const config = await db.telegramConfig.findFirst()
        if (config?.enabled) {
          await notifyTelegram(
            `🛡️ Bloom SIEM Alert\n\n` +
            `⚠️ ${rule.name}\n` +
            `Severity: ${rule.severity.toUpperCase()}\n` +
            `MITRE: ${rule.tactic} — ${rule.techniqueId} ${rule.techniqueName}\n` +
            `IP: ${match.ip}\n` +
            `Details: ${match.details}\n` +
            `Project: ${projectDomain}\n` +
            `Action: ${rule.playbook.blockIp ? 'IP BLOCKED' : 'monitoring'}`,
            { requireApproval: rule.playbook.blockIp, callbackData: `bloom_block:${match.ip}` }
          )
        }
      }
    }
  }

  return { alertsCreated, rulesChecked: DETECTION_RULES.length }
}
