import { db } from '@/lib/db'
import { runChat } from '@/lib/llm'
import { promises as dns } from 'node:dns'
import { connect as tlsConnect } from 'node:tls'
import { createConnection } from 'node:net'

export interface TargetAnalysis {
  hostname: string
  kind: 'domain' | 'localhost' | 'ip'
  timestamp: string
  // DNS resolution (real)
  dns: {
    resolved: boolean
    addresses: string[]
    cname?: string | null
    mx?: string[]
    txt?: string[]
    ns?: string[]
    error?: string
  }
  // HTTP reachability (real)
  http: {
    reachable: boolean
    statusCode?: number
    statusText?: string
    responseTimeMs?: number
    server?: string
    contentType?: string
    finalUrl?: string
    redirects?: number
    bodyPreview?: string
    error?: string
  }
  // HTTPS / SSL certificate (real)
  ssl: {
    hasCert?: boolean
    valid?: boolean
    daysUntilExpiry?: number
    issuer?: string
    validFrom?: string
    validTo?: string
    subject?: string
    error?: string
  } | null
  // Port scan (real TCP connect attempts)
  ports: {
    port: number
    service: string
    open: boolean
    responseTimeMs?: number
  }[]
  // Overall status
  status: 'up' | 'down' | 'partial'
  summary: string
}

const COMMON_PORTS: { port: number; service: string }[] = [
  { port: 22, service: 'ssh' },
  { port: 80, service: 'http' },
  { port: 443, service: 'https' },
  { port: 3000, service: 'node-app' },
  { port: 3306, service: 'mysql' },
  { port: 5432, service: 'postgresql' },
  { port: 6379, service: 'redis' },
  { port: 8080, service: 'http-alt' },
  { port: 9200, service: 'elasticsearch' },
]

function detectKind(hostname: string): 'domain' | 'localhost' | 'ip' {
  if (hostname.startsWith('localhost') || hostname.startsWith('127.0.0.1')) return 'localhost'
  // IPv4 check
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname.split(':')[0])) return 'ip'
  return 'domain'
}

async function resolveDns(hostname: string, kind: string): Promise<TargetAnalysis['dns']> {
  if (kind === 'localhost') {
    return { resolved: true, addresses: ['127.0.0.1'], error: undefined }
  }

  const cleanHost = hostname.split(':')[0]
  const result: TargetAnalysis['dns'] = { resolved: false, addresses: [] }

  try {
    const addrs = await dns.resolve4(cleanHost)
    result.resolved = true
    result.addresses = addrs
  } catch (err) {
    result.error = err instanceof Error ? err.message : 'DNS resolution failed'
    // Try resolveAny as fallback
    try {
      const any = await dns.resolveAny(cleanHost)
      const ips = any.filter((a) => a.type === 4 || a.type === 6).map((a) => a.address)
      if (ips.length > 0) {
        result.resolved = true
        result.addresses = ips
        result.error = undefined
      }
    } catch {
      // keep error
    }
    return result
  }

  // Try CNAME, MX, NS, TXT (best effort)
  try {
    const cname = await dns.resolveCname(cleanHost)
    result.cname = cname[0] || null
  } catch { /* ignore */ }

  try {
    const mx = await dns.resolveMx(cleanHost)
    result.mx = mx.map((m) => m.exchange)
  } catch { /* ignore */ }

  try {
    const ns = await dns.resolveNs(cleanHost)
    result.ns = ns
  } catch { /* ignore */ }

  try {
    const txt = await dns.resolveTxt(cleanHost)
    result.txt = txt.flat()
  } catch { /* ignore */ }

  return result
}

async function checkHttp(hostname: string, kind: string): Promise<TargetAnalysis['http']> {
  const cleanHost = hostname.split(':')[0]
  const portFromHost = hostname.includes(':') ? hostname.split(':')[1] : null

  // Use https for domains without explicit port, http for localhost:port
  let url: string
  if (kind === 'localhost') {
    const port = portFromHost || '3000'
    url = `http://${cleanHost}:${port}/`
  } else if (portFromHost) {
    url = `http://${cleanHost}:${portFromHost}/`
  } else {
    url = `https://${cleanHost}/`
  }

  const result: TargetAnalysis['http'] = { reachable: false }
  const startTime = Date.now()

  try {
    const res = await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      signal: AbortSignal.timeout(8000),
      headers: { 'User-Agent': 'Bloom-SIEM/2.5 (+https://bloomsec.net)' },
    })

    result.reachable = true
    result.statusCode = res.status
    result.statusText = res.statusText
    result.responseTimeMs = Date.now() - startTime
    result.server = res.headers.get('server') || undefined
    result.contentType = res.headers.get('content-type') || undefined
    result.finalUrl = res.url
    result.redirects = 0 // fetch follows redirects automatically; we don't count

    // Get a small body preview
    try {
      const text = await res.text()
      result.bodyPreview = text.slice(0, 500)
    } catch { /* ignore body errors */ }
  } catch (err) {
    result.error = err instanceof Error ? err.message : 'HTTP request failed'
    result.responseTimeMs = Date.now() - startTime
  }

  return result
}

async function checkSsl(hostname: string, kind: string): Promise<TargetAnalysis['ssl']> {
  if (kind === 'localhost') return null

  const cleanHost = hostname.split(':')[0]
  const port = hostname.includes(':') ? Number(hostname.split(':')[1]) : 443

  return new Promise((resolve) => {
    const result: TargetAnalysis['ssl'] = { hasCert: false, valid: false }
    const socket = tlsConnect(
      { host: cleanHost, port, servername: cleanHost, rejectUnauthorized: false },
      () => {
        const cert = socket.getPeerCertificate()
        if (cert && Object.keys(cert).length > 0) {
          result.hasCert = true
          result.subject = cert.subject?.CN || JSON.stringify(cert.subject)
          result.issuer = cert.issuer?.O || cert.issuer?.CN || JSON.stringify(cert.issuer)
          result.validFrom = cert.valid_from
          result.validTo = cert.valid_to
          const expiry = new Date(cert.valid_to).getTime()
          const now = Date.now()
          const validFromTime = new Date(cert.valid_from).getTime()
          result.daysUntilExpiry = Math.floor((expiry - now) / (1000 * 60 * 60 * 24))
          // A cert is "valid" if:
          // 1. It's not expired (daysUntilExpiry > 0)
          // 2. The current date is within the validity window (after valid_from)
          // We DON'T require socket.authorized because that checks the full CA chain,
          // which can fail if the server doesn't send intermediate certs — a common
          // misconfiguration that doesn't mean the cert itself is invalid.
          result.valid = result.daysUntilExpiry > 0 && now >= validFromTime
        }
        socket.end()
        resolve(result)
      }
    )
    socket.setTimeout(15000, () => {
      result.error = 'TLS connection timeout'
      socket.destroy()
      resolve(result)
    })
    socket.on('error', (err) => {
      result.error = err.message
      resolve(result)
    })
  })
}

async function scanPorts(hostname: string, kind: string): Promise<TargetAnalysis['ports']> {
  const cleanHost = hostname.split(':')[0]
  const targetHost = kind === 'localhost' ? '127.0.0.1' : cleanHost

  // If hostname has explicit port, only scan that port + a few common ones
  const explicitPort = hostname.includes(':') ? Number(hostname.split(':')[1]) : null
  const portsToScan = explicitPort
    ? [COMMON_PORTS.find((p) => p.port === explicitPort) || { port: explicitPort, service: 'custom' }, ...COMMON_PORTS.filter((p) => p.port !== explicitPort).slice(0, 5)]
    : kind === 'localhost' ? COMMON_PORTS.filter((p) => [3000, 8080, 5432, 6379, 9200].includes(p.port)) : COMMON_PORTS

  const results: TargetAnalysis['ports'] = []

  await Promise.all(
    portsToScan.map(async ({ port, service }) => {
      const startTime = Date.now()
      try {
        await new Promise<void>((resolve, reject) => {
          const socket = createConnection({ host: targetHost, port }, () => {
            socket.end()
            resolve()
          })
          socket.setTimeout(5000, () => {
            socket.destroy()
            reject(new Error('timeout'))
          })
          socket.on('error', (err) => {
            socket.destroy()
            reject(err)
          })
        })
        results.push({ port, service, open: true, responseTimeMs: Date.now() - startTime })
      } catch {
        results.push({ port, service, open: false })
      }
    })
  )

  return results.sort((a, b) => a.port - b.port)
}

export async function analyzeTarget(hostname: string): Promise<TargetAnalysis> {
  const kind = detectKind(hostname)
  const timestamp = new Date().toISOString()

  const [dnsResult, httpResult, sslResult, portsResult] = await Promise.all([
    resolveDns(hostname, kind),
    checkHttp(hostname, kind),
    checkSsl(hostname, kind),
    scanPorts(hostname, kind),
  ])

  const anyHttp = httpResult.reachable
  const anyPortOpen = portsResult.some((p) => p.open)
  const dnsOk = dnsResult.resolved || kind === 'localhost'

  const status: TargetAnalysis['status'] =
    anyHttp && anyPortOpen ? 'up' :
    !anyHttp && !anyPortOpen && !dnsOk ? 'down' :
    'partial'

  const summary = kind === 'localhost'
    ? `Localhost target on port ${hostname.split(':')[1] || '3000'}. HTTP ${httpResult.reachable ? `reachable (${httpResult.statusCode})` : 'unreachable'}. ${portsResult.filter((p) => p.open).length} ports open.`
    : `Domain ${hostname}. DNS ${dnsResult.resolved ? `resolved to ${dnsResult.addresses.join(', ')}` : 'failed'}. HTTP ${httpResult.reachable ? `${httpResult.statusCode} in ${httpResult.responseTimeMs}ms` : 'unreachable'}. SSL ${sslResult?.valid ? `valid (${sslResult.daysUntilExpiry}d remaining)` : sslResult?.hasCert ? 'invalid/expired' : 'none'}. ${portsResult.filter((p) => p.open).length} ports open.`

  return {
    hostname,
    kind,
    timestamp,
    dns: dnsResult,
    http: httpResult,
    ssl: sslResult,
    ports: portsResult,
    status,
    summary,
  }
}

/**
 * Persist the analysis result to the MonitoredTarget record.
 */
export async function analyzeAndPersist(targetId: string): Promise<TargetAnalysis> {
  const target = await db.monitoredTarget.findUnique({ where: { id: targetId } })
  if (!target) throw new Error('Target not found')

  const result = await analyzeTarget(target.hostname)

  await db.monitoredTarget.update({
    where: { id: targetId },
    data: {
      lastStatus: result.status,
      lastCheckAt: new Date(),
      lastResult: JSON.stringify(result),
    },
  })

  return result
}

/**
 * Generate an AI risk assessment of a monitored target using real LLM.
 */
export async function generateTargetRiskAssessment(analysis: TargetAnalysis): Promise<{
  riskLevel: 'low' | 'medium' | 'high' | 'critical'
  riskScore: number
  findings: string[]
  recommendations: string[]
  provider: string
  model: string
}> {
  const systemPrompt = `You are Bloom AI Security Analyst. Analyze the target's real scan results and provide a risk assessment.

Respond with valid JSON only:
{
  "riskLevel": "low" | "medium" | "high" | "critical",
  "riskScore": <0-100>,
  "findings": ["<specific finding 1>", ...],
  "recommendations": ["<actionable recommendation 1>", ...]
}

Base the assessment on:
- Open ports (more open = higher exposure)
- SSL validity (expired/invalid = high risk)
- HTTP server header (reveals server software version = info disclosure)
- DNS records (missing MX/SPF/DMARC = potential email spoofing)
- Response time and reachability`

  const userPrompt = `Target: ${analysis.hostname} (${analysis.kind})

DNS: ${analysis.dns.resolved ? `resolved → ${analysis.dns.addresses.join(', ')}` : 'FAILED'}
  MX: ${analysis.dns.mx?.join(', ') || 'none'}
  NS: ${analysis.dns.ns?.join(', ') || 'none'}
  TXT: ${analysis.dns.txt?.slice(0, 3).join(', ') || 'none'}

HTTP: ${analysis.http.reachable ? `${analysis.http.statusCode} ${analysis.http.statusText} in ${analysis.http.responseTimeMs}ms` : 'UNREACHABLE'}
  Server: ${analysis.http.server || 'unknown'}
  Content-Type: ${analysis.http.contentType || 'unknown'}
  Redirects to: ${analysis.http.finalUrl || 'none'}

SSL: ${analysis.ssl ? (analysis.ssl.hasCert ? `${analysis.ssl.valid ? 'VALID' : 'INVALID/EXPIRED'} (${analysis.ssl.daysUntilExpiry}d remaining, issuer: ${analysis.ssl.issuer})` : 'no cert') : 'N/A (localhost)'}

Open ports: ${analysis.ports.filter((p) => p.open).map((p) => `${p.port}/${p.service}`).join(', ') || 'none'}
Closed ports: ${analysis.ports.filter((p) => !p.open).map((p) => `${p.port}/${p.service}`).join(', ') || 'none'}`

  try {
    const result = await runChat(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      { temperature: 0.3, maxTokens: 700 }
    )

    let content = result.content.trim()
    if (content.startsWith('```')) {
      content = content.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '')
    }
    const parsed = JSON.parse(content)
    return {
      riskLevel: parsed.riskLevel || 'medium',
      riskScore: Math.min(100, Math.max(0, Number(parsed.riskScore) || 50)),
      findings: Array.isArray(parsed.findings) ? parsed.findings : [],
      recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : [],
      provider: result.provider,
      model: result.model,
    }
  } catch (err) {
    console.error('[AI Risk] LLM failed, using rule-based:', err)
    // Rule-based fallback
    const openPortCount = analysis.ports.filter((p) => p.open).length
    const sslIssue = analysis.ssl && (!analysis.ssl.valid || (analysis.ssl.daysUntilExpiry ?? 999) < 30)
    const riskScore = Math.min(100, openPortCount * 10 + (sslIssue ? 30 : 0) + (analysis.http.server ? 5 : 0))
    const riskLevel = riskScore >= 70 ? 'critical' : riskScore >= 50 ? 'high' : riskScore >= 30 ? 'medium' : 'low'
    return {
      riskLevel,
      riskScore,
      findings: [
        `${openPortCount} ports open`,
        sslIssue ? 'SSL certificate issue detected' : 'SSL valid',
        analysis.http.server ? `Server header exposes: ${analysis.http.server}` : 'No server header',
      ],
      recommendations: [
        'Close unnecessary open ports',
        sslIssue ? 'Renew SSL certificate' : 'Maintain SSL hygiene',
        analysis.http.server ? 'Hide server version header' : 'Keep current config',
      ],
      provider: 'rule-based',
      model: 'fallback',
    }
  }
}
