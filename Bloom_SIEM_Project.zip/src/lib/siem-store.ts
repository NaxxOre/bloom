'use client'

import { create } from 'zustand'

export type SiemView =
  | 'home'
  | 'monitored_targets'
  | 'reports'
  | 'response'
  | 'alerts'
  | 'intelligence'
  | 'controls'
  | 'connectors'
  | 'automation'
  | 'ai_config'
  | 'admin'

interface SiemState {
  activeView: SiemView
  setActiveView: (v: SiemView) => void
  alertFilter: 'all' | 'new' | 'triaged' | 'escalated' | 'closed'
  setAlertFilter: (f: SiemState['alertFilter']) => void
  severityFilter: 'all' | 'low' | 'medium' | 'high' | 'critical'
  setSeverityFilter: (s: SiemState['severityFilter']) => void
  wsConnected: boolean
  setWsConnected: (b: boolean) => void
  liveEvents: LiveEvent[]
  pushLiveEvent: (e: LiveEvent) => void
}

export interface LiveEvent {
  id: string
  type: 'heartbeat' | 'alert' | 'action' | 'log'
  message: string
  severity?: 'info' | 'low' | 'medium' | 'high' | 'critical'
  ts: number
}

export const useSiemStore = create<SiemState>((set) => ({
  activeView: 'home',
  setActiveView: (v) => set({ activeView: v }),
  alertFilter: 'all',
  setAlertFilter: (f) => set({ alertFilter: f }),
  severityFilter: 'all',
  setSeverityFilter: (s) => set({ severityFilter: s }),
  wsConnected: false,
  setWsConnected: (b) => set({ wsConnected: b }),
  liveEvents: [],
  pushLiveEvent: (e) =>
    set((s) => {
      // Deduplicate by event ID (SSE reconnects can replay)
      if (s.liveEvents.some((existing) => existing.id === e.id)) return s
      return { liveEvents: [e, ...s.liveEvents].slice(0, 50) }
    }),
}))
