import { db } from '@/lib/db'

const geoCache = new Map<string, { country: string; countryCode: string; asn: string; expires: number }>()
const CACHE_TTL = 24 * 60 * 60 * 1000

export async function lookupIp(ip: string): Promise<{ country: string; countryCode: string; asn: string } | null> {
  if (!ip || ip === '0.0.0.0' || ip === '127.0.0.1' || ip.startsWith('10.') || ip.startsWith('192.168.') || ip.startsWith('172.') || ip.startsWith('21.')) {
    return { country: 'Local', countryCode: 'LO', asn: 'Private Network' }
  }

  const cached = geoCache.get(ip)
  if (cached && cached.expires > Date.now()) {
    return { country: cached.country, countryCode: cached.countryCode, asn: cached.asn }
  }

  try {
    const res = await fetch(`http://ip-api.com/json/${ip}?fields=status,country,countryCode,as,asname`, {
      signal: AbortSignal.timeout(3000),
    })
    const data = await res.json()
    if (data.status === 'success') {
      const result = {
        country: data.country || 'Unknown',
        countryCode: data.countryCode || 'XX',
        asn: data.asname || data.as || 'Unknown',
      }
      geoCache.set(ip, { ...result, expires: Date.now() + CACHE_TTL })
      return result
    }
  } catch {}

  return null
}

export async function checkCountryBlock(ip: string): Promise<{ blocked: boolean; country?: string; rule?: string }> {
  const geo = await lookupIp(ip)
  if (!geo) return { blocked: false }
  const blocked = await db.domain.findUnique({ where: { hostname: `country:${geo.countryCode}` } })
  if (blocked?.status === 'blocked') {
    return { blocked: true, country: geo.country, rule: `Country Block: ${geo.country}` }
  }
  return { blocked: false, country: geo.country }
}
