// In-memory live event generator for Bloom SIEM
// Avoids the need for a separate WebSocket process

export interface LiveEvent {
  id: string
  type: 'heartbeat' | 'alert' | 'action' | 'log' | 'agent_offline'
  message: string
  severity?: 'info' | 'low' | 'medium' | 'high' | 'critical'
  ts: number
}

// Global in-memory state (survives across requests in dev)
declare global {
  var __bloomSiemState: {
    events: LiveEvent[]
    lastHeartbeats: Map<string, number>
    heartbeatIntervalMin: number
    aiActionsEnabled: boolean
    lastLogEmit: number
    lastAlertEmit: number
    lastHeartbeatEmit: number
    subscribers: Set<(e: LiveEvent) => void>
  } | undefined
}

const HOSTS = [
  'web-prod-01', 'web-prod-02', 'db-prod-01', 'db-prod-02', 'app-prod-01',
  'app-prod-02', 'mail-srv-01', 'vpn-gw-01', 'dc-01', 'dc-02',
  'fileshare-01', 'bastion-01', 'k8s-master-01', 'k8s-worker-01', 'k8s-worker-02',
]

const SAMPLE_IPS = [
  '185.220.101.45', '193.27.228.142', '45.155.205.83', '91.219.236.166',
  '194.169.175.10', '103.97.176.30', '212.193.30.25', '167.94.138.44',
  '198.235.24.34', '139.59.8.173',
]

const ALERT_TEMPLATES = [
  { title: 'SSH Brute Force Detected', severity: 'high', tactic: 'Credential Access', technique: 'T1110', source: 'network' },
  { title: 'Suspicious PowerShell Execution', severity: 'high', tactic: 'Execution', technique: 'T1059.001', source: 'endpoint' },
  { title: 'C2 Beacon to Malicious Host', severity: 'critical', tactic: 'Command & Control', technique: 'T1071', source: 'network' },
  { title: 'Mimikatz Detected', severity: 'critical', tactic: 'Credential Access', technique: 'T1003', source: 'endpoint' },
  { title: 'Data Exfiltration Pattern', severity: 'high', tactic: 'Exfiltration', technique: 'T1041', source: 'behavior' },
  { title: 'Port Scan from External', severity: 'low', tactic: 'Reconnaissance', technique: 'T1046', source: 'external' },
  { title: 'Malware Signature Match', severity: 'critical', tactic: 'Execution', technique: 'T1204', source: 'endpoint' },
  { title: 'DNS Tunneling Suspected', severity: 'high', tactic: 'Command & Control', technique: 'T1071.004', source: 'network' },
  { title: 'Privileged Account Created', severity: 'high', tactic: 'Persistence', technique: 'T1136', source: 'endpoint' },
  { title: 'Lateral Movement via SMB', severity: 'high', tactic: 'Lateral Movement', technique: 'T1021.002', source: 'network' },
  { title: 'AV Service Stopped', severity: 'critical', tactic: 'Defense Evasion', technique: 'T1562.001', source: 'endpoint' },
]

const ACTION_TEMPLATES = [
  { action: 'block_ip', label: 'IP blocked at perimeter firewall' },
  { action: 'isolate_host', label: 'Host network-isolated via EDR' },
  { action: 'disable_user', label: 'User account disabled in AD' },
  { action: 'quarantine_file', label: 'File quarantined by endpoint agent' },
  { action: 'create_ticket', label: 'Incident ticket created' },
  { action: 'notify', label: 'SOC on-call paged' },
]

const LOG_TEMPLATES = [
  'TCP connection from external host',
  'SSH authentication failed',
  'HTTP request to suspicious domain',
  'File modified in system directory',
  'User login from new location',
  'DNS query to known DGA domain',
  'Firewall rule blocked connection',
  'Process spawned with elevated privileges',
  'Outbound HTTPS connection',
  'New listening port opened',
]

function rand<T>(arr: T[]): T { return arr[Math.floor(Math.random() * arr.length)] }
function randInt(min: number, max: number) { return Math.floor(Math.random() * (max - min + 1)) + min }

function getState() {
  if (!globalThis.__bloomSiemState) {
    globalThis.__bloomSiemState = {
      events: [],
      lastHeartbeats: new Map(),
      heartbeatIntervalMin: 5,
      aiActionsEnabled: true,
      lastLogEmit: 0,
      lastAlertEmit: 0,
      lastHeartbeatEmit: 0,
      subscribers: new Set(),
    }
    // Initialize heartbeats
    HOSTS.forEach((h) => globalThis.__bloomSiemState!.lastHeartbeats.set(h, Date.now()))
  }
  return globalThis.__bloomSiemState
}

function pushEvent(event: LiveEvent) {
  const state = getState()
  state.events.unshift(event)
  if (state.events.length > 100) state.events = state.events.slice(0, 100)
  state.subscribers.forEach((cb) => cb(event))
}

// Tick function — called on every /api/live request to generate new events
export function tickLiveEvents() {
  const state = getState()
  const now = Date.now()

  // Heartbeats every 10s
  if (now - state.lastHeartbeatEmit > 10000) {
    state.lastHeartbeatEmit = now
    // 3 random agents heartbeat
    for (let i = 0; i < 3; i++) {
      const host = rand(HOSTS)
      state.lastHeartbeats.set(host, now)
      pushEvent({
        id: `hb_${host}_${now}_${i}`,
        type: 'heartbeat',
        message: `Heartbeat from ${host} (every ${state.heartbeatIntervalMin}m)`,
        severity: 'info',
        ts: now,
      })
    }

    // Check offline agents
    const offlineThresholdMs = state.heartbeatIntervalMin * 60 * 1000 * 3
    for (const host of HOSTS) {
      const last = state.lastHeartbeats.get(host) || 0
      if (now - last > offlineThresholdMs && now - last < offlineThresholdMs + 15000) {
        pushEvent({
          id: `offline_${host}_${now}`,
          type: 'agent_offline',
          message: `Agent ${host} went offline — no heartbeat for ${Math.floor((now - last) / 60000)} min`,
          severity: 'high',
          ts: now,
        })
      }
    }
  }

  // Logs every 3s
  if (now - state.lastLogEmit > 3000) {
    state.lastLogEmit = now
    const severityRoll = Math.random()
    const severity =
      severityRoll > 0.95 ? 'critical' :
      severityRoll > 0.85 ? 'high' :
      severityRoll > 0.65 ? 'medium' :
      severityRoll > 0.35 ? 'low' : 'info'
    pushEvent({
      id: `log_${now}_${randInt(1000, 9999)}`,
      type: 'log',
      message: `${rand(['FIREWALL', 'ENDPOINT', 'AUTH', 'NETWORK', 'CLOUD', 'DNS'])} · ${rand(LOG_TEMPLATES)} · src=${rand(SAMPLE_IPS)}`,
      severity,
      ts: now,
    })
  }

  // Alerts every 12s
  if (now - state.lastAlertEmit > 12000) {
    state.lastAlertEmit = now
    const tmpl = rand(ALERT_TEMPLATES)
    const srcIp = rand(SAMPLE_IPS)
    const alertId = `alert_${now}_${randInt(1000, 9999)}`

    pushEvent({
      id: alertId,
      type: 'alert',
      message: `${tmpl.title} (${tmpl.tactic}) · src=${srcIp} · via ${Math.random() > 0.5 ? 'ai' : 'rule'}`,
      severity: tmpl.severity as LiveEvent['severity'],
      ts: now,
    })

    // AI auto-action for high/critical
    if (state.aiActionsEnabled && ['high', 'critical'].includes(tmpl.severity)) {
      const act = rand(ACTION_TEMPLATES)
      const target =
        act.action === 'block_ip' ? srcIp :
        act.action === 'isolate_host' ? rand(HOSTS) :
        act.action === 'disable_user' ? rand(['admin', 'svc_account', 'analyst-jane', 'developer-01']) :
        act.action === 'quarantine_file' ? `${rand(['a1b2', 'f9e8', '9a8b'])}c3d4e5f6...` :
        act.action === 'create_ticket' ? `INC-2026-${randInt(100, 999)}` :
        'soc-team@bloom.io'

      // Slight delay simulated by ts offset
      pushEvent({
        id: `action_${now}_${randInt(1000, 9999)}`,
        type: 'action',
        message: `AI ${act.action} → ${target} (response to "${tmpl.title}")`,
        severity: tmpl.severity as LiveEvent['severity'],
        ts: now + 1500,
      })
    }
  }
}

export function getRecentEvents(since: number = 0, limit: number = 50): LiveEvent[] {
  const state = getState()
  return state.events.filter((e) => e.ts > since).slice(0, limit)
}

export function getConfig() {
  const state = getState()
  return {
    heartbeatIntervalMin: state.heartbeatIntervalMin,
    aiActionsEnabled: state.aiActionsEnabled,
  }
}

export function updateConfig(cfg: { heartbeatIntervalMin?: number; aiActionsEnabled?: boolean }) {
  const state = getState()
  if (cfg.heartbeatIntervalMin !== undefined) state.heartbeatIntervalMin = cfg.heartbeatIntervalMin
  if (cfg.aiActionsEnabled !== undefined) state.aiActionsEnabled = cfg.aiActionsEnabled
  return getConfig()
}

export function subscribe(cb: (e: LiveEvent) => void): () => void {
  const state = getState()
  state.subscribers.add(cb)
  return () => { state.subscribers.delete(cb) }
}
